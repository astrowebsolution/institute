-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 17, 2019 at 12:16 PM
-- Server version: 5.6.41-84.1-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demorewo_demore`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `aId` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `aFDate` date NOT NULL,
  `aTDate` date NOT NULL,
  `aPlan` int(11) NOT NULL,
  `aNostudent` int(11) NOT NULL,
  `aNosms` int(11) NOT NULL,
  `plan_price` varchar(255) NOT NULL,
  `plan_allocation` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `fees` varchar(255) NOT NULL,
  `dicipline` varchar(255) NOT NULL,
  `medical` varchar(255) NOT NULL,
  `transport` varchar(255) NOT NULL,
  `bulk` varchar(255) NOT NULL,
  `short` varchar(255) NOT NULL,
  `messageall` varchar(255) NOT NULL,
  `marksms` varchar(255) NOT NULL,
  `sms_medical_add` varchar(255) NOT NULL,
  `sms_medical_edit` varchar(255) NOT NULL,
  `sms_dicipline_add` varchar(255) NOT NULL,
  `sms_dicipline_edit` varchar(255) NOT NULL,
  `sms_fees_add` varchar(255) NOT NULL,
  `sms_fees_edit` varchar(255) NOT NULL,
  `sms_fees_pending` varchar(255) NOT NULL,
  `sms_fees_reminder_single` varchar(255) NOT NULL,
  `sms_fees_reminder_all` varchar(255) NOT NULL,
  `sms_attedence` varchar(255) NOT NULL,
  `sms_message_all` varchar(255) NOT NULL,
  `sms_message_mark` varchar(255) NOT NULL,
  `sms_message_text` varchar(255) NOT NULL,
  `frontoffice` varchar(255) NOT NULL,
  `feesreminder` varchar(255) NOT NULL,
  `smshideshow` varchar(255) NOT NULL,
  `homework` varchar(255) NOT NULL,
  `studentexammarks` varchar(255) NOT NULL,
  `studentattedence` varchar(255) NOT NULL,
  `studentadmissions` varchar(255) NOT NULL,
  `studentprofile` varchar(255) NOT NULL,
  `schoolsettings` varchar(255) NOT NULL,
  `sssalaryname` varchar(255) NOT NULL,
  `ssteacherprofile` varchar(255) NOT NULL,
  `ssfees` varchar(255) NOT NULL,
  `ssgrade` varchar(255) NOT NULL,
  `ssacadmic` varchar(255) NOT NULL,
  `ssdesignation` varchar(255) NOT NULL,
  `ssqualification` varchar(255) NOT NULL,
  `sssection` varchar(255) NOT NULL,
  `sshouse` varchar(255) NOT NULL,
  `ssaccount` varchar(255) NOT NULL,
  `ssschoolprofile` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `ipoption` varchar(255) NOT NULL,
  `passcheck` varchar(255) NOT NULL,
  `mobilenolist` varchar(255) NOT NULL,
  `currentsmstime` varchar(255) NOT NULL,
  `attendance_cur_dateactive` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`aId`, `sId`, `aFDate`, `aTDate`, `aPlan`, `aNostudent`, `aNosms`, `plan_price`, `plan_allocation`, `note`, `fees`, `dicipline`, `medical`, `transport`, `bulk`, `short`, `messageall`, `marksms`, `sms_medical_add`, `sms_medical_edit`, `sms_dicipline_add`, `sms_dicipline_edit`, `sms_fees_add`, `sms_fees_edit`, `sms_fees_pending`, `sms_fees_reminder_single`, `sms_fees_reminder_all`, `sms_attedence`, `sms_message_all`, `sms_message_mark`, `sms_message_text`, `frontoffice`, `feesreminder`, `smshideshow`, `homework`, `studentexammarks`, `studentattedence`, `studentadmissions`, `studentprofile`, `schoolsettings`, `sssalaryname`, `ssteacherprofile`, `ssfees`, `ssgrade`, `ssacadmic`, `ssdesignation`, `ssqualification`, `sssection`, `sshouse`, `ssaccount`, `ssschoolprofile`, `ipaddress`, `ipoption`, `passcheck`, `mobilenolist`, `currentsmstime`, `attendance_cur_dateactive`) VALUES
(2, 1, '2019-02-05', '2019-02-05', 1, 1077, 0, 'Rs.220 + GST', '', '', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '', '1', '', '', '2019-02-05 10:09:27', 0);

-- --------------------------------------------------------

--
-- Table structure for table `addroom`
--

CREATE TABLE `addroom` (
  `rid` int(11) NOT NULL,
  `roomno` varchar(100) NOT NULL,
  `floorname` varchar(100) NOT NULL,
  `lineno` varchar(100) NOT NULL,
  `benchcapacity` varchar(100) NOT NULL,
  `totbench` varchar(100) NOT NULL,
  `totstu` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `add_exam`
--

CREATE TABLE `add_exam` (
  `examId` int(11) NOT NULL,
  `schollId` int(11) NOT NULL,
  `classId` int(11) NOT NULL,
  `examName` varchar(200) NOT NULL,
  `examDate` date NOT NULL,
  `common_exam_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `add_exam_name`
--

CREATE TABLE `add_exam_name` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(150) NOT NULL,
  `schollId` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(32) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'admin',
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `created`, `username`, `password`, `email`, `role`, `status`) VALUES
(1, '2018-03-27 13:31:35', 'admin', '0192023a7bbd73250516f069df18b500', 'admin@gmail.com', 'admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin_details`
--

CREATE TABLE `admin_details` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_details`
--

INSERT INTO `admin_details` (`id`, `username`, `password`, `type`) VALUES
(1, 'admin', 'admin123', 'superadmin');

-- --------------------------------------------------------

--
-- Table structure for table `admin_editaccess`
--

CREATE TABLE `admin_editaccess` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `lesson_board_activity_list_id` int(11) NOT NULL,
  `request_access` int(11) NOT NULL COMMENT '1 - permission asked to edit, 2 - permission granted',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `autoname_types`
--

CREATE TABLE `autoname_types` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` text NOT NULL,
  `is_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auto_generations`
--

CREATE TABLE `auto_generations` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `autoname_type_id` int(11) NOT NULL,
  `fees_type_id` int(11) NOT NULL,
  `auto_start_no` varchar(50) DEFAULT NULL,
  `type` enum('Automatic','Manual','','') NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_entry`
--

CREATE TABLE `bank_entry` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `bank_setting_id` int(11) NOT NULL,
  `action_mode` varchar(100) DEFAULT NULL,
  `amount` varchar(50) NOT NULL,
  `payment_mode` varchar(100) DEFAULT NULL,
  `entry_date` varchar(100) DEFAULT NULL,
  `challan_no` varchar(100) DEFAULT NULL,
  `is_active` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_name`
--

CREATE TABLE `bank_name` (
  `id` int(64) NOT NULL,
  `scl_id` varchar(100) NOT NULL,
  `bank_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bank_setting`
--

CREATE TABLE `bank_setting` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `bank_name` text NOT NULL,
  `account_name` varchar(200) DEFAULT NULL,
  `account_no` varchar(100) DEFAULT NULL,
  `branch` varchar(200) DEFAULT NULL,
  `ifsc_code` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `opening_balance` varchar(200) DEFAULT NULL,
  `account_in_head` varchar(100) DEFAULT NULL,
  `fees_group_id` varchar(200) DEFAULT NULL,
  `is_active` int(11) NOT NULL,
  `fees_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `aurther` text NOT NULL,
  `quantity` text NOT NULL,
  `now` text NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `book_fees_collection`
--

CREATE TABLE `book_fees_collection` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `academicid` int(11) NOT NULL,
  `fees_group_id` int(11) NOT NULL,
  `term_setting_id` int(11) NOT NULL,
  `class` varchar(50) NOT NULL,
  `school_admissionid` int(11) DEFAULT NULL,
  `fees_amount` varchar(250) DEFAULT NULL,
  `paid_amount` varchar(250) DEFAULT NULL,
  `balance_amount` varchar(250) DEFAULT NULL,
  `receipt_no` varchar(100) DEFAULT NULL,
  `is_active` int(11) DEFAULT '1',
  `updatedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff_form_id` int(11) DEFAULT NULL,
  `cancel_reason` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bus_fees_collection`
--

CREATE TABLE `bus_fees_collection` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `academicid` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `school_admissionid` int(11) DEFAULT NULL,
  `fees_amount` varchar(250) DEFAULT NULL,
  `paid_amount` varchar(250) DEFAULT NULL,
  `balance_amount` varchar(250) DEFAULT NULL,
  `receipt_no` varchar(100) DEFAULT NULL,
  `is_active` int(11) DEFAULT '1',
  `updatedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff_form_id` int(11) DEFAULT NULL,
  `cancel_reason` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `castes`
--

CREATE TABLE `castes` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `castes`
--

INSERT INTO `castes` (`id`, `sid`, `name`, `status`, `created`) VALUES
(1, 1, 'OC', 1, '2018-04-28 00:00:00'),
(2, 1, 'BC', 1, '2018-04-27 21:33:16');

-- --------------------------------------------------------

--
-- Table structure for table `certificate`
--

CREATE TABLE `certificate` (
  `id` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `class_name` varchar(100) NOT NULL,
  `stud_name` varchar(100) NOT NULL,
  `pre_stud` varchar(100) NOT NULL,
  `pre_par` varchar(100) NOT NULL,
  `academic` varchar(100) NOT NULL,
  `tu_num` varchar(100) NOT NULL,
  `tu_words` text NOT NULL,
  `issue_date` varchar(100) NOT NULL,
  `book_num` varchar(200) NOT NULL,
  `total` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `com_id` int(11) NOT NULL,
  `msg_id_fk` int(11) NOT NULL,
  `fromdate` varchar(50) NOT NULL,
  `todate` varchar(50) NOT NULL,
  `classname` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `reason` varchar(850) NOT NULL,
  `stu_name` varchar(50) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `mother_name` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `admi_id` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cosholatic_grades`
--

CREATE TABLE `cosholatic_grades` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `exam_detail_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `cosholatic_subsubject_id` int(11) NOT NULL,
  `cos_grade` varchar(10) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cosholatic_mainsubject`
--

CREATE TABLE `cosholatic_mainsubject` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `abbrevation` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cosholatic_subsubject`
--

CREATE TABLE `cosholatic_subsubject` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `main_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `abbrevation` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dynamicfields`
--

CREATE TABLE `dynamicfields` (
  `id` int(11) NOT NULL,
  `dynamictable_id` int(11) NOT NULL,
  `fieldname` varchar(500) NOT NULL,
  `fieldtype` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dynamicfields`
--

INSERT INTO `dynamicfields` (`id`, `dynamictable_id`, `fieldname`, `fieldtype`, `status`, `sid`, `modified`) VALUES
(2, 1, 'dd', 'select', 1, 1, '2018-04-29 01:14:29'),
(3, 1, 'du', 'date', 1, 1, '2018-04-29 01:15:57');

-- --------------------------------------------------------

--
-- Table structure for table `dynamictables`
--

CREATE TABLE `dynamictables` (
  `id` int(11) NOT NULL,
  `tablename` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dynamictables`
--

INSERT INTO `dynamictables` (`id`, `tablename`, `status`, `sid`, `modified`) VALUES
(1, 'school_admission', 1, 1, '2018-04-29 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `emp_code`
--

CREATE TABLE `emp_code` (
  `id` int(11) NOT NULL,
  `sId` varchar(11) NOT NULL,
  `emp_format` varchar(25) NOT NULL,
  `prefix` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `enquiries_no` varchar(50) NOT NULL,
  `enquiries_status` enum('In Progress','Closed','Rejected','') NOT NULL,
  `app_rel_name` varchar(255) NOT NULL,
  `app_relation` varchar(50) NOT NULL,
  `mobile_phone` varchar(50) NOT NULL,
  `street_address` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `app_remark` varchar(255) NOT NULL,
  `stu_name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `currentclass` varchar(20) NOT NULL,
  `currentschool` varchar(255) NOT NULL,
  `income_year` varchar(20) NOT NULL,
  `incomeclass` varchar(20) NOT NULL,
  `status_remark` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `eventtype` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  `user_classes` varchar(500) NOT NULL,
  `user_department` varchar(500) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `allDay` varchar(10) DEFAULT NULL,
  `holiday` varchar(50) NOT NULL,
  `start` varchar(255) NOT NULL,
  `end` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `className` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `backgroundColor` varchar(255) DEFAULT NULL,
  `borderColor` varchar(255) DEFAULT NULL,
  `textColor` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `events_old`
--

CREATE TABLE `events_old` (
  `id` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `event_name` text NOT NULL,
  `event_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `examroomallocation`
--

CREATE TABLE `examroomallocation` (
  `exid` int(11) NOT NULL,
  `examname` varchar(100) NOT NULL,
  `examdate` date NOT NULL,
  `extime` varchar(100) NOT NULL,
  `examroomno` longtext NOT NULL,
  `clsname` longtext NOT NULL,
  `teachername` longtext NOT NULL,
  `tecroomsel` longtext NOT NULL,
  `autman` int(11) NOT NULL,
  `stuclsname` longtext NOT NULL,
  `noofstu` longtext NOT NULL,
  `fromstu` longtext NOT NULL,
  `tostu` longtext NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(150) NOT NULL,
  `sid` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exam_config_grades`
--

CREATE TABLE `exam_config_grades` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `graderow_id` int(11) NOT NULL,
  `fa_grade` text NOT NULL,
  `fa_min_mark` int(11) NOT NULL,
  `fa_max_mark` int(11) NOT NULL,
  `sa_grade` text NOT NULL,
  `sa_min_mark` int(11) NOT NULL,
  `sa_max_mark` int(11) NOT NULL,
  `total_grade` text NOT NULL,
  `total_min_mark` int(11) NOT NULL,
  `total_max_mark` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_config_grades`
--

INSERT INTO `exam_config_grades` (`id`, `sid`, `graderow_id`, `fa_grade`, `fa_min_mark`, `fa_max_mark`, `sa_grade`, `sa_min_mark`, `sa_max_mark`, `total_grade`, `total_min_mark`, `total_max_mark`) VALUES
(1, 1, 1, 'A1', 37, 40, 'A1', 55, 60, 'A1', 91, 100),
(2, 1, 2, 'A2', 33, 36, 'A2', 49, 54, 'A2', 81, 90),
(3, 1, 3, 'B1', 29, 32, 'B1', 43, 48, 'B1', 71, 80),
(4, 1, 4, 'B2', 25, 28, 'B2', 37, 42, 'B2', 61, 70),
(5, 1, 5, 'C1', 21, 24, 'C1', 31, 36, 'C1', 51, 60),
(6, 1, 6, 'C2', 17, 20, 'C2', 25, 30, 'C2', 41, 50),
(7, 1, 7, 'D', 13, 16, 'D', 20, 24, 'D', 33, 40),
(8, 1, 8, 'E1', 9, 12, 'E1', 13, 19, 'E1', 21, 32),
(9, 1, 9, 'E2', 0, 8, 'E2', 0, 12, 'E2', 0, 20);

-- --------------------------------------------------------

--
-- Table structure for table `exam_config_totalgrades`
--

CREATE TABLE `exam_config_totalgrades` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `grade` text NOT NULL,
  `classes` text NOT NULL,
  `min_mark` int(11) NOT NULL,
  `max_mark` int(11) NOT NULL,
  `graderow_id` int(11) NOT NULL,
  `apply_version` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_config_totalgrades`
--

INSERT INTO `exam_config_totalgrades` (`id`, `sid`, `grade`, `classes`, `min_mark`, `max_mark`, `graderow_id`, `apply_version`) VALUES
(63, 1, 'A+', '', 451, 500, 0, 1),
(64, 1, 'A', '', 401, 450, 1, 1),
(65, 1, 'B+', '', 351, 400, 2, 1),
(66, 1, 'B', '', 301, 350, 3, 1),
(67, 1, 'C+', '', 251, 300, 4, 1),
(68, 1, 'C', '', 201, 250, 5, 1),
(69, 1, 'D+', '', 151, 200, 6, 1),
(70, 1, 'D', '', 101, 150, 7, 1),
(71, 1, 'E', '', 1, 100, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `exam_details`
--

CREATE TABLE `exam_details` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `examDate` date NOT NULL,
  `exam_id` int(11) NOT NULL,
  `subject_id` varchar(1000) NOT NULL,
  `status` int(11) NOT NULL,
  `publish_status` int(11) NOT NULL,
  `generatecard_status` int(11) NOT NULL COMMENT '0 - NA, 1 - Card Created, 2 - Raised Request',
  `examentry_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exam_grades`
--

CREATE TABLE `exam_grades` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `exam_detail_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `school_subject_id` int(11) NOT NULL,
  `fa_mark` varchar(20) NOT NULL,
  `sa_mark` varchar(20) NOT NULL,
  `total_mark` varchar(20) NOT NULL,
  `fa_grade` varchar(20) NOT NULL,
  `sa_grade` varchar(20) NOT NULL,
  `total_grade` varchar(20) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exam_mark`
--

CREATE TABLE `exam_mark` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `exam_detail_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `school_subject_id` int(11) NOT NULL,
  `mark` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `pass_mark` varchar(10) NOT NULL,
  `total_mark` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exam_remarks`
--

CREATE TABLE `exam_remarks` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `exam_detail_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `remark` text NOT NULL,
  `total` int(11) NOT NULL,
  `tot` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `crank` int(11) NOT NULL COMMENT 'class rank',
  `orank` int(11) NOT NULL COMMENT 'overall rank',
  `chart1` int(11) NOT NULL COMMENT ' 0 - NA, 1 - Chart created',
  `chart2` int(11) NOT NULL COMMENT ' 0 - NA, 1 - Chart created'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exam_totalgrades`
--

CREATE TABLE `exam_totalgrades` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `exam_detail_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `remark` text NOT NULL,
  `total` int(11) NOT NULL,
  `total_grade` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `crank` int(11) NOT NULL,
  `orank` int(11) NOT NULL,
  `chart1` int(11) NOT NULL,
  `chart2` int(11) NOT NULL,
  `chart3` int(11) NOT NULL,
  `chart4` int(11) NOT NULL,
  `chart5` int(11) NOT NULL,
  `chart6` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `expenses_entry`
--

CREATE TABLE `expenses_entry` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `bank_setting_id` int(11) NOT NULL,
  `expenses_setting_id` varchar(100) DEFAULT NULL,
  `amount` varchar(50) NOT NULL,
  `is_active` int(11) DEFAULT '1',
  `receipt_no` varchar(100) DEFAULT NULL,
  `updatedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `payment_mode` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `expenses_setting`
--

CREATE TABLE `expenses_setting` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` text NOT NULL,
  `is_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fees_collection_default`
--

CREATE TABLE `fees_collection_default` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `fees_type_id` int(11) NOT NULL,
  `academicid` int(11) NOT NULL,
  `fees_group_id` int(11) NOT NULL,
  `term_setting_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fees_discount`
--

CREATE TABLE `fees_discount` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_acadamic_id` int(11) NOT NULL,
  `school_admissionid` int(11) DEFAULT NULL,
  `classsectionid` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `rollno` varchar(50) NOT NULL,
  `fees_name_id` int(11) NOT NULL,
  `fees_amount` varchar(250) DEFAULT NULL,
  `concession` varchar(100) NOT NULL,
  `concession_amount` varchar(100) NOT NULL,
  `net_amount` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `is_active` int(11) DEFAULT '1',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees_discount`
--

INSERT INTO `fees_discount` (`id`, `sid`, `school_config_acadamic_id`, `school_admissionid`, `classsectionid`, `student_name`, `rollno`, `fees_name_id`, `fees_amount`, `concession`, `concession_amount`, `net_amount`, `remarks`, `is_active`, `created`) VALUES
(1, 1, 1, 76, 1, 'OMA SHAHID', '-', 1, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(2, 1, 1, 76, 1, 'OMA SHAHID', '-', 2, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(3, 1, 1, 76, 1, 'OMA SHAHID', '-', 3, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(4, 1, 1, 76, 1, 'OMA SHAHID', '-', 4, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(5, 1, 1, 76, 1, 'OMA SHAHID', '-', 5, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(6, 1, 1, 76, 1, 'OMA SHAHID', '-', 6, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(7, 1, 1, 76, 1, 'OMA SHAHID', '-', 7, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(8, 1, 1, 76, 1, 'OMA SHAHID', '-', 8, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(9, 1, 1, 76, 1, 'OMA SHAHID', '-', 9, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(10, 1, 1, 76, 1, 'OMA SHAHID', '-', 10, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(11, 1, 1, 76, 1, 'OMA SHAHID', '-', 11, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(12, 1, 1, 76, 1, 'OMA SHAHID', '-', 12, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:18:05'),
(13, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 1, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(14, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 2, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(15, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 3, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(16, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 4, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(17, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 5, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(18, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 6, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(19, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 7, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(20, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 8, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(21, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 9, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(22, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 10, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(23, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 11, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(24, 1, 1, 70, 1, 'MD SHEEZAN ALI', '-', 12, '1620', '0', '620', '1000', '', 1, '2019-02-05 12:19:03'),
(25, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 1, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(26, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 2, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(27, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 3, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(28, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 4, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(29, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 5, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(30, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 6, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(31, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 7, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(32, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 8, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(33, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 9, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(34, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 10, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(35, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 11, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(36, 1, 1, 47, 1, 'ABDUL MUHAYMIN HAFIZ', '-', 12, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:20:14'),
(37, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 1, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(38, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 2, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(39, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 3, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(40, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 4, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(41, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 5, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(42, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 6, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(43, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 7, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(44, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 8, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(45, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 9, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(46, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 10, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(47, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 11, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(48, 1, 1, 75, 1, 'MOHAMMED INSHAL', '-', 12, '1620', '0', '100', '1520', '', 1, '2019-02-05 12:21:19'),
(49, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 1, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(50, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 2, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(51, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 3, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(52, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 4, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(53, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 5, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(54, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 6, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(55, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 7, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(56, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 8, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(57, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 9, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(58, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 10, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(59, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 11, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(60, 1, 1, 123, 2, 'MD HASAN SAUD', '-', 12, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:22:47'),
(61, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 1, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(62, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 2, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(63, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 3, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(64, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 4, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(65, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 5, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(66, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 6, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(67, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 7, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(68, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 8, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(69, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 9, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(70, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 10, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(71, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 11, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(72, 1, 1, 115, 2, 'ZUNAID ALAM', '-', 12, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:24:44'),
(73, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 1, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(74, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 2, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(75, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 3, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(76, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 4, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(77, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 5, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(78, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 6, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(79, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 7, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(80, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 8, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(81, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 9, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(82, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 10, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(83, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 11, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(84, 1, 1, 125, 2, 'MD HUZAIFA ', '-', 12, '1620', '0', '1240', '380', '', 1, '2019-02-05 12:25:26'),
(85, 1, 1, 145, 2, 'ZAID AHMED', '-', 1, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(86, 1, 1, 145, 2, 'ZAID AHMED', '-', 2, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(87, 1, 1, 145, 2, 'ZAID AHMED', '-', 3, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(88, 1, 1, 145, 2, 'ZAID AHMED', '-', 4, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(89, 1, 1, 145, 2, 'ZAID AHMED', '-', 5, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(90, 1, 1, 145, 2, 'ZAID AHMED', '-', 6, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(91, 1, 1, 145, 2, 'ZAID AHMED', '-', 7, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(92, 1, 1, 145, 2, 'ZAID AHMED', '-', 8, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(93, 1, 1, 145, 2, 'ZAID AHMED', '-', 9, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(94, 1, 1, 145, 2, 'ZAID AHMED', '-', 10, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(95, 1, 1, 145, 2, 'ZAID AHMED', '-', 11, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(96, 1, 1, 145, 2, 'ZAID AHMED', '-', 12, '1620', '0', '270', '1350', '', 1, '2019-02-05 12:26:53'),
(97, 1, 1, 144, 2, 'TAHA UZAI', '-', 1, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(98, 1, 1, 144, 2, 'TAHA UZAI', '-', 2, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(99, 1, 1, 144, 2, 'TAHA UZAI', '-', 3, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(100, 1, 1, 144, 2, 'TAHA UZAI', '-', 4, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(101, 1, 1, 144, 2, 'TAHA UZAI', '-', 5, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(102, 1, 1, 144, 2, 'TAHA UZAI', '-', 6, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(103, 1, 1, 144, 2, 'TAHA UZAI', '-', 7, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(104, 1, 1, 144, 2, 'TAHA UZAI', '-', 8, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(105, 1, 1, 144, 2, 'TAHA UZAI', '-', 9, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(106, 1, 1, 144, 2, 'TAHA UZAI', '-', 10, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(107, 1, 1, 144, 2, 'TAHA UZAI', '-', 11, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(108, 1, 1, 144, 2, 'TAHA UZAI', '-', 12, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:29:12'),
(109, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 1, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(110, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 2, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(111, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 3, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(112, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 4, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(113, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 5, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(114, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 6, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(115, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 7, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(116, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 8, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(117, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 9, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(118, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 10, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(119, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 11, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(120, 1, 1, 124, 2, 'MD HUSSAIN MEHEBAN', '-', 12, '1620', '0', '400', '1220', '', 1, '2019-02-05 12:31:40'),
(121, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 1, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(122, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 2, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(123, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 3, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(124, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 4, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(125, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 5, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(126, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 6, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(127, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 7, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(128, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 8, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(129, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 9, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(130, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 10, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(131, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 11, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(132, 1, 1, 143, 2, 'SK GOLAM HASSAN', '-', 12, '1620', '0', '420', '1200', '', 1, '2019-02-05 12:33:11'),
(133, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 1, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(134, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 2, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(135, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 3, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(136, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 4, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(137, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 5, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(138, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 6, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(139, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 7, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(140, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 8, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(141, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 9, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(142, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 10, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(143, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 11, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(144, 1, 1, 11, 1, 'IFA SHAMSAD', '-', 12, '1620', '0', '250', '1370', '', 1, '2019-02-05 12:41:13'),
(145, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 1, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(146, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 2, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(147, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 3, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(148, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 4, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(149, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 5, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(150, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 6, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(151, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 7, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(152, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 8, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(153, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 9, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(154, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 10, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(155, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 11, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(156, 1, 1, 21, 1, 'SAAH SOHAIL', '-', 12, '1620', '0', '370', '1250', '', 1, '2019-02-05 12:43:52'),
(157, 1, 1, 18, 1, 'AZIA AHMED', '-', 1, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(158, 1, 1, 18, 1, 'AZIA AHMED', '-', 2, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(159, 1, 1, 18, 1, 'AZIA AHMED', '-', 3, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(160, 1, 1, 18, 1, 'AZIA AHMED', '-', 4, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(161, 1, 1, 18, 1, 'AZIA AHMED', '-', 5, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(162, 1, 1, 18, 1, 'AZIA AHMED', '-', 6, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(163, 1, 1, 18, 1, 'AZIA AHMED', '-', 7, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(164, 1, 1, 18, 1, 'AZIA AHMED', '-', 8, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(165, 1, 1, 18, 1, 'AZIA AHMED', '-', 9, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(166, 1, 1, 18, 1, 'AZIA AHMED', '-', 10, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(167, 1, 1, 18, 1, 'AZIA AHMED', '-', 11, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(168, 1, 1, 18, 1, 'AZIA AHMED', '-', 12, '1620', '0', '480', '1140', '', 1, '2019-02-05 12:50:41'),
(169, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 1, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(170, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 2, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(171, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 3, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(172, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 4, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(173, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 5, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(174, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 6, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(175, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 7, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(176, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 8, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(177, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 9, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(178, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 10, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(179, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 11, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(180, 1, 1, 17, 1, 'NAMIA MAYAM', '-', 12, '1620', '0', '320', '1300', '', 1, '2019-02-05 12:54:23'),
(181, 1, 1, 90, 2, 'AISHA FATMA', '-', 1, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(182, 1, 1, 90, 2, 'AISHA FATMA', '-', 2, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(183, 1, 1, 90, 2, 'AISHA FATMA', '-', 3, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(184, 1, 1, 90, 2, 'AISHA FATMA', '-', 4, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(185, 1, 1, 90, 2, 'AISHA FATMA', '-', 5, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(186, 1, 1, 90, 2, 'AISHA FATMA', '-', 6, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(187, 1, 1, 90, 2, 'AISHA FATMA', '-', 7, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(188, 1, 1, 90, 2, 'AISHA FATMA', '-', 8, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(189, 1, 1, 90, 2, 'AISHA FATMA', '-', 9, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(190, 1, 1, 90, 2, 'AISHA FATMA', '-', 10, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(191, 1, 1, 90, 2, 'AISHA FATMA', '-', 11, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(192, 1, 1, 90, 2, 'AISHA FATMA', '-', 12, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:04:07'),
(193, 1, 1, 93, 2, 'EEAM NASIM', '-', 1, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(194, 1, 1, 93, 2, 'EEAM NASIM', '-', 2, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(195, 1, 1, 93, 2, 'EEAM NASIM', '-', 3, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(196, 1, 1, 93, 2, 'EEAM NASIM', '-', 4, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(197, 1, 1, 93, 2, 'EEAM NASIM', '-', 5, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(198, 1, 1, 93, 2, 'EEAM NASIM', '-', 6, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(199, 1, 1, 93, 2, 'EEAM NASIM', '-', 7, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(200, 1, 1, 93, 2, 'EEAM NASIM', '-', 8, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(201, 1, 1, 93, 2, 'EEAM NASIM', '-', 9, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(202, 1, 1, 93, 2, 'EEAM NASIM', '-', 10, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(203, 1, 1, 93, 2, 'EEAM NASIM', '-', 11, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(204, 1, 1, 93, 2, 'EEAM NASIM', '-', 12, '1620', '0', '250', '1370', '', 1, '2019-02-06 05:05:20'),
(205, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 1, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(206, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 2, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(207, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 3, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(208, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 4, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(209, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 5, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(210, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 6, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(211, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 7, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(212, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 8, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(213, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 9, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(214, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 10, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(215, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 11, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(216, 1, 1, 217, 3, 'MOHAMMAD EBAHIM', '-', 12, '1620', '0', '160', '1460', '', 1, '2019-02-06 05:06:21'),
(217, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 1, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(218, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 2, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(219, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 3, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(220, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 4, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(221, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 5, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(222, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 6, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(223, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 7, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(224, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 8, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(225, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 9, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(226, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 10, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(227, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 11, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(228, 1, 1, 199, 3, 'MD.AALAYMEEN EJAZ', '-', 12, '1620', '0', '220', '1400', '', 1, '2019-02-06 05:06:50'),
(229, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 1, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(230, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 2, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(231, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 3, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(232, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 4, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(233, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 5, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(234, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 6, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(235, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 7, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(236, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 8, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(237, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 9, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(238, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 10, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(239, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 11, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(240, 1, 1, 266, 4, 'MD YAWA MALLIK', '-', 12, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:29'),
(241, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 1, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:56'),
(242, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 2, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(243, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 3, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(244, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 4, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(245, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 5, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(246, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 6, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(247, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 7, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(248, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 8, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(249, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 9, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(250, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 10, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(251, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 11, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(252, 1, 1, 281, 4, 'SYED ABDUL KHALEQ', '-', 12, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:07:57'),
(253, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 1, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(254, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 2, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(255, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 3, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(256, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 4, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(257, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 5, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(258, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 6, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(259, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 7, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(260, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 8, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(261, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 9, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(262, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 10, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(263, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 11, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(264, 1, 1, 263, 4, 'MD AIHANUDDIN', '-', 12, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:08:57'),
(265, 1, 1, 221, 3, 'MD ILYASEEN', '-', 1, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(266, 1, 1, 221, 3, 'MD ILYASEEN', '-', 2, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(267, 1, 1, 221, 3, 'MD ILYASEEN', '-', 3, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(268, 1, 1, 221, 3, 'MD ILYASEEN', '-', 4, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(269, 1, 1, 221, 3, 'MD ILYASEEN', '-', 5, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(270, 1, 1, 221, 3, 'MD ILYASEEN', '-', 6, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(271, 1, 1, 221, 3, 'MD ILYASEEN', '-', 7, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(272, 1, 1, 221, 3, 'MD ILYASEEN', '-', 8, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(273, 1, 1, 221, 3, 'MD ILYASEEN', '-', 9, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(274, 1, 1, 221, 3, 'MD ILYASEEN', '-', 10, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(275, 1, 1, 221, 3, 'MD ILYASEEN', '-', 11, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(276, 1, 1, 221, 3, 'MD ILYASEEN', '-', 12, '1620', '0', '1240', '380', '', 1, '2019-02-06 05:10:45'),
(277, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 1, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(278, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 2, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(279, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 3, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(280, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 4, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(281, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 5, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(282, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 6, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(283, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 7, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(284, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 8, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(285, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 9, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(286, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 10, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(287, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 11, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(288, 1, 1, 276, 4, 'NOUMAN HOSSAIN', '-', 12, '1620', '0', '400', '1220', '', 1, '2019-02-06 05:11:14'),
(289, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 1, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(290, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 2, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(291, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 3, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(292, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 4, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(293, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 5, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(294, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 6, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(295, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 7, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(296, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 8, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(297, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 9, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(298, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 10, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(299, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 11, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(300, 1, 1, 181, 3, 'AYESHA FATHMA', '-', 12, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:12:03'),
(301, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 1, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(302, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 2, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(303, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 3, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(304, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 4, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(305, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 5, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(306, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 6, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(307, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 7, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(308, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 8, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(309, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 9, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(310, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 10, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(311, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 11, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(312, 1, 1, 149, 3, 'AABIYA MOHAMMADI', '-', 12, '1620', '0', '320', '1300', '', 1, '2019-02-06 05:12:34'),
(313, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 1, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(314, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 2, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(315, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 3, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(316, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 4, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(317, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 5, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(318, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 6, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(319, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 7, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(320, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 8, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(321, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 9, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(322, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 10, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(323, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 11, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(324, 1, 1, 168, 3, 'NOO SIDDIQUA', '-', 12, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:13:29'),
(325, 1, 1, 243, 4, 'ZATASHA WASI', '-', 1, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(326, 1, 1, 243, 4, 'ZATASHA WASI', '-', 2, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(327, 1, 1, 243, 4, 'ZATASHA WASI', '-', 3, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(328, 1, 1, 243, 4, 'ZATASHA WASI', '-', 4, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(329, 1, 1, 243, 4, 'ZATASHA WASI', '-', 5, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(330, 1, 1, 243, 4, 'ZATASHA WASI', '-', 6, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(331, 1, 1, 243, 4, 'ZATASHA WASI', '-', 7, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(332, 1, 1, 243, 4, 'ZATASHA WASI', '-', 8, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(333, 1, 1, 243, 4, 'ZATASHA WASI', '-', 9, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(334, 1, 1, 243, 4, 'ZATASHA WASI', '-', 10, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(335, 1, 1, 243, 4, 'ZATASHA WASI', '-', 11, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(336, 1, 1, 243, 4, 'ZATASHA WASI', '-', 12, '1620', '0', '620', '1000', '', 1, '2019-02-06 05:15:19'),
(337, 1, 1, 240, 4, 'TALLA AZMI', '-', 1, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(338, 1, 1, 240, 4, 'TALLA AZMI', '-', 2, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(339, 1, 1, 240, 4, 'TALLA AZMI', '-', 3, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(340, 1, 1, 240, 4, 'TALLA AZMI', '-', 4, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(341, 1, 1, 240, 4, 'TALLA AZMI', '-', 5, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(342, 1, 1, 240, 4, 'TALLA AZMI', '-', 6, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(343, 1, 1, 240, 4, 'TALLA AZMI', '-', 7, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(344, 1, 1, 240, 4, 'TALLA AZMI', '-', 8, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(345, 1, 1, 240, 4, 'TALLA AZMI', '-', 9, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(346, 1, 1, 240, 4, 'TALLA AZMI', '-', 10, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(347, 1, 1, 240, 4, 'TALLA AZMI', '-', 11, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(348, 1, 1, 240, 4, 'TALLA AZMI', '-', 12, '1620', '0', '500', '1120', '', 1, '2019-02-06 05:15:58'),
(349, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 1, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(350, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 2, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(351, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 3, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(352, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 4, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(353, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 5, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(354, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 6, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(355, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 7, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(356, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 8, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(357, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 9, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(358, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 10, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(359, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 11, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(360, 1, 1, 239, 4, 'SUMAYYA AUFI', '-', 12, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:16:43'),
(361, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 1, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(362, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 2, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(363, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 3, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(364, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 4, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(365, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 5, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(366, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 6, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(367, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 7, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(368, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 8, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(369, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 9, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(370, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 10, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(371, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 11, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(372, 1, 1, 242, 4, 'TASMIYA SHAKI', '-', 12, '1620', '0', '480', '1140', '', 1, '2019-02-06 05:17:40'),
(373, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 1, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(374, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 2, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(375, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 3, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(376, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 4, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(377, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 5, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(378, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 6, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(379, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 7, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(380, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 8, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(381, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 9, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(382, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 10, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(383, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 11, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(384, 1, 1, 302, 5, 'NILOFA FIDOUSE', '-', 12, '1620', '0', '270', '1350', '', 1, '2019-02-06 05:19:28'),
(385, 1, 1, 309, 5, 'YUSHA KHAN', '-', 1, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(386, 1, 1, 309, 5, 'YUSHA KHAN', '-', 2, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(387, 1, 1, 309, 5, 'YUSHA KHAN', '-', 3, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(388, 1, 1, 309, 5, 'YUSHA KHAN', '-', 4, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(389, 1, 1, 309, 5, 'YUSHA KHAN', '-', 5, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(390, 1, 1, 309, 5, 'YUSHA KHAN', '-', 6, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(391, 1, 1, 309, 5, 'YUSHA KHAN', '-', 7, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(392, 1, 1, 309, 5, 'YUSHA KHAN', '-', 8, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(393, 1, 1, 309, 5, 'YUSHA KHAN', '-', 9, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(394, 1, 1, 309, 5, 'YUSHA KHAN', '-', 10, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(395, 1, 1, 309, 5, 'YUSHA KHAN', '-', 11, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(396, 1, 1, 309, 5, 'YUSHA KHAN', '-', 12, '1620', '0', '200', '1420', '', 1, '2019-02-06 05:20:00'),
(397, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 1, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(398, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 2, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(399, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 3, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(400, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 4, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(401, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 5, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(402, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 6, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(403, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 7, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(404, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 8, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(405, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 9, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(406, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 10, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(407, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 11, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(408, 1, 1, 293, 5, 'AYESHA JEELANI', '-', 12, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:20:23'),
(409, 1, 1, 290, 5, 'AYANA VANI', '-', 1, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(410, 1, 1, 290, 5, 'AYANA VANI', '-', 2, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(411, 1, 1, 290, 5, 'AYANA VANI', '-', 3, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(412, 1, 1, 290, 5, 'AYANA VANI', '-', 4, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(413, 1, 1, 290, 5, 'AYANA VANI', '-', 5, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(414, 1, 1, 290, 5, 'AYANA VANI', '-', 6, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(415, 1, 1, 290, 5, 'AYANA VANI', '-', 7, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(416, 1, 1, 290, 5, 'AYANA VANI', '-', 8, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(417, 1, 1, 290, 5, 'AYANA VANI', '-', 9, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(418, 1, 1, 290, 5, 'AYANA VANI', '-', 10, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(419, 1, 1, 290, 5, 'AYANA VANI', '-', 11, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(420, 1, 1, 290, 5, 'AYANA VANI', '-', 12, '1620', '0', '420', '1200', '', 1, '2019-02-06 05:20:46'),
(421, 1, 1, 314, 5, 'HANIA FATMA ', '-', 1, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(422, 1, 1, 314, 5, 'HANIA FATMA ', '-', 2, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(423, 1, 1, 314, 5, 'HANIA FATMA ', '-', 3, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(424, 1, 1, 314, 5, 'HANIA FATMA ', '-', 4, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(425, 1, 1, 314, 5, 'HANIA FATMA ', '-', 5, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(426, 1, 1, 314, 5, 'HANIA FATMA ', '-', 6, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(427, 1, 1, 314, 5, 'HANIA FATMA ', '-', 7, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(428, 1, 1, 314, 5, 'HANIA FATMA ', '-', 8, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(429, 1, 1, 314, 5, 'HANIA FATMA ', '-', 9, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(430, 1, 1, 314, 5, 'HANIA FATMA ', '-', 10, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(431, 1, 1, 314, 5, 'HANIA FATMA ', '-', 11, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(432, 1, 1, 314, 5, 'HANIA FATMA ', '-', 12, '1620', '0', '860', '760', '', 1, '2019-02-06 05:21:20'),
(433, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 1, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(434, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 2, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(435, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 3, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(436, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 4, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(437, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 5, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(438, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 6, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(439, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 7, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(440, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 8, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(441, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 9, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(442, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 10, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(443, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 11, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(444, 1, 1, 315, 5, 'ZAINAB MOIN - YTE', '-', 12, '1620', '0', '520', '1100', '', 1, '2019-02-06 05:21:43'),
(445, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 13, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(446, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 14, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(447, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 15, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(448, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 16, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(449, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 17, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(450, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 18, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(451, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 19, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(452, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 20, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(453, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 21, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(454, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 22, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(455, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 23, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(456, 1, 1, 401, 15, 'MUHAMMAD AFZAL SADIQUE', '-', 24, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:23:23'),
(457, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 13, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(458, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 14, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(459, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 15, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(460, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 16, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(461, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 17, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(462, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 18, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(463, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 19, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(464, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 20, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(465, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 21, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(466, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 22, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(467, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 23, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(468, 1, 1, 380, 15, 'MD SHAYAAN HOSSAIN', '-', 24, '1720', '0', '520', '1200', '', 1, '2019-02-06 05:31:49'),
(469, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 13, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(470, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 14, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(471, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 15, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(472, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 16, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(473, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 17, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(474, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 18, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(475, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 19, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(476, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 20, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(477, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 21, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(478, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 22, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(479, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 23, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(480, 1, 1, 372, 15, 'MD FAHAN ALI ', '-', 24, '1720', '0', '200', '1520', '', 1, '2019-02-06 05:32:35'),
(481, 1, 1, 360, 15, 'ABU SAEED', '-', 13, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(482, 1, 1, 360, 15, 'ABU SAEED', '-', 14, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(483, 1, 1, 360, 15, 'ABU SAEED', '-', 15, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(484, 1, 1, 360, 15, 'ABU SAEED', '-', 16, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(485, 1, 1, 360, 15, 'ABU SAEED', '-', 17, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(486, 1, 1, 360, 15, 'ABU SAEED', '-', 18, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(487, 1, 1, 360, 15, 'ABU SAEED', '-', 19, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07');
INSERT INTO `fees_discount` (`id`, `sid`, `school_config_acadamic_id`, `school_admissionid`, `classsectionid`, `student_name`, `rollno`, `fees_name_id`, `fees_amount`, `concession`, `concession_amount`, `net_amount`, `remarks`, `is_active`, `created`) VALUES
(488, 1, 1, 360, 15, 'ABU SAEED', '-', 20, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(489, 1, 1, 360, 15, 'ABU SAEED', '-', 21, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(490, 1, 1, 360, 15, 'ABU SAEED', '-', 22, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(491, 1, 1, 360, 15, 'ABU SAEED', '-', 23, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(492, 1, 1, 360, 15, 'ABU SAEED', '-', 24, '1720', '0', '500', '1220', '', 1, '2019-02-06 05:33:07'),
(493, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 13, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(494, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 14, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(495, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 15, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(496, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 16, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(497, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 17, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(498, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 18, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(499, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 19, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(500, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 20, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(501, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 21, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(502, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 22, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(503, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 23, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(504, 1, 1, 400, 15, 'MD. AYYAN KHAN', '-', 24, '1720', '0', '900', '820', '', 1, '2019-02-06 05:34:58'),
(505, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 13, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(506, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 14, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(507, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 15, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(508, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 16, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(509, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 17, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(510, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 18, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(511, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 19, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(512, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 20, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(513, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 21, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(514, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 22, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(515, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 23, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(516, 1, 1, 472, 16, 'QUAYAAMUDDIN AHMED', '-', 24, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:31'),
(517, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 13, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(518, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 14, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(519, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 15, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(520, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 16, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(521, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 17, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(522, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 18, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(523, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 19, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(524, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 20, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(525, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 21, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(526, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 22, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(527, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 23, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(528, 1, 1, 477, 16, 'SK. GOLAM MUSTOFA ', '-', 24, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:35:58'),
(529, 1, 1, 446, 16, 'AIZ ALI', '-', 13, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(530, 1, 1, 446, 16, 'AIZ ALI', '-', 14, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(531, 1, 1, 446, 16, 'AIZ ALI', '-', 15, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(532, 1, 1, 446, 16, 'AIZ ALI', '-', 16, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(533, 1, 1, 446, 16, 'AIZ ALI', '-', 17, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(534, 1, 1, 446, 16, 'AIZ ALI', '-', 18, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(535, 1, 1, 446, 16, 'AIZ ALI', '-', 19, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(536, 1, 1, 446, 16, 'AIZ ALI', '-', 20, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(537, 1, 1, 446, 16, 'AIZ ALI', '-', 21, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(538, 1, 1, 446, 16, 'AIZ ALI', '-', 22, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(539, 1, 1, 446, 16, 'AIZ ALI', '-', 23, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(540, 1, 1, 446, 16, 'AIZ ALI', '-', 24, '1720', '0', '620', '1100', '', 1, '2019-02-06 05:36:26'),
(541, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 13, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(542, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 14, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(543, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 15, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(544, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 16, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(545, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 17, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(546, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 18, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(547, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 19, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(548, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 20, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(549, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 21, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(550, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 22, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(551, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 23, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(552, 1, 1, 475, 16, 'SK AYAN ULLHA', '-', 24, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:36:55'),
(553, 1, 1, 450, 16, 'IMAN ALAM', '-', 13, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(554, 1, 1, 450, 16, 'IMAN ALAM', '-', 14, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(555, 1, 1, 450, 16, 'IMAN ALAM', '-', 15, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(556, 1, 1, 450, 16, 'IMAN ALAM', '-', 16, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(557, 1, 1, 450, 16, 'IMAN ALAM', '-', 17, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(558, 1, 1, 450, 16, 'IMAN ALAM', '-', 18, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(559, 1, 1, 450, 16, 'IMAN ALAM', '-', 19, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(560, 1, 1, 450, 16, 'IMAN ALAM', '-', 20, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(561, 1, 1, 450, 16, 'IMAN ALAM', '-', 21, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(562, 1, 1, 450, 16, 'IMAN ALAM', '-', 22, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(563, 1, 1, 450, 16, 'IMAN ALAM', '-', 23, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(564, 1, 1, 450, 16, 'IMAN ALAM', '-', 24, '1720', '0', '270', '1450', '', 1, '2019-02-06 05:37:48'),
(565, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 13, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(566, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 14, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(567, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 15, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(568, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 16, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(569, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 17, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(570, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 18, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(571, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 19, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(572, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 20, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(573, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 21, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(574, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 22, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(575, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 23, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(576, 1, 1, 471, 16, 'MUZAMMIL IQBAL', '-', 24, '1720', '0', '860', '860', '', 1, '2019-02-06 05:38:14'),
(577, 1, 1, 481, 16, 'SAAD BIN OME', '-', 13, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(578, 1, 1, 481, 16, 'SAAD BIN OME', '-', 14, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(579, 1, 1, 481, 16, 'SAAD BIN OME', '-', 15, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(580, 1, 1, 481, 16, 'SAAD BIN OME', '-', 16, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(581, 1, 1, 481, 16, 'SAAD BIN OME', '-', 17, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(582, 1, 1, 481, 16, 'SAAD BIN OME', '-', 18, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(583, 1, 1, 481, 16, 'SAAD BIN OME', '-', 19, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(584, 1, 1, 481, 16, 'SAAD BIN OME', '-', 20, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(585, 1, 1, 481, 16, 'SAAD BIN OME', '-', 21, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(586, 1, 1, 481, 16, 'SAAD BIN OME', '-', 22, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(587, 1, 1, 481, 16, 'SAAD BIN OME', '-', 23, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(588, 1, 1, 481, 16, 'SAAD BIN OME', '-', 24, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:38:44'),
(589, 1, 1, 344, 15, 'HIBA KHAN', '-', 13, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(590, 1, 1, 344, 15, 'HIBA KHAN', '-', 14, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(591, 1, 1, 344, 15, 'HIBA KHAN', '-', 15, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(592, 1, 1, 344, 15, 'HIBA KHAN', '-', 16, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(593, 1, 1, 344, 15, 'HIBA KHAN', '-', 17, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(594, 1, 1, 344, 15, 'HIBA KHAN', '-', 18, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(595, 1, 1, 344, 15, 'HIBA KHAN', '-', 19, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(596, 1, 1, 344, 15, 'HIBA KHAN', '-', 20, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(597, 1, 1, 344, 15, 'HIBA KHAN', '-', 21, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(598, 1, 1, 344, 15, 'HIBA KHAN', '-', 22, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(599, 1, 1, 344, 15, 'HIBA KHAN', '-', 23, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(600, 1, 1, 344, 15, 'HIBA KHAN', '-', 24, '1720', '0', '820', '900', '', 1, '2019-02-06 05:43:44'),
(601, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 13, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(602, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 14, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(603, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 15, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(604, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 16, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(605, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 17, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(606, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 18, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(607, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 19, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(608, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 20, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(609, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 21, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(610, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 22, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(611, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 23, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(612, 1, 1, 334, 15, 'ATIQAH HAQUE', '-', 24, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:44:07'),
(613, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 13, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(614, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 14, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(615, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 15, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(616, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 16, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(617, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 17, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(618, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 18, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(619, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 19, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(620, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 20, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(621, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 21, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(622, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 22, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(623, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 23, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(624, 1, 1, 350, 15, 'MAHE NOO KHATOON', '-', 24, '1720', '0', '720', '1000', '', 1, '2019-02-06 05:44:39'),
(625, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 13, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(626, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 14, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(627, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 15, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(628, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 16, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(629, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 17, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(630, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 18, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(631, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 19, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(632, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 20, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(633, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 21, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(634, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 22, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(635, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 23, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(636, 1, 1, 337, 15, 'AYESHA BINT SHAHNAWAZ', '-', 24, '1720', '0', '220', '1500', '', 1, '2019-02-06 05:46:47'),
(637, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 13, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(638, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 14, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(639, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 15, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(640, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 16, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(641, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 17, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(642, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 18, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(643, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 19, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(644, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 20, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(645, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 21, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(646, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 22, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(647, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 23, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(648, 1, 1, 424, 16, 'SAMIA TANVEE', '-', 24, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:47:39'),
(649, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 13, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(650, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 14, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(651, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 15, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(652, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 16, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(653, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 17, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(654, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 18, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(655, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 19, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(656, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 20, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(657, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 21, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(658, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 22, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(659, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 23, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(660, 1, 1, 416, 16, 'NUZHAT HAFIZ', '-', 24, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:48:13'),
(661, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 13, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(662, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 14, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(663, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 15, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(664, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 16, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(665, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 17, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(666, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 18, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(667, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 19, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(668, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 20, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(669, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 21, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(670, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 22, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(671, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 23, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(672, 1, 1, 433, 16, 'UMA SIDDIQUE', '-', 24, '1720', '0', '1310', '410', '', 1, '2019-02-06 05:49:16'),
(673, 1, 1, 517, 6, 'AAFAT AHMED', '-', 13, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(674, 1, 1, 517, 6, 'AAFAT AHMED', '-', 14, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(675, 1, 1, 517, 6, 'AAFAT AHMED', '-', 15, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(676, 1, 1, 517, 6, 'AAFAT AHMED', '-', 16, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(677, 1, 1, 517, 6, 'AAFAT AHMED', '-', 17, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(678, 1, 1, 517, 6, 'AAFAT AHMED', '-', 18, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(679, 1, 1, 517, 6, 'AAFAT AHMED', '-', 19, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(680, 1, 1, 517, 6, 'AAFAT AHMED', '-', 20, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(681, 1, 1, 517, 6, 'AAFAT AHMED', '-', 21, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(682, 1, 1, 517, 6, 'AAFAT AHMED', '-', 22, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(683, 1, 1, 517, 6, 'AAFAT AHMED', '-', 23, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(684, 1, 1, 517, 6, 'AAFAT AHMED', '-', 24, '1720', '0', '370', '1350', '', 1, '2019-02-06 05:57:13'),
(685, 1, 1, 525, 6, 'MD ANAS', '-', 13, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(686, 1, 1, 525, 6, 'MD ANAS', '-', 14, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(687, 1, 1, 525, 6, 'MD ANAS', '-', 15, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(688, 1, 1, 525, 6, 'MD ANAS', '-', 16, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(689, 1, 1, 525, 6, 'MD ANAS', '-', 17, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(690, 1, 1, 525, 6, 'MD ANAS', '-', 18, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(691, 1, 1, 525, 6, 'MD ANAS', '-', 19, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(692, 1, 1, 525, 6, 'MD ANAS', '-', 20, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(693, 1, 1, 525, 6, 'MD ANAS', '-', 21, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(694, 1, 1, 525, 6, 'MD ANAS', '-', 22, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(695, 1, 1, 525, 6, 'MD ANAS', '-', 23, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(696, 1, 1, 525, 6, 'MD ANAS', '-', 24, '1720', '0', '420', '1300', '', 1, '2019-02-06 05:57:54'),
(697, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 13, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(698, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 14, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(699, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 15, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(700, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 16, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(701, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 17, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(702, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 18, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(703, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 19, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(704, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 20, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(705, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 21, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(706, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 22, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(707, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 23, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(708, 1, 1, 543, 6, 'WAQAS SAWOOD', '-', 24, '1720', '0', '320', '1400', '', 1, '2019-02-06 05:58:29'),
(709, 1, 1, 592, 7, 'MD HAMMAAD', '-', 13, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(710, 1, 1, 592, 7, 'MD HAMMAAD', '-', 14, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(711, 1, 1, 592, 7, 'MD HAMMAAD', '-', 15, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(712, 1, 1, 592, 7, 'MD HAMMAAD', '-', 16, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(713, 1, 1, 592, 7, 'MD HAMMAAD', '-', 17, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(714, 1, 1, 592, 7, 'MD HAMMAAD', '-', 18, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(715, 1, 1, 592, 7, 'MD HAMMAAD', '-', 19, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(716, 1, 1, 592, 7, 'MD HAMMAAD', '-', 20, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(717, 1, 1, 592, 7, 'MD HAMMAAD', '-', 21, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(718, 1, 1, 592, 7, 'MD HAMMAAD', '-', 22, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(719, 1, 1, 592, 7, 'MD HAMMAAD', '-', 23, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(720, 1, 1, 592, 7, 'MD HAMMAAD', '-', 24, '1720', '0', '910', '810', '', 1, '2019-02-06 05:59:56'),
(721, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 13, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(722, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 14, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(723, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 15, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(724, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 16, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(725, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 17, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(726, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 18, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(727, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 19, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(728, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 20, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(729, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 21, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(730, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 22, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(731, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 23, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(732, 1, 1, 600, 7, 'SHAMUIL EJAZ', '-', 24, '1720', '0', '400', '1320', '', 1, '2019-02-06 06:01:14'),
(733, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 13, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(734, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 14, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(735, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 15, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(736, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 16, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(737, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 17, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(738, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 18, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(739, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 19, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(740, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 20, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(741, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 21, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(742, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 22, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(743, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 23, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(744, 1, 1, 595, 7, 'MD OBAIDULLAH', '-', 24, '1720', '0', '170', '1550', '', 1, '2019-02-06 06:07:01'),
(745, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 13, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(746, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 14, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(747, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 15, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(748, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 16, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(749, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 17, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(750, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 18, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(751, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 19, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(752, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 20, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(753, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 21, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(754, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 22, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(755, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 23, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(756, 1, 1, 583, 7, 'AYAAN AHMED SIDDIQUE', '-', 24, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:07:40'),
(757, 1, 1, 602, 7, 'ZAID BIN OME', '-', 13, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(758, 1, 1, 602, 7, 'ZAID BIN OME', '-', 14, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(759, 1, 1, 602, 7, 'ZAID BIN OME', '-', 15, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(760, 1, 1, 602, 7, 'ZAID BIN OME', '-', 16, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(761, 1, 1, 602, 7, 'ZAID BIN OME', '-', 17, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(762, 1, 1, 602, 7, 'ZAID BIN OME', '-', 18, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(763, 1, 1, 602, 7, 'ZAID BIN OME', '-', 19, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(764, 1, 1, 602, 7, 'ZAID BIN OME', '-', 20, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(765, 1, 1, 602, 7, 'ZAID BIN OME', '-', 21, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(766, 1, 1, 602, 7, 'ZAID BIN OME', '-', 22, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(767, 1, 1, 602, 7, 'ZAID BIN OME', '-', 23, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(768, 1, 1, 602, 7, 'ZAID BIN OME', '-', 24, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:08:15'),
(769, 1, 1, 653, 8, 'MD MUZTABA', '-', 13, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(770, 1, 1, 653, 8, 'MD MUZTABA', '-', 14, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(771, 1, 1, 653, 8, 'MD MUZTABA', '-', 15, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(772, 1, 1, 653, 8, 'MD MUZTABA', '-', 16, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(773, 1, 1, 653, 8, 'MD MUZTABA', '-', 17, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(774, 1, 1, 653, 8, 'MD MUZTABA', '-', 18, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(775, 1, 1, 653, 8, 'MD MUZTABA', '-', 19, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(776, 1, 1, 653, 8, 'MD MUZTABA', '-', 20, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(777, 1, 1, 653, 8, 'MD MUZTABA', '-', 21, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(778, 1, 1, 653, 8, 'MD MUZTABA', '-', 22, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(779, 1, 1, 653, 8, 'MD MUZTABA', '-', 23, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(780, 1, 1, 653, 8, 'MD MUZTABA', '-', 24, '1720', '0', '500', '1220', '', 1, '2019-02-06 06:09:05'),
(781, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 13, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(782, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 14, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(783, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 15, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(784, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 16, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(785, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 17, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(786, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 18, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(787, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 19, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(788, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 20, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(789, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 21, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(790, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 22, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(791, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 23, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(792, 1, 1, 657, 8, 'SHIEKH ANAS', '-', 24, '1720', '0', '320', '1400', '', 1, '2019-02-06 06:09:45'),
(793, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 13, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(794, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 14, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(795, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 15, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(796, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 16, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(797, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 17, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(798, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 18, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(799, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 19, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(800, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 20, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(801, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 21, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(802, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 22, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(803, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 23, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(804, 1, 1, 649, 8, 'MD HAMZA FAOOQUE', '-', 24, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:10:50'),
(805, 1, 1, 659, 8, 'TAHA SHAMS', '-', 13, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(806, 1, 1, 659, 8, 'TAHA SHAMS', '-', 14, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(807, 1, 1, 659, 8, 'TAHA SHAMS', '-', 15, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(808, 1, 1, 659, 8, 'TAHA SHAMS', '-', 16, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(809, 1, 1, 659, 8, 'TAHA SHAMS', '-', 17, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(810, 1, 1, 659, 8, 'TAHA SHAMS', '-', 18, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(811, 1, 1, 659, 8, 'TAHA SHAMS', '-', 19, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(812, 1, 1, 659, 8, 'TAHA SHAMS', '-', 20, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(813, 1, 1, 659, 8, 'TAHA SHAMS', '-', 21, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(814, 1, 1, 659, 8, 'TAHA SHAMS', '-', 22, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(815, 1, 1, 659, 8, 'TAHA SHAMS', '-', 23, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(816, 1, 1, 659, 8, 'TAHA SHAMS', '-', 24, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:11:24'),
(817, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 13, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(818, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 14, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(819, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 15, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(820, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 16, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(821, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 17, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(822, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 18, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(823, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 19, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(824, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 20, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(825, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 21, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(826, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 22, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(827, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 23, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(828, 1, 1, 499, 6, 'MEHWISH KHAN', '-', 24, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:12:30'),
(829, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 13, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(830, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 14, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(831, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 15, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(832, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 16, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(833, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 17, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(834, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 18, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(835, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 19, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(836, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 20, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(837, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 21, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(838, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 22, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(839, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 23, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(840, 1, 1, 503, 6, 'SAYEEDA SAHANA', '-', 24, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:13:41'),
(841, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 13, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(842, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 14, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(843, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 15, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(844, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 16, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(845, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 17, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(846, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 18, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(847, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 19, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(848, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 20, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(849, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 21, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(850, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 22, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(851, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 23, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(852, 1, 1, 513, 6, 'SIDAH ZAKI', '-', 24, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:16:02'),
(853, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 13, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(854, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 14, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(855, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 15, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(856, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 16, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(857, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 17, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(858, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 18, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(859, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 19, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(860, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 20, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(861, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 21, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(862, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 22, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(863, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 23, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(864, 1, 1, 508, 6, 'TANAAZ KHAN', '-', 24, '1720', '0', '220', '1500', '', 1, '2019-02-06 06:16:30'),
(865, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 13, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(866, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 14, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(867, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 15, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(868, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 16, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(869, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 17, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(870, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 18, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(871, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 19, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(872, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 20, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(873, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 21, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(874, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 22, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(875, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 23, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(876, 1, 1, 609, 8, 'BUSHA KHATOON', '-', 24, '1720', '0', '1310', '410', '', 1, '2019-02-06 06:17:16'),
(877, 1, 1, 622, 8, 'SIDA SABE', '-', 13, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(878, 1, 1, 622, 8, 'SIDA SABE', '-', 14, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(879, 1, 1, 622, 8, 'SIDA SABE', '-', 15, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(880, 1, 1, 622, 8, 'SIDA SABE', '-', 16, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(881, 1, 1, 622, 8, 'SIDA SABE', '-', 17, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(882, 1, 1, 622, 8, 'SIDA SABE', '-', 18, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(883, 1, 1, 622, 8, 'SIDA SABE', '-', 19, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(884, 1, 1, 622, 8, 'SIDA SABE', '-', 20, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(885, 1, 1, 622, 8, 'SIDA SABE', '-', 21, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(886, 1, 1, 622, 8, 'SIDA SABE', '-', 22, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(887, 1, 1, 622, 8, 'SIDA SABE', '-', 23, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(888, 1, 1, 622, 8, 'SIDA SABE', '-', 24, '1720', '0', '270', '1450', '', 1, '2019-02-06 06:17:59'),
(889, 1, 1, 608, 8, 'AISHA KHAN', '-', 13, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(890, 1, 1, 608, 8, 'AISHA KHAN', '-', 14, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(891, 1, 1, 608, 8, 'AISHA KHAN', '-', 15, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(892, 1, 1, 608, 8, 'AISHA KHAN', '-', 16, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(893, 1, 1, 608, 8, 'AISHA KHAN', '-', 17, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(894, 1, 1, 608, 8, 'AISHA KHAN', '-', 18, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(895, 1, 1, 608, 8, 'AISHA KHAN', '-', 19, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(896, 1, 1, 608, 8, 'AISHA KHAN', '-', 20, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(897, 1, 1, 608, 8, 'AISHA KHAN', '-', 21, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(898, 1, 1, 608, 8, 'AISHA KHAN', '-', 22, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(899, 1, 1, 608, 8, 'AISHA KHAN', '-', 23, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(900, 1, 1, 608, 8, 'AISHA KHAN', '-', 24, '1720', '0', '720', '1000', '', 1, '2019-02-06 06:18:28'),
(901, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 25, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(902, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 26, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(903, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 27, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(904, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 28, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(905, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 29, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(906, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 30, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(907, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 31, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(908, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 32, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(909, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 33, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(910, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 34, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(911, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 35, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(912, 1, 1, 707, 9, 'MD ADNAN AKAM      ', '-', 36, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:23:57'),
(913, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 25, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(914, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 26, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(915, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 27, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(916, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 28, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(917, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 29, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(918, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 30, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(919, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 31, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(920, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 32, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(921, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 33, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(922, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 34, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(923, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 35, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(924, 1, 1, 806, 10, 'SK. EHAN EZA', '-', 36, '1750', '0', '350', '1400', '', 1, '2019-02-06 06:24:54'),
(925, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(926, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(927, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(928, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(929, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(930, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(931, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(932, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(933, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(934, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(935, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(936, 1, 1, 805, 10, 'SIDDIKUL AMIN', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:19:39'),
(937, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 25, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(938, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 26, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(939, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 27, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(940, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 28, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(941, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 29, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(942, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 30, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(943, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 31, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(944, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 32, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(945, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 33, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(946, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 34, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(947, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 35, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(948, 1, 1, 775, 10, 'ALHAMD NIAZI', '-', 36, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:20:15'),
(949, 1, 1, 776, 10, 'ANIS KHAN', '-', 25, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(950, 1, 1, 776, 10, 'ANIS KHAN', '-', 26, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(951, 1, 1, 776, 10, 'ANIS KHAN', '-', 27, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(952, 1, 1, 776, 10, 'ANIS KHAN', '-', 28, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(953, 1, 1, 776, 10, 'ANIS KHAN', '-', 29, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(954, 1, 1, 776, 10, 'ANIS KHAN', '-', 30, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(955, 1, 1, 776, 10, 'ANIS KHAN', '-', 31, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(956, 1, 1, 776, 10, 'ANIS KHAN', '-', 32, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(957, 1, 1, 776, 10, 'ANIS KHAN', '-', 33, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(958, 1, 1, 776, 10, 'ANIS KHAN', '-', 34, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(959, 1, 1, 776, 10, 'ANIS KHAN', '-', 35, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(960, 1, 1, 776, 10, 'ANIS KHAN', '-', 36, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:20:42'),
(961, 1, 1, 791, 10, 'MD AYYAN', '-', 25, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(962, 1, 1, 791, 10, 'MD AYYAN', '-', 26, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(963, 1, 1, 791, 10, 'MD AYYAN', '-', 27, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(964, 1, 1, 791, 10, 'MD AYYAN', '-', 28, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(965, 1, 1, 791, 10, 'MD AYYAN', '-', 29, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(966, 1, 1, 791, 10, 'MD AYYAN', '-', 30, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(967, 1, 1, 791, 10, 'MD AYYAN', '-', 31, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(968, 1, 1, 791, 10, 'MD AYYAN', '-', 32, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(969, 1, 1, 791, 10, 'MD AYYAN', '-', 33, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(970, 1, 1, 791, 10, 'MD AYYAN', '-', 34, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(971, 1, 1, 791, 10, 'MD AYYAN', '-', 35, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24');
INSERT INTO `fees_discount` (`id`, `sid`, `school_config_acadamic_id`, `school_admissionid`, `classsectionid`, `student_name`, `rollno`, `fees_name_id`, `fees_amount`, `concession`, `concession_amount`, `net_amount`, `remarks`, `is_active`, `created`) VALUES
(972, 1, 1, 791, 10, 'MD AYYAN', '-', 36, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:22:24'),
(973, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 25, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(974, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 26, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(975, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 27, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(976, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 28, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(977, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 29, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(978, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 30, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(979, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 31, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(980, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 32, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(981, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 33, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(982, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 34, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(983, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 35, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(984, 1, 1, 782, 10, 'FAISAL IFAN ', '-', 36, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:22:57'),
(985, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 25, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(986, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 26, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(987, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 27, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(988, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 28, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(989, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 29, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(990, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 30, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(991, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 31, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(992, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 32, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(993, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 33, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(994, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 34, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(995, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 35, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(996, 1, 1, 811, 10, 'MD ZAKI QUAISHI', '-', 36, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:23:43'),
(997, 1, 1, 794, 10, 'MD SHAQEEB', '-', 25, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(998, 1, 1, 794, 10, 'MD SHAQEEB', '-', 26, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(999, 1, 1, 794, 10, 'MD SHAQEEB', '-', 27, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(1000, 1, 1, 794, 10, 'MD SHAQEEB', '-', 28, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(1001, 1, 1, 794, 10, 'MD SHAQEEB', '-', 29, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(1002, 1, 1, 794, 10, 'MD SHAQEEB', '-', 30, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(1003, 1, 1, 794, 10, 'MD SHAQEEB', '-', 31, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(1004, 1, 1, 794, 10, 'MD SHAQEEB', '-', 32, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(1005, 1, 1, 794, 10, 'MD SHAQEEB', '-', 33, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(1006, 1, 1, 794, 10, 'MD SHAQEEB', '-', 34, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(1007, 1, 1, 794, 10, 'MD SHAQEEB', '-', 35, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(1008, 1, 1, 794, 10, 'MD SHAQEEB', '-', 36, '1750', '0', '940', '810', '', 1, '2019-02-06 07:24:21'),
(1009, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 25, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1010, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 26, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1011, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 27, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1012, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 28, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1013, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 29, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1014, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 30, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1015, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 31, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1016, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 32, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1017, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 33, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1018, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 34, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1019, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 35, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1020, 1, 1, 691, 9, 'ZAINAB SHAMSI', '-', 36, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:24:56'),
(1021, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1022, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1023, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1024, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1025, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1026, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1027, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1028, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1029, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1030, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1031, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1032, 1, 1, 680, 9, 'NOOAIN FATMA', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:25:33'),
(1033, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 25, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1034, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 26, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1035, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 27, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1036, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 28, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1037, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 29, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1038, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 30, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1039, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 31, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1040, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 32, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1041, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 33, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1042, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 34, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1043, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 35, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1044, 1, 1, 672, 9, 'KHUSHNUMA KHATOON', '-', 36, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:02'),
(1045, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 25, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1046, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 26, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1047, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 27, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1048, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 28, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1049, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 29, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1050, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 30, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1051, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 31, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1052, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 32, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1053, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 33, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1054, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 34, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1055, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 35, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1056, 1, 1, 662, 9, 'ALIEFYA HAFIZ', '-', 36, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:26:26'),
(1057, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 25, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1058, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 26, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1059, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 27, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1060, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 28, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1061, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 29, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1062, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 30, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1063, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 31, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1064, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 32, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1065, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 33, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1066, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 34, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1067, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 35, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1068, 1, 1, 673, 9, 'KHUSNUMA AZMI', '-', 36, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:26:53'),
(1069, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 25, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1070, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 26, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1071, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 27, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1072, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 28, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1073, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 29, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1074, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 30, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1075, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 31, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1076, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 32, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1077, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 33, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1078, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 34, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1079, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 35, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1080, 1, 1, 688, 9, 'TAAIBAH MAYAM', '-', 36, '1750', '0', '450', '1300', '', 1, '2019-02-06 07:27:34'),
(1081, 1, 1, 771, 10, 'THAMEENA ALI', '-', 25, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1082, 1, 1, 771, 10, 'THAMEENA ALI', '-', 26, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1083, 1, 1, 771, 10, 'THAMEENA ALI', '-', 27, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1084, 1, 1, 771, 10, 'THAMEENA ALI', '-', 28, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1085, 1, 1, 771, 10, 'THAMEENA ALI', '-', 29, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1086, 1, 1, 771, 10, 'THAMEENA ALI', '-', 30, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1087, 1, 1, 771, 10, 'THAMEENA ALI', '-', 31, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1088, 1, 1, 771, 10, 'THAMEENA ALI', '-', 32, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1089, 1, 1, 771, 10, 'THAMEENA ALI', '-', 33, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1090, 1, 1, 771, 10, 'THAMEENA ALI', '-', 34, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1091, 1, 1, 771, 10, 'THAMEENA ALI', '-', 35, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1092, 1, 1, 771, 10, 'THAMEENA ALI', '-', 36, '1750', '0', '700', '1050', '', 1, '2019-02-06 07:28:49'),
(1093, 1, 1, 767, 10, 'ZOYA SHAH', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1094, 1, 1, 767, 10, 'ZOYA SHAH', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1095, 1, 1, 767, 10, 'ZOYA SHAH', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1096, 1, 1, 767, 10, 'ZOYA SHAH', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1097, 1, 1, 767, 10, 'ZOYA SHAH', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1098, 1, 1, 767, 10, 'ZOYA SHAH', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1099, 1, 1, 767, 10, 'ZOYA SHAH', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1100, 1, 1, 767, 10, 'ZOYA SHAH', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1101, 1, 1, 767, 10, 'ZOYA SHAH', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1102, 1, 1, 767, 10, 'ZOYA SHAH', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1103, 1, 1, 767, 10, 'ZOYA SHAH', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1104, 1, 1, 767, 10, 'ZOYA SHAH', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:29:30'),
(1105, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1106, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1107, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1108, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1109, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1110, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1111, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1112, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1113, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1114, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1115, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1116, 1, 1, 741, 10, 'ALFISHA ZAFI', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:30:00'),
(1117, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 25, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1118, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 26, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1119, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 27, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1120, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 28, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1121, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 29, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1122, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 30, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1123, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 31, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1124, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 32, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1125, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 33, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1126, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 34, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1127, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 35, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1128, 1, 1, 754, 10, 'KAIKASHA KHATOON', '-', 36, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:30:43'),
(1129, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 25, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1130, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 26, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1131, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 27, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1132, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 28, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1133, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 29, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1134, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 30, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1135, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 31, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1136, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 32, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1137, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 33, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1138, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 34, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1139, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 35, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1140, 1, 1, 742, 10, 'ALIZA PAVEEN', '-', 36, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:31:20'),
(1141, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 25, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1142, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 26, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1143, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 27, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1144, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 28, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1145, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 29, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1146, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 30, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1147, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 31, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1148, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 32, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1149, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 33, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1150, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 34, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1151, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 35, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1152, 1, 1, 740, 10, 'ADIBA OBAIS', '-', 36, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:32:09'),
(1153, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 25, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:32'),
(1154, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 26, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:32'),
(1155, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 27, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:32'),
(1156, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 28, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:32'),
(1157, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 29, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:32'),
(1158, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 30, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:32'),
(1159, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 31, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:32'),
(1160, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 32, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:32'),
(1161, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 33, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:32'),
(1162, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 34, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:33'),
(1163, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 35, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:33'),
(1164, 1, 1, 762, 10, 'TAIBA KHATOON', '-', 36, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:32:33'),
(1165, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 25, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1166, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 26, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1167, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 27, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1168, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 28, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1169, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 29, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1170, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 30, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1171, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 31, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1172, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 32, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1173, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 33, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1174, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 34, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1175, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 35, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1176, 1, 1, 739, 10, 'ADIBA MUDDASSI', '-', 36, '1750', '0', '500', '1250', '', 1, '2019-02-06 07:33:18'),
(1177, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 25, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1178, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 26, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1179, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 27, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1180, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 28, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1181, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 29, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1182, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 30, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1183, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 31, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1184, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 32, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1185, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 33, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1186, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 34, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1187, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 35, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1188, 1, 1, 738, 10, 'AAMNA YASEEN', '-', 36, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:33:43'),
(1189, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1190, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1191, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1192, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1193, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1194, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1195, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1196, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1197, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1198, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1199, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1200, 1, 1, 763, 10, 'TASHHUD HUSSAIN', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:34:10'),
(1201, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 25, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1202, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 26, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1203, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 27, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1204, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 28, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1205, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 29, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1206, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 30, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1207, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 31, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1208, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 32, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1209, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 33, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1210, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 34, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1211, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 35, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1212, 1, 1, 847, 11, 'ALI- AL - HOSSAIN', '-', 36, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:34:56'),
(1213, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 25, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1214, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 26, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1215, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 27, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1216, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 28, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1217, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 29, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1218, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 30, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1219, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 31, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1220, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 32, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1221, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 33, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1222, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 34, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1223, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 35, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1224, 1, 1, 859, 11, 'MD KASHIF QAMA', '-', 36, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:35:25'),
(1225, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 25, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1226, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 26, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1227, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 27, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1228, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 28, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1229, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 29, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1230, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 30, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1231, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 31, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1232, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 32, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1233, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 33, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1234, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 34, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1235, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 35, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1236, 1, 1, 874, 11, 'TAMZEED KAIM BAKSH', '-', 36, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:36:01'),
(1237, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 25, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1238, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 26, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1239, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 27, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1240, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 28, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1241, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 29, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1242, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 30, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1243, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 31, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1244, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 32, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1245, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 33, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1246, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 34, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1247, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 35, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1248, 1, 1, 921, 12, 'IFTEKHA ALAM', '-', 36, '1750', '0', '940', '810', '', 1, '2019-02-06 07:36:30'),
(1249, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 25, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1250, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 26, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1251, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 27, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1252, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 28, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1253, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 29, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1254, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 30, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1255, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 31, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1256, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 32, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1257, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 33, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1258, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 34, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1259, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 35, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1260, 1, 1, 937, 12, 'MUHASIF ALAM', '-', 36, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:36:55'),
(1261, 1, 1, 918, 12, 'ATIF JEELANI', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1262, 1, 1, 918, 12, 'ATIF JEELANI', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1263, 1, 1, 918, 12, 'ATIF JEELANI', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1264, 1, 1, 918, 12, 'ATIF JEELANI', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1265, 1, 1, 918, 12, 'ATIF JEELANI', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1266, 1, 1, 918, 12, 'ATIF JEELANI', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1267, 1, 1, 918, 12, 'ATIF JEELANI', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1268, 1, 1, 918, 12, 'ATIF JEELANI', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1269, 1, 1, 918, 12, 'ATIF JEELANI', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1270, 1, 1, 918, 12, 'ATIF JEELANI', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1271, 1, 1, 918, 12, 'ATIF JEELANI', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1272, 1, 1, 918, 12, 'ATIF JEELANI', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:37:17'),
(1273, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 25, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1274, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 26, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1275, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 27, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1276, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 28, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1277, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 29, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1278, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 30, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1279, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 31, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1280, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 32, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1281, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 33, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1282, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 34, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1283, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 35, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1284, 1, 1, 912, 12, 'AAMI AHMED KHAN', '-', 36, '1750', '0', '430', '1320', '', 1, '2019-02-06 07:37:59'),
(1285, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 25, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1286, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 26, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1287, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 27, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1288, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 28, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1289, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 29, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1290, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 30, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1291, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 31, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1292, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 32, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1293, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 33, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1294, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 34, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1295, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 35, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1296, 1, 1, 814, 11, 'AFIFAH KHAN', '-', 36, '1750', '0', '230', '1520', '', 1, '2019-02-06 07:38:33'),
(1297, 1, 1, 837, 11, 'ABIA BISE', '-', 25, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1298, 1, 1, 837, 11, 'ABIA BISE', '-', 26, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1299, 1, 1, 837, 11, 'ABIA BISE', '-', 27, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1300, 1, 1, 837, 11, 'ABIA BISE', '-', 28, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1301, 1, 1, 837, 11, 'ABIA BISE', '-', 29, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1302, 1, 1, 837, 11, 'ABIA BISE', '-', 30, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1303, 1, 1, 837, 11, 'ABIA BISE', '-', 31, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1304, 1, 1, 837, 11, 'ABIA BISE', '-', 32, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1305, 1, 1, 837, 11, 'ABIA BISE', '-', 33, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1306, 1, 1, 837, 11, 'ABIA BISE', '-', 34, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1307, 1, 1, 837, 11, 'ABIA BISE', '-', 35, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1308, 1, 1, 837, 11, 'ABIA BISE', '-', 36, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:40:26'),
(1309, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 25, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1310, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 26, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1311, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 27, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1312, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 28, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1313, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 29, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1314, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 30, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1315, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 31, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1316, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 32, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1317, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 33, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1318, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 34, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1319, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 35, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1320, 1, 1, 831, 11, 'LAAIB DAULAT WASI', '-', 36, '1750', '0', '650', '1100', '', 1, '2019-02-06 07:41:54'),
(1321, 1, 1, 840, 11, 'SAAA ZAKI', '-', 25, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1322, 1, 1, 840, 11, 'SAAA ZAKI', '-', 26, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1323, 1, 1, 840, 11, 'SAAA ZAKI', '-', 27, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1324, 1, 1, 840, 11, 'SAAA ZAKI', '-', 28, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1325, 1, 1, 840, 11, 'SAAA ZAKI', '-', 29, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1326, 1, 1, 840, 11, 'SAAA ZAKI', '-', 30, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1327, 1, 1, 840, 11, 'SAAA ZAKI', '-', 31, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1328, 1, 1, 840, 11, 'SAAA ZAKI', '-', 32, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1329, 1, 1, 840, 11, 'SAAA ZAKI', '-', 33, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1330, 1, 1, 840, 11, 'SAAA ZAKI', '-', 34, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1331, 1, 1, 840, 11, 'SAAA ZAKI', '-', 35, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1332, 1, 1, 840, 11, 'SAAA ZAKI', '-', 36, '1750', '0', '330', '1420', '', 1, '2019-02-06 07:42:52'),
(1333, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 25, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1334, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 26, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1335, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 27, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1336, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 28, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1337, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 29, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1338, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 30, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1339, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 31, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1340, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 32, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1341, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 33, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1342, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 34, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1343, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 35, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1344, 1, 1, 822, 11, 'BUSHA SHAMS ', '-', 36, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:43:36'),
(1345, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 25, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1346, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 26, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1347, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 27, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1348, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 28, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1349, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 29, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1350, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 30, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1351, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 31, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1352, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 32, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1353, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 33, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1354, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 34, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1355, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 35, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1356, 1, 1, 843, 11, 'TAUBAH SHEEEN', '-', 36, '1750', '0', '400', '1350', '', 1, '2019-02-06 07:44:16'),
(1357, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 25, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1358, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 26, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1359, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 27, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1360, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 28, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1361, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 29, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1362, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 30, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1363, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 31, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1364, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 32, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1365, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 33, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1366, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 34, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1367, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 35, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1368, 1, 1, 826, 11, 'FATIMA BINT SHAHNAWAZ', '-', 36, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:44:49'),
(1369, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 25, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1370, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 26, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1371, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 27, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1372, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 28, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1373, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 29, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1374, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 30, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1375, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 31, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1376, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 32, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1377, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 33, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1378, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 34, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1379, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 35, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1380, 1, 1, 892, 12, 'LAIBA MEHABAN', '-', 36, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:45:36'),
(1381, 1, 1, 904, 12, 'TAHIM IFAM', '-', 25, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1382, 1, 1, 904, 12, 'TAHIM IFAM', '-', 26, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1383, 1, 1, 904, 12, 'TAHIM IFAM', '-', 27, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1384, 1, 1, 904, 12, 'TAHIM IFAM', '-', 28, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1385, 1, 1, 904, 12, 'TAHIM IFAM', '-', 29, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1386, 1, 1, 904, 12, 'TAHIM IFAM', '-', 30, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1387, 1, 1, 904, 12, 'TAHIM IFAM', '-', 31, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1388, 1, 1, 904, 12, 'TAHIM IFAM', '-', 32, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1389, 1, 1, 904, 12, 'TAHIM IFAM', '-', 33, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1390, 1, 1, 904, 12, 'TAHIM IFAM', '-', 34, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1391, 1, 1, 904, 12, 'TAHIM IFAM', '-', 35, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1392, 1, 1, 904, 12, 'TAHIM IFAM', '-', 36, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:46:29'),
(1393, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 25, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1394, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 26, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1395, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 27, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1396, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 28, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1397, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 29, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1398, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 30, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1399, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 31, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1400, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 32, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1401, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 33, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1402, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 34, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1403, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 35, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1404, 1, 1, 894, 12, 'MANTASHA SOLANKI', '-', 36, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:47:47'),
(1405, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 25, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1406, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 26, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1407, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 27, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1408, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 28, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1409, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 29, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1410, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 30, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1411, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 31, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1412, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 32, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1413, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 33, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1414, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 34, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1415, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 35, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1416, 1, 1, 885, 12, 'HAADIYA AAFEEN', '-', 36, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:19'),
(1417, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 25, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1418, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 26, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1419, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 27, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1420, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 28, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1421, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 29, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1422, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 30, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1423, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 31, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1424, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 32, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1425, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 33, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1426, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 34, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1427, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 35, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1428, 1, 1, 890, 12, 'JUWAIYA AAFEEN', '-', 36, '1750', '0', '940', '810', '', 1, '2019-02-06 07:48:52'),
(1429, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 25, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1430, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 26, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1431, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 27, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1432, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 28, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1433, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 29, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1434, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 30, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1435, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 31, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1436, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 32, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1437, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 33, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1438, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 34, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1439, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 35, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1440, 1, 1, 907, 12, 'ZAINAB FATMA', '-', 36, '1750', '0', '930', '820', '', 1, '2019-02-06 07:49:19'),
(1441, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 25, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1442, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 26, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1443, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 27, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1444, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 28, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1445, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 29, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56');
INSERT INTO `fees_discount` (`id`, `sid`, `school_config_acadamic_id`, `school_admissionid`, `classsectionid`, `student_name`, `rollno`, `fees_name_id`, `fees_amount`, `concession`, `concession_amount`, `net_amount`, `remarks`, `is_active`, `created`) VALUES
(1446, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 30, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1447, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 31, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1448, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 32, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1449, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 33, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1450, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 34, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1451, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 35, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1452, 1, 1, 1009, 13, 'YASEEN AHMED', '-', 36, '1750', '0', '535', '1215', '', 1, '2019-02-06 07:49:56'),
(1453, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 25, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1454, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 26, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1455, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 27, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1456, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 28, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1457, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 29, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1458, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 30, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1459, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 31, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1460, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 32, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1461, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 33, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1462, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 34, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1463, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 35, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1464, 1, 1, 1008, 13, 'SYED ADIL AKHTE', '-', 36, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:50:38'),
(1465, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 25, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1466, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 26, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1467, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 27, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1468, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 28, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1469, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 29, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1470, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 30, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1471, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 31, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1472, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 32, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1473, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 33, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1474, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 34, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1475, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 35, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1476, 1, 1, 985, 13, 'HUZAIFA BABA', '-', 36, '1750', '0', '940', '810', '', 1, '2019-02-06 07:51:03'),
(1477, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 25, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1478, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 26, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1479, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 27, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1480, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 28, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1481, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 29, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1482, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 30, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1483, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 31, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1484, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 32, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1485, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 33, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1486, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 34, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1487, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 35, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1488, 1, 1, 1005, 13, 'SHAIK MUHAMMAD SAAD ', '-', 36, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:51:31'),
(1489, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 25, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1490, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 26, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1491, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 27, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1492, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 28, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1493, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 29, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1494, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 30, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1495, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 31, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1496, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 32, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1497, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 33, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1498, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 34, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1499, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 35, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1500, 1, 1, 943, 13, 'ALFIA HAQUE', '-', 36, '1750', '0', '350', '1400', '', 1, '2019-02-06 07:52:06'),
(1501, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 25, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1502, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 26, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1503, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 27, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1504, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 28, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1505, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 29, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1506, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 30, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1507, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 31, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1508, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 32, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1509, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 33, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1510, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 34, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1511, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 35, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1512, 1, 1, 948, 13, 'AYESHA AZMI ', '-', 36, '1750', '0', '530', '1220', '', 1, '2019-02-06 07:53:08'),
(1513, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1514, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1515, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1516, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1517, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1518, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1519, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1520, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1521, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1522, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1523, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1524, 1, 1, 966, 13, 'SHAIKH AQSAANAM', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:53:33'),
(1525, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 25, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1526, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 26, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1527, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 27, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1528, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 28, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1529, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 29, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1530, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 30, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1531, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 31, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1532, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 32, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1533, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 33, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1534, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 34, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1535, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 35, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1536, 1, 1, 954, 13, 'MANTASHA NIZAM', '-', 36, '1750', '0', '250', '1500', '', 1, '2019-02-06 07:53:58'),
(1537, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 25, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1538, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 26, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1539, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 27, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1540, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 28, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1541, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 29, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1542, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 30, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1543, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 31, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1544, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 32, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1545, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 33, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1546, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 34, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1547, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 35, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1548, 1, 1, 974, 13, 'ZAINAB LASKA', '-', 36, '1750', '0', '800', '950', '', 1, '2019-02-06 07:54:38'),
(1549, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 25, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1550, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 26, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1551, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 27, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1552, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 28, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1553, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 29, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1554, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 30, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1555, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 31, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1556, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 32, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1557, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 33, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1558, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 34, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1559, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 35, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1560, 1, 1, 944, 13, 'ALISHA SHAMS ', '-', 36, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:55:13'),
(1561, 1, 1, 961, 13, 'SADAF ALI', '-', 25, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1562, 1, 1, 961, 13, 'SADAF ALI', '-', 26, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1563, 1, 1, 961, 13, 'SADAF ALI', '-', 27, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1564, 1, 1, 961, 13, 'SADAF ALI', '-', 28, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1565, 1, 1, 961, 13, 'SADAF ALI', '-', 29, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1566, 1, 1, 961, 13, 'SADAF ALI', '-', 30, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1567, 1, 1, 961, 13, 'SADAF ALI', '-', 31, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1568, 1, 1, 961, 13, 'SADAF ALI', '-', 32, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1569, 1, 1, 961, 13, 'SADAF ALI', '-', 33, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1570, 1, 1, 961, 13, 'SADAF ALI', '-', 34, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1571, 1, 1, 961, 13, 'SADAF ALI', '-', 35, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1572, 1, 1, 961, 13, 'SADAF ALI', '-', 36, '1750', '0', '940', '810', '', 1, '2019-02-06 07:55:57'),
(1573, 1, 1, 942, 13, 'AIBA ASLAM', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1574, 1, 1, 942, 13, 'AIBA ASLAM', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1575, 1, 1, 942, 13, 'AIBA ASLAM', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1576, 1, 1, 942, 13, 'AIBA ASLAM', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1577, 1, 1, 942, 13, 'AIBA ASLAM', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1578, 1, 1, 942, 13, 'AIBA ASLAM', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1579, 1, 1, 942, 13, 'AIBA ASLAM', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1580, 1, 1, 942, 13, 'AIBA ASLAM', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1581, 1, 1, 942, 13, 'AIBA ASLAM', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1582, 1, 1, 942, 13, 'AIBA ASLAM', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1583, 1, 1, 942, 13, 'AIBA ASLAM', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1584, 1, 1, 942, 13, 'AIBA ASLAM', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:28'),
(1585, 1, 1, 950, 13, 'HIBA ASLAM', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1586, 1, 1, 950, 13, 'HIBA ASLAM', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1587, 1, 1, 950, 13, 'HIBA ASLAM', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1588, 1, 1, 950, 13, 'HIBA ASLAM', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1589, 1, 1, 950, 13, 'HIBA ASLAM', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1590, 1, 1, 950, 13, 'HIBA ASLAM', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1591, 1, 1, 950, 13, 'HIBA ASLAM', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1592, 1, 1, 950, 13, 'HIBA ASLAM', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1593, 1, 1, 950, 13, 'HIBA ASLAM', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1594, 1, 1, 950, 13, 'HIBA ASLAM', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1595, 1, 1, 950, 13, 'HIBA ASLAM', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1596, 1, 1, 950, 13, 'HIBA ASLAM', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:56:55'),
(1597, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1598, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1599, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1600, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1601, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1602, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1603, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1604, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1605, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1606, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1607, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1608, 1, 1, 1050, 14, 'MD ADEEB EQUBAL', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 07:57:26'),
(1609, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 25, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1610, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 26, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1611, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 27, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1612, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 28, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1613, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 29, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1614, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 30, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1615, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 31, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1616, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 32, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1617, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 33, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1618, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 34, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1619, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 35, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1620, 1, 1, 1062, 14, 'MD OSAID MISBAH', '-', 36, '1750', '0', '300', '1450', '', 1, '2019-02-06 07:57:45'),
(1621, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 25, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1622, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 26, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1623, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 27, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1624, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 28, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1625, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 29, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1626, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 30, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1627, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 31, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1628, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 32, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1629, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 33, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1630, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 34, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1631, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 35, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1632, 1, 1, 1061, 14, 'MD MUSA-AL-SHAHNAWAZ', '-', 36, '1750', '0', '200', '1550', '', 1, '2019-02-06 07:58:13'),
(1633, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 25, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1634, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 26, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1635, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 27, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1636, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 28, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1637, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 29, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1638, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 30, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1639, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 31, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1640, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 32, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1641, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 33, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1642, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 34, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1643, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 35, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1644, 1, 1, 1048, 14, 'HUZEFA ZUBAI', '-', 36, '1750', '0', '380', '1370', '', 1, '2019-02-06 07:59:21'),
(1645, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 25, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1646, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 26, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1647, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 27, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1648, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 28, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1649, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 29, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1650, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 30, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1651, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 31, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1652, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 32, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1653, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 33, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1654, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 34, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1655, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 35, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1656, 1, 1, 1049, 14, 'MD AAZIB SHAMIM', '-', 36, '1750', '0', '550', '1200', '', 1, '2019-02-06 07:59:49'),
(1657, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 25, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1658, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 26, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1659, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 27, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1660, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 28, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1661, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 29, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1662, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 30, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1663, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 31, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1664, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 32, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1665, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 33, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1666, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 34, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1667, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 35, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1668, 1, 1, 1076, 14, 'MD WAQQAS ZAHID', '-', 36, '1750', '0', '550', '1200', '', 1, '2019-02-06 08:00:23'),
(1669, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 25, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1670, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 26, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1671, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 27, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1672, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 28, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1673, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 29, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1674, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 30, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1675, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 31, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1676, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 32, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1677, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 33, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1678, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 34, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1679, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 35, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1680, 1, 1, 1017, 14, 'AKSHA KHAN', '-', 36, '1750', '0', '350', '1400', '', 1, '2019-02-06 08:01:19'),
(1681, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 25, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1682, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 26, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1683, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 27, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1684, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 28, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1685, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 29, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1686, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 30, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1687, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 31, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1688, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 32, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1689, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 33, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1690, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 34, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1691, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 35, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46'),
(1692, 1, 1, 1025, 14, 'KULSOOM HAYAT', '-', 36, '1750', '0', '1340', '410', '', 1, '2019-02-06 08:01:46');

-- --------------------------------------------------------

--
-- Table structure for table `fees_group`
--

CREATE TABLE `fees_group` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `fees_type_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `is_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees_group`
--

INSERT INTO `fees_group` (`id`, `sid`, `fees_type_id`, `name`, `is_active`) VALUES
(1, 1, 1, 'Tuition Fees 2018-2019', 1);

-- --------------------------------------------------------

--
-- Table structure for table `fees_name`
--

CREATE TABLE `fees_name` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `academicid` int(11) DEFAULT NULL,
  `school_config_acadamic_id` int(11) DEFAULT NULL,
  `fees_type_id` int(11) DEFAULT NULL,
  `fees_group_id` int(11) DEFAULT NULL,
  `term_setting_id` int(11) DEFAULT NULL,
  `month` varchar(200) DEFAULT NULL,
  `due_date` int(11) NOT NULL,
  `class` varchar(200) DEFAULT NULL,
  `fees_amount` varchar(100) DEFAULT NULL,
  `late_fees_amount` varchar(20) NOT NULL,
  `remarks` text,
  `is_active` int(11) NOT NULL,
  `fees_name` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees_name`
--

INSERT INTO `fees_name` (`id`, `sid`, `academicid`, `school_config_acadamic_id`, `fees_type_id`, `fees_group_id`, `term_setting_id`, `month`, `due_date`, `class`, `fees_amount`, `late_fees_amount`, `remarks`, `is_active`, `fees_name`) VALUES
(1, 1, 1, 1, 1, 1, NULL, '4', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(2, 1, 1, 1, 1, 1, NULL, '5', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(3, 1, 1, 1, 1, 1, NULL, '6', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(4, 1, 1, 1, 1, 1, NULL, '7', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(5, 1, 1, 1, 1, 1, NULL, '8', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(6, 1, 1, 1, 1, 1, NULL, '9', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(7, 1, 1, 1, 1, 1, NULL, '10', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(8, 1, 1, 1, 1, 1, NULL, '11', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(9, 1, 1, 1, 1, 1, NULL, '12', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(10, 1, 1, 1, 1, 1, NULL, '1', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(11, 1, 1, 1, 1, 1, NULL, '2', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(12, 1, 1, 1, 1, 1, NULL, '3', 5, '1,2,3,4,5', '1620', '50', '', 1, 'Monthly Fees'),
(13, 1, 1, 1, 1, 1, NULL, '4', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(14, 1, 1, 1, 1, 1, NULL, '5', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(15, 1, 1, 1, 1, 1, NULL, '6', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(16, 1, 1, 1, 1, 1, NULL, '7', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(17, 1, 1, 1, 1, 1, NULL, '8', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(18, 1, 1, 1, 1, 1, NULL, '9', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(19, 1, 1, 1, 1, 1, NULL, '10', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(20, 1, 1, 1, 1, 1, NULL, '11', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(21, 1, 1, 1, 1, 1, NULL, '12', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(22, 1, 1, 1, 1, 1, NULL, '1', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(23, 1, 1, 1, 1, 1, NULL, '2', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(24, 1, 1, 1, 1, 1, NULL, '3', 5, '15,16,6,7,8', '1720', '50', '', 1, 'Monthly Fees'),
(25, 1, 1, 1, 1, 1, NULL, '4', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(26, 1, 1, 1, 1, 1, NULL, '5', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(27, 1, 1, 1, 1, 1, NULL, '6', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(28, 1, 1, 1, 1, 1, NULL, '7', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(29, 1, 1, 1, 1, 1, NULL, '8', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(30, 1, 1, 1, 1, 1, NULL, '9', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(31, 1, 1, 1, 1, 1, NULL, '10', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(32, 1, 1, 1, 1, 1, NULL, '11', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(33, 1, 1, 1, 1, 1, NULL, '12', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(34, 1, 1, 1, 1, NULL, NULL, '1', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(35, 1, 1, 1, 1, NULL, NULL, '2', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(36, 1, 1, 1, 1, NULL, NULL, '3', 5, '9,10,11,12,13,14', '1750', '50', '', 1, 'Monthly Fees'),
(37, 1, 1, 1, 1, 1, NULL, '', 0, '1,2,3,4,5,15,16,6,7,8,9,10,11,12,13,14', '100', '', '', 1, 'ID card fees'),
(38, 1, 1, 1, 1, 1, NULL, '', 0, '1,2,3,4,5,15,16,6,7,8,9,10,11,12,13,14', '200', '', '', 1, 'Diary fees'),
(39, 1, 1, 1, 1, 1, NULL, '', 0, '1,2,3,4,5,15,16,6,7,8,9,10,11,12,13,14', '2000', '', '', 1, 'Hifz Adm'),
(40, 1, 1, 1, 1, 1, NULL, '', 0, '1,2,3,4,5,15,16,6,7,8,9,10,11,12,13,14', '300', '', '', 1, 'Hifz fees'),
(41, 1, 1, 1, 1, 1, NULL, '', 0, '1,2,3,4,5,15,16,6,7,8,9,10,11,12,13,14', '100', '', '', 1, 'Fees Book'),
(42, 1, 1, 1, 1, 1, NULL, '', 0, '1,2', '26000', '', '', 1, 'Admission Fees'),
(43, 1, 1, 1, 1, 1, NULL, '', 0, '3,4,5', '27000', '', '', 1, 'Admission Fees'),
(44, 1, 1, 1, 1, 1, NULL, '', 0, '15,16', '28000', '', '', 1, 'Admission Fees'),
(45, 1, 1, 1, 1, 1, NULL, '', 0, '6,7,8', '30000', '', '', 1, 'Admission Fees'),
(46, 1, 1, 1, 1, 1, NULL, '', 0, '9,10', '32000', '', '', 1, 'Admission Fees'),
(47, 1, 1, 1, 1, 1, NULL, '', 0, '11,12', '53000', '', '', 1, 'Admission Fees'),
(48, 1, 1, 1, 1, 1, NULL, '', 0, '13', '54000', '', '', 1, 'Admission Fees'),
(49, 1, 1, 1, 1, 1, NULL, '', 0, '14', '55000', '', '', 1, 'Admission Fees'),
(50, 1, 1, 1, 1, 1, NULL, '', 0, '1,2', '5750', '', '', 1, 'Session Fees'),
(51, 1, 1, 1, 1, 1, NULL, '', 0, '3,4,5,15,16,6,7,8,9,10,11,12,13,14', '6000', '', '', 1, 'Session Fees');

-- --------------------------------------------------------

--
-- Table structure for table `fees_type`
--

CREATE TABLE `fees_type` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` text NOT NULL,
  `is_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees_type`
--

INSERT INTO `fees_type` (`id`, `sid`, `name`, `is_active`) VALUES
(1, 1, 'Tuition Fees 2018-2019', 1);

-- --------------------------------------------------------

--
-- Table structure for table `frbl_banner`
--

CREATE TABLE `frbl_banner` (
  `id` int(11) NOT NULL,
  `bannerimage` text COLLATE utf8_unicode_ci NOT NULL,
  `propertytype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `area` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bedrooms` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bathrooms` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `available` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `full_atten`
--

CREATE TABLE `full_atten` (
  `id` int(11) NOT NULL,
  `admission_id` text NOT NULL,
  `date` varchar(100) NOT NULL,
  `class_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `images` text NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `groupname`
--

CREATE TABLE `groupname` (
  `gr_id` int(11) NOT NULL,
  `groupname` varchar(100) NOT NULL,
  `class_id` longtext NOT NULL,
  `stuname` varchar(100) NOT NULL,
  `sid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `home_works`
--

CREATE TABLE `home_works` (
  `id` int(11) UNSIGNED NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `home_work` text NOT NULL,
  `sms_sent` tinyint(1) NOT NULL DEFAULT '0',
  `updated_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `home_date` date NOT NULL,
  `homework_sms_type` int(11) NOT NULL COMMENT '0 - Single SMS Box, 1 -  Subject wise SMS Box',
  `sms_content` varchar(255) DEFAULT NULL,
  `sms_count` int(11) NOT NULL DEFAULT '0',
  `sms_delivery_count` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hostel_manage`
--

CREATE TABLE `hostel_manage` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `hostel_type_id` int(11) NOT NULL,
  `school_config_section_id` varchar(500) NOT NULL,
  `warden_name` varchar(100) NOT NULL,
  `total_room` varchar(100) NOT NULL,
  `note` varchar(500) NOT NULL,
  `hostel_name` varchar(100) NOT NULL,
  `Designation_code` varchar(50) NOT NULL,
  `warden_full_name` varchar(150) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hostel_room`
--

CREATE TABLE `hostel_room` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `hostel_type_id` int(11) NOT NULL,
  `hostel_manage_id` int(11) NOT NULL,
  `roomno` varchar(50) NOT NULL,
  `bed` varchar(50) NOT NULL,
  `rent` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hostel_room_allocation`
--

CREATE TABLE `hostel_room_allocation` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `hostel_type_id` int(11) NOT NULL,
  `hostel_manage_id` int(11) NOT NULL,
  `hostel_room_id` int(11) NOT NULL,
  `room_no` varchar(50) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hostel_type`
--

CREATE TABLE `hostel_type` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_item_master`
--

CREATE TABLE `inventory_item_master` (
  `id` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `stock` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_supplier_master`
--

CREATE TABLE `inventory_supplier_master` (
  `id` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `address` varchar(3000) NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `mobile_no` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE `issue` (
  `s_id` varchar(50) NOT NULL,
  `b_id` int(11) NOT NULL,
  `date` text NOT NULL,
  `val` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE `leaves` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `fromdate` date NOT NULL,
  `todate` date NOT NULL,
  `subject` varchar(100) NOT NULL,
  `reason` text NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `created_date` date NOT NULL,
  `status` int(11) NOT NULL COMMENT '1-Approved,0-Pending,2-Rejected'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `leave_app_his`
--

CREATE TABLE `leave_app_his` (
  `id` int(12) NOT NULL,
  `from_date` varchar(100) NOT NULL,
  `to_date` varchar(100) NOT NULL,
  `staff_name` varchar(100) NOT NULL,
  `emp_code` varchar(100) NOT NULL,
  `l_type` varchar(100) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1-Approved,0-Pending,2-Rejected',
  `sId` int(11) NOT NULL,
  `purpose` text NOT NULL,
  `remarks` text NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `leave_dect`
--

CREATE TABLE `leave_dect` (
  `id` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `desig_id` varchar(100) NOT NULL,
  `percent` varchar(100) NOT NULL,
  `amt` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `leave_name`
--

CREATE TABLE `leave_name` (
  `id` int(11) NOT NULL,
  `leave_name` varchar(100) NOT NULL,
  `allow_per_month` varchar(100) NOT NULL,
  `sId` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lesson_boards`
--

CREATE TABLE `lesson_boards` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `fields_name` text NOT NULL COMMENT 'lesson activity dynamic fields with , seprator',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_periods` int(11) NOT NULL,
  `days_of_week` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lesson_board_activity`
--

CREATE TABLE `lesson_board_activity` (
  `id` int(11) NOT NULL,
  `lesson_board_id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `description` text NOT NULL,
  `attachments` text NOT NULL COMMENT '1 - has attachment, 0 - no attachment',
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lesson_board_activity_list`
--

CREATE TABLE `lesson_board_activity_list` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `lesson_board_id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `school_subject_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `period_id` int(11) NOT NULL,
  `description` text NOT NULL COMMENT 'lesson plan description',
  `fields_name_description` text NOT NULL COMMENT 'Dynamic fields_name with Description merged here',
  `attachments` text NOT NULL,
  `planstatus` varchar(50) NOT NULL,
  `comments` text NOT NULL,
  `postponed` date NOT NULL,
  `duplicate_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `end_date` datetime NOT NULL COMMENT 'Completed status updates date',
  `request_access` int(11) NOT NULL COMMENT 'ask permission to edit',
  `admin_access` int(11) NOT NULL COMMENT 'Extra access to Proceed Edit Status',
  `admin_access_date` datetime NOT NULL COMMENT 'Date - Extra access to Proceed Edit Status',
  `share_status` int(11) NOT NULL COMMENT '1 - shared to others',
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lesson_board_config`
--

CREATE TABLE `lesson_board_config` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `fields_name` text NOT NULL COMMENT 'lesson activity dynamic fields with , seprator',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_periods` int(11) NOT NULL,
  `days_of_week` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lesson_board_config`
--

INSERT INTO `lesson_board_config` (`id`, `sid`, `fields_name`, `start_date`, `end_date`, `total_periods`, `days_of_week`, `status`, `created`, `modified`) VALUES
(1, 1, 'homework,activity,assignment', '2018-06-01', '2019-05-31', 8, 'Monday,Tuesday,Wednesday,Thursday,Friday', 1, '2018-07-08 10:21:14', '2018-07-08 10:21:14');

-- --------------------------------------------------------

--
-- Table structure for table `libraray_book_issue`
--

CREATE TABLE `libraray_book_issue` (
  `id` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `class_id` varchar(255) NOT NULL,
  `stu_id` varchar(255) NOT NULL,
  `book_id` varchar(255) NOT NULL,
  `issue_date` varchar(255) NOT NULL,
  `due_date` varchar(255) NOT NULL,
  `return_date` varchar(255) NOT NULL,
  `return` int(11) NOT NULL,
  `sub_id` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `libraray_new_book`
--

CREATE TABLE `libraray_new_book` (
  `id` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `book_no` varchar(255) NOT NULL,
  `book_isbn` varchar(255) NOT NULL,
  `book_name` varchar(255) NOT NULL,
  `book_author` varchar(255) NOT NULL,
  `book_subject` varchar(255) NOT NULL,
  `book_publisher` varchar(255) NOT NULL,
  `book_edition` varchar(255) NOT NULL,
  `book_year` varchar(255) NOT NULL,
  `book_page` varchar(255) NOT NULL,
  `book_volume` varchar(255) NOT NULL,
  `book_rackno` varchar(255) NOT NULL,
  `book_cost` varchar(255) NOT NULL,
  `book_count` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `libraray_rules`
--

CREATE TABLE `libraray_rules` (
  `id` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `rules` varchar(700) NOT NULL,
  `class_section` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `libraray_subject`
--

CREATE TABLE `libraray_subject` (
  `hId` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loan_mgmt`
--

CREATE TABLE `loan_mgmt` (
  `id` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `staff_name` varchar(100) NOT NULL,
  `desig` varchar(100) NOT NULL,
  `scode` varchar(100) NOT NULL,
  `l_type` varchar(100) NOT NULL,
  `l_amt` varchar(100) NOT NULL,
  `appli_date` varchar(100) NOT NULL,
  `app_date` varchar(100) NOT NULL,
  `loan_app` varchar(100) NOT NULL,
  `emi_amt` varchar(100) NOT NULL,
  `emi_str_mont` varchar(100) NOT NULL,
  `pur_loan` varchar(100) NOT NULL,
  `app_by` varchar(100) NOT NULL,
  `ref_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loan_trans`
--

CREATE TABLE `loan_trans` (
  `id` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `desig` varchar(100) NOT NULL,
  `staff_name` varchar(100) NOT NULL,
  `ref_no` varchar(100) NOT NULL,
  `p_date` varchar(100) NOT NULL,
  `p_amt` varchar(100) NOT NULL,
  `c_bal` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `l_bal` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `manage_timing`
--

CREATE TABLE `manage_timing` (
  `id` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `class_id` varchar(255) NOT NULL,
  `day` varchar(255) NOT NULL,
  `subject_id` varchar(255) NOT NULL,
  `designation_id` varchar(255) NOT NULL,
  `staff_id` varchar(255) NOT NULL,
  `subject_name_module` varchar(255) NOT NULL,
  `start_hour` varchar(255) NOT NULL,
  `start_minute` varchar(255) NOT NULL,
  `end_hour` varchar(255) NOT NULL,
  `end_minute` varchar(255) NOT NULL,
  `start_period` varchar(255) NOT NULL,
  `end_period` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `classname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL,
  `message` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `minute`
--

CREATE TABLE `minute` (
  `id` int(11) NOT NULL,
  `minute` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `month_setting`
--

CREATE TABLE `month_setting` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `fees_type_id` int(11) NOT NULL,
  `month` varchar(150) NOT NULL,
  `due_date` date DEFAULT NULL,
  `is_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `new_home_works`
--

CREATE TABLE `new_home_works` (
  `home_work_id` bigint(11) UNSIGNED NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_section` int(11) NOT NULL,
  `home_work` text NOT NULL,
  `sms_sent` tinyint(1) NOT NULL DEFAULT '0',
  `updated_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `home_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `notification_type_id` int(11) NOT NULL,
  `users_type` enum('all','teacher','student','parent','admin') NOT NULL,
  `unread` int(11) NOT NULL COMMENT '1 - unread, 0 - read',
  `message` text NOT NULL,
  `student_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `showall` int(11) NOT NULL COMMENT '0 - no, 1 - display to all type users',
  `url` varchar(255) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notification_types`
--

CREATE TABLE `notification_types` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 - hidden, 1 - shown',
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `old_leaveform`
--

CREATE TABLE `old_leaveform` (
  `id` int(11) NOT NULL,
  `fromdate` varchar(50) NOT NULL,
  `todate` varchar(50) NOT NULL,
  `classname` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `reason` varchar(850) NOT NULL,
  `stu_name` varchar(50) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `created_date` date NOT NULL,
  `admi_id` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `paymentplan`
--

CREATE TABLE `paymentplan` (
  `pId` int(11) NOT NULL,
  `pName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paymentplan`
--

INSERT INTO `paymentplan` (`pId`, `pName`) VALUES
(1, 'Economic Plan'),
(2, 'Deleuxe Plan'),
(3, 'Premium Plan');

-- --------------------------------------------------------

--
-- Table structure for table `period`
--

CREATE TABLE `period` (
  `id` int(11) NOT NULL,
  `period` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `periods`
--

CREATE TABLE `periods` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `lesson_board_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `start_time` varchar(20) NOT NULL,
  `end_time` varchar(20) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `quickabse_class`
--

CREATE TABLE `quickabse_class` (
  `id` int(11) NOT NULL,
  `todate` date NOT NULL,
  `class` int(11) NOT NULL,
  `classall` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quickabse_class`
--

INSERT INTO `quickabse_class` (`id`, `todate`, `class`, `classall`) VALUES
(1, '2017-06-21', 0, 'All');

-- --------------------------------------------------------

--
-- Table structure for table `quick_absent`
--

CREATE TABLE `quick_absent` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `classid` int(11) NOT NULL,
  `class` varchar(100) NOT NULL,
  `absent` varchar(100) NOT NULL,
  `ab_permi` varchar(100) NOT NULL,
  `delay` varchar(100) NOT NULL,
  `excu_delay` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(10) NOT NULL,
  `total_votes` int(5) NOT NULL DEFAULT '0',
  `total_value` int(5) NOT NULL DEFAULT '0',
  `used_ips` longtext NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `receipt_no`
--

CREATE TABLE `receipt_no` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `fees_type_id` int(11) NOT NULL,
  `fees_group_id` int(11) NOT NULL,
  `receipt_no_type` varchar(50) NOT NULL,
  `auto_start_no` varchar(50) DEFAULT NULL,
  `receipt_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reportcard_logs`
--

CREATE TABLE `reportcard_logs` (
  `id` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `exam_detail_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `cron_status` int(11) NOT NULL,
  `url` varchar(200) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reportcard_settings`
--

CREATE TABLE `reportcard_settings` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `disp_classname` varchar(255) NOT NULL,
  `disp_examname` varchar(255) NOT NULL,
  `disp_year` varchar(20) NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `school_logo_path` text NOT NULL,
  `header_row_settings` varchar(255) NOT NULL,
  `signature_settings` varchar(100) NOT NULL,
  `teacher_settings` varchar(100) NOT NULL,
  `high_mark_settings` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reportcard_settings`
--

INSERT INTO `reportcard_settings` (`id`, `sid`, `section_id`, `exam_id`, `disp_classname`, `disp_examname`, `disp_year`, `school_name`, `school_logo_path`, `header_row_settings`, `signature_settings`, `teacher_settings`, `high_mark_settings`) VALUES
(1, 1, 107, 2, 'XII - A', 'Monthly Revision Test', '2017-2018', 'WElcome Notes School', 'uploads/reportcard_logo/schoollogoseba.jpg', '2,3,4', '2', '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `reportentry`
--

CREATE TABLE `reportentry` (
  `id` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `examId` int(11) NOT NULL,
  `stuId` int(11) NOT NULL,
  `reportId` int(11) NOT NULL,
  `report` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `report_field`
--

CREATE TABLE `report_field` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `report_field` varchar(255) NOT NULL,
  `class_section` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `status`, `created`) VALUES
(1, 'HOD', 1, '2018-05-25 00:00:00'),
(2, 'Manager/Admin', 1, '2018-05-25 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `roles_settings`
--

CREATE TABLE `roles_settings` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL COMMENT 'head_staff_profile_id',
  `staff_profile_id_list` text NOT NULL COMMENT 'List of Staff - can access by this user',
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sal_day_set`
--

CREATE TABLE `sal_day_set` (
  `id` int(11) NOT NULL,
  `sal_day` varchar(100) NOT NULL,
  `loan_view` varchar(100) NOT NULL,
  `sId` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_admission`
--

CREATE TABLE `school_admission` (
  `admi_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `sWebsite` text NOT NULL,
  `app_no` varchar(255) NOT NULL,
  `stu_name` varchar(255) NOT NULL,
  `aBirth` varchar(50) NOT NULL,
  `age` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `app_relation` varchar(255) NOT NULL,
  `app_rel_dis` varchar(255) NOT NULL,
  `app_rel_name` varchar(255) NOT NULL,
  `app_curr_school_name` varchar(255) NOT NULL,
  `current_class` varchar(255) NOT NULL,
  `income_year` varchar(255) NOT NULL,
  `join_class_section` varchar(255) NOT NULL,
  `admission_no` varchar(255) NOT NULL,
  `roll_no` varchar(255) NOT NULL,
  `app_status` varchar(255) NOT NULL,
  `app_offer_specific` varchar(255) NOT NULL,
  `app_remark` text NOT NULL,
  `name_of_parent` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `name_of_mother` varchar(255) NOT NULL,
  `mother_occupation` varchar(50) NOT NULL,
  `street_address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `pincode` text NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `home_phone` varchar(255) NOT NULL,
  `mobile_phone` varchar(255) NOT NULL,
  `business_phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `medical_problem` text NOT NULL,
  `medical_need` text NOT NULL,
  `medical_allergies` text NOT NULL,
  `food_allergies` text NOT NULL,
  `blood_group` varchar(255) NOT NULL,
  `medical_other_info` text NOT NULL,
  `class_teacher_name` varchar(255) NOT NULL,
  `other_subject_name` varchar(255) NOT NULL,
  `other_teacher_name` varchar(255) NOT NULL,
  `is_staff_child` varchar(255) NOT NULL,
  `student_category_id` int(11) NOT NULL,
  `school_bus` varchar(255) NOT NULL,
  `house_name` varchar(255) NOT NULL,
  `chome_phone` varchar(50) NOT NULL,
  `ccell_phone` varchar(50) NOT NULL,
  `cbusiness_phone` varchar(50) NOT NULL,
  `csms` varchar(50) NOT NULL,
  `cemail` varchar(50) NOT NULL,
  `communication_prefernce` varchar(888) NOT NULL,
  `ickup_child` varchar(255) NOT NULL,
  `emergency_contact` varchar(255) NOT NULL,
  `feesdate` varchar(255) NOT NULL,
  `feesyear` varchar(255) NOT NULL,
  `feename` varchar(255) NOT NULL,
  `totfeesamt` varchar(255) NOT NULL,
  `feespaidamt` varchar(255) NOT NULL,
  `feesbalanceamt` varchar(255) NOT NULL,
  `challan` text NOT NULL,
  `studentphoto` text NOT NULL,
  `student_type` varchar(50) NOT NULL DEFAULT 'admission',
  `suser` varchar(70) NOT NULL,
  `spass` varchar(70) NOT NULL,
  `date` varchar(250) NOT NULL,
  `dob_words` varchar(250) NOT NULL,
  `nat_state` varchar(250) NOT NULL,
  `religion` varchar(250) NOT NULL,
  `caste` varchar(250) NOT NULL,
  `subcaste` int(11) NOT NULL,
  `ter_convert` varchar(250) NOT NULL,
  `annual_income` varchar(250) NOT NULL,
  `name_of_guardian` varchar(250) NOT NULL,
  `gurd_occup` varchar(250) NOT NULL,
  `gurd_address_phone` varchar(250) NOT NULL,
  `gurd_annual_income` varchar(250) NOT NULL,
  `bro_sis_studying` varchar(250) NOT NULL,
  `tc_elmentry_leaving` varchar(250) NOT NULL,
  `mother_tongue` varchar(250) NOT NULL,
  `lang_proposed` varchar(250) NOT NULL,
  `previous_schl_hsrty` varchar(250) NOT NULL,
  `identi_marks` varchar(250) NOT NULL,
  `authored` varchar(100) NOT NULL,
  `miss_no` varchar(100) NOT NULL,
  `allocation` varchar(100) NOT NULL,
  `mis_set` text NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `allowed` int(11) NOT NULL,
  `allowed_usage` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_admission`
--

INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(1, 1, '', '', 'ADEEBAH IFAN', '2012-01-10', '', 'FEMALE', '', '', '', '', '', '', '1', '1531', '1531', '', '', '', 'MD IFAN AHMED', '', 'AZOO IFAN', '', '61/B, G.J.KHAN OAD, KOLKATA - 700039', '', '', '', '', '', '9661124201', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9661124201', '9661124201', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(2, 1, '', '', 'AFIFA FATIMA', '2012-03-01', '', 'FEMALE', '', '', '', '', '', '', '1', '1538', '1538', '', '', '', 'MD EHSANUDDIN', '', 'SHABNAM AKHTE', '', '9M, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '9123370365', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9123370365', '9123370365', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(3, 1, '', '', 'AFIFA KHATOON', '2011-06-28', '', 'FEMALE', '', '', '', '', '', '', '1', '1622', '1622', '', '', '', 'SK SHABBI', '', 'JASMIN BEGAM', '', '32B, MIAJAN OSTAGA LANE, KAAYA, KOLKATA-700017', '', '', '', '', '', '9330570224', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330570224', '9330570224', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(4, 1, '', '', 'AIZAH AHI', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1588', '1588', '', '', '', 'ASIF IQBAL', '', 'SAMEEN ALI', '', 'SHAHNI MANZIL. 5, CEMATOIUM STEET, KOL - 14', '', '', '', '', '', '9830081306', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830081306', '9830081306', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(5, 1, '', '', 'ALIZA TANWEE', '2011-10-01', '', 'FEMALE', '', '', '', '', '', '', '1', '1605', '1605', '', '', '', 'TANWEE IQBAL', '', 'AAISHA PAVEEN', '', '4A,G.J.KHAN OAD AL-HAYAT ESIDENCY KOL-39', '', '', '', '', '', '9831984433', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831984433', '9831984433', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(6, 1, '', '', 'AEEBA KAUSE', '2019-02-06', '', 'FEMALE', '', '', '', '', '', '', '1', '1632', '1632', '', '', '', 'SHOAIB AKHTE', '', 'SEEMA KAUSE', '', '2/L, DILKHUSHA STEET, KOL - 17', '', '', '', '', '', '9830387995', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830387995', '9830387995', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(7, 1, '', '', 'ASEEL SAWA', '2012-01-30', '', 'FEMALE', '', '', '', '', '', '', '1', '1534', '1534', '', '', '', 'MOHAMMAD SAWA ALI', '', 'ASMA\'A ANSA', '', 'B/26/1/H/1, BIGHT STEET, KOLKATA - 700017 (PHULWAI SHAIF, PATNA)', '', '', '', '', '', '9102063086', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9102063086', '9102063086', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(8, 1, '', '', 'AYAT MAHTAB', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1663', '1663', '', '', '', 'MAHTAB ALAM', '', 'SHABANA MAHTAB', '', '19, MCLEOD STEET KOL-17', '', '', '', '', '', '9903838509', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903838509', '9903838509', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(9, 1, '', '', 'AYESHA PAVEEN', '2012-01-19', '', 'FEMALE', '', '', '', '', '', '', '1', '1532', '1532', '', '', '', 'MD MANZU KHAN', '', 'ASHIYA PAVEEN', '', '13/1, MAHENDA OY LANE, KOLKATA - 700046', '', '', '', '', '', '8420425959', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420425959', '8420425959', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(10, 1, '', '', 'FAIZA KHAN', '2011-06-25', '', 'FEMALE', '', '', '', '', '', '', '1', '1628', '1628', '', '', '', 'MD.ZAFA IQBAL', '', 'SEEAT FATMA', '', '61/1L/2, TOPSIA OAD KOL-39', '', '', '', '', '', '7890392161', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890392161', '7890392161', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(11, 1, '', '', 'IFA SHAMSAD', '2012-03-01', '', 'FEMALE', '', '', '', '', '', '', '1', '1545', '1545', '', '', '', 'MD SHAMSAD ALAM', '', 'SABA PAWEEN', '', 'GULSHAN COLONY. 4TH FLOO. I/A, WEST CHOWBAGHA, NEA AUTO STAND, KOLKATA - 700100', '', '', '', '', '', '9836606561', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836606561', '9836606561', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(12, 1, '', '', 'INAAYA ADIL', '2012-03-09', '', 'FEMALE', '', '', '', '', '', '', '1', '1560', '1560', '', '', '', 'MD ADIL EZA', '', 'JABEEN ADIL', '', '4TH FLOO. FLAT NO. 4D. 15/A/1, GOLAM ZILANI KHAN OAD, KOLKATA 700039', '', '', '', '', '', '8847867748', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8847867748', '8847867748', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(13, 1, '', '', 'KEENZA FIOZ', '2011-05-25', '', 'FEMALE', '', '', '', '', '', '', '1', '1651', '1651', '', '', '', 'MD.FIOZ ALAM', '', 'AJUMAND AFEEN', '', '22C, LINTON STEET KOL-14', '', '', '', '', '', '9830430098', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830430098', '9830430098', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(14, 1, '', '', 'LAIQUA ALAM', '2011-04-13', '', 'FEMALE', '', '', '', '', '', '', '1', '1638', '1638', '', '', '', 'EJAZ ALAM', '', 'ZEENAT ALAM', '', '202, AJ.C BOSE OAD KOL-17', '', '', '', '', '', '9330889529', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330889529', '9330889529', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(15, 1, '', '', 'MANTASHA AHMED', '2011-05-03', '', 'FEMALE', '', '', '', '', '', '', '1', '1646', '1646', '', '', '', 'SAMI AHMED', '', 'EHANA ALI', '', '38/1H/2, SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '9007277826', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007277826', '9007277826', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(16, 1, '', '', 'NAIYAA SULTAN', '2011-09-24', '', 'FEMALE', '', '', '', '', '', '', '1', '1540', '1540', '', '', '', 'MD SULTAN', '', 'DAAKSHA NOOI', '', 'GULSHAN COLONY. 2ND FLOO. E/6, WEST CHOWBAGHA, NEA AUTO STAND, KOLKATA - 700100', '', '', '', '', '', '8240088076', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240088076', '8240088076', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(17, 1, '', '', 'NAMIA MAYAM', '2011-02-06', '', 'FEMALE', '', '', '', '', '', '', '1', '1686', '1686', '', '', '', 'MD.KHALID MISBAH', '', 'NASEEN JAHAN', '', '19/D, SI SYED AHMED OAD KOL-14', '', '', '', '', '', '9681127815', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681127815', '9681127815', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(18, 1, '', '', 'AZIA AHMED', '2011-03-14', '', 'FEMALE', '', '', '', '', '', '', '1', '1684', '1684', '', '', '', 'MD.SHABBI AHMED', '', 'NAZNIN PAWEEN', '', '84 A/2 TOPSIA OAD KOL-39', '', '', '', '', '', '9163988345', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163988345', '9163988345', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(19, 1, '', '', 'OZY PAVEEN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1594', '1594', '', '', '', 'MD INAM', '', 'UNE PAVEN', '', '11/B, TILJALA SHIBTALA LANE. KOLKATA - 700039', '', '', '', '', '', '8017320601', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8017320601', '8017320601', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(20, 1, '', '', 'SAA EKAM', '2011-09-08', '', 'FEMALE', '', '', '', '', '', '', '1', '1596', '1596', '', '', '', 'EKAM ALAM', '', 'KHUSBU ALAM', '', '12/2, TOPSIA 2ND LANE ,2ND FLOO KOL-39', '', '', '', '', '', '8961787606', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8961787606', '8961787606', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(21, 1, '', '', 'SAAH SOHAIL', '2011-11-24', '', 'FEMALE', '', '', '', '', '', '', '1', '1600', '1600', '', '', '', 'MD.SOHAIL AKHTE', '', 'KAHKUSHAN SOHAIL', '', '24, IFLE ANGE OAD KOL-19', '', '', '', '', '', '9051784583', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9051784583', '9051784583', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(22, 1, '', '', 'SHAFA AMIN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1647', '1647', '', '', '', 'MD AMINUDDIN', '', 'SAIKA PAVEEN', '', '62, LINTON STEET, KOL - 14', '', '', '', '', '', '9831387562', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831387562', '9831387562', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(23, 1, '', '', 'SHAIKA KHAN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1574', '1574', '', '', '', 'MD ZAFFA KHAN', '', 'SHAISTA NAAZ', '', '6/B, TILJALA LANE, KOL - 39', '', '', '', '', '', '9007907522', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007907522', '9007907522', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(24, 1, '', '', 'SHIFA HAYAT KALAM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1581', '1581', '', '', '', 'ABDUL KALAM', '', 'HENA KHALID', '', '33G, TOPSIA OAD, KOL - 39', '', '', '', '', '', '8420047472', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420047472', '8420047472', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(25, 1, '', '', 'SHIZA SAMI', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1656', '1656', '', '', '', 'MD SAMI', '', 'SABA PAVEEN', '', '7/H/7, JANNAGA OAD, KOL-17', '', '', '', '', '', '9681149894', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681149894', '9681149894', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(26, 1, '', '', 'SHIZA SHAHNAWAZ', '2011-04-10', '', 'FEMALE', '', '', '', '', '', '', '1', '1554', '1554', '', '', '', 'SHAHNAWAZ ALAM', '', 'BILKIS NASIM', '', '16, DAMZEN LANE, KOLKATA - 700073', '', '', '', '', '', '9123340191', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9123340191', '9123340191', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(27, 1, '', '', 'SIDA AZIM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1648', '1648', '', '', '', 'MD AZIMUDDIN', '', 'SAFINA KHATOON', '', '62, LINTON STEET, KOL - 14', '', '', '', '', '', '9804745290', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9804745290', '9804745290', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(28, 1, '', '', 'SUMAIA FATMA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1606', '1606', '', '', '', 'MD SAJID', '', 'NOO FATMA', '', '9, G J KHAN OAD, BLOCK A, 2ND FLOO, KOL-39', '', '', '', '', '', '9831235336', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831235336', '9831235336', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(29, 1, '', '', 'SUMAYTA NOUSHEEN', '2012-02-26', '', 'FEMALE', '', '', '', '', '', '', '1', '1626', '1626', '', '', '', 'SABI ALI MOLLAH', '', 'SALMA PAVIN', '', 'B12/1, LA BLOCK. SECTO III, SALT LAKE, KOL-98', '', '', '', '', '', '9477477498', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9477477498', '9477477498', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(30, 1, '', '', 'TAIBA HASSAIN', '1970-01-01', '', 'FEMALE', '', '', '', '', '', '', '1', '1533', '1533', '', '', '', 'AFTAB HASSAIN', '', 'SHAHEEN BEGUM', '', '24, PALM AVENUE, KOLKATA - 700019', '', '', '', '', '', '8100151932', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100151932', '8100151932', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(31, 1, '', '', 'UMME OMAAN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1643', '1643', '', '', '', 'SK JAHANGI EZA', '', 'DAAKSHAN AKHTE', '', '40B, BIGHT STEET, KOL - 17', '', '', '', '', '', '7439244262', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7439244262', '7439244262', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(32, 1, '', '', 'ZAFEEA QAMA', '2011-07-12', '', 'FEMALE', '', '', '', '', '', '', '1', '1587', '1587', '', '', '', 'SHAMS QAMA', '', 'MAHJABEEN BANO', '', '7/H/1 HATI BAGAN OAD KOL-14', '', '', '', '', '', '9062144228', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062144228', '9062144228', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(33, 1, '', '', 'ZAAFSHA KHATOON', '2011-08-30', '', 'FEMALE', '', '', '', '', '', '', '1', '1539', '1539', '', '', '', 'MD SHABBI HUSSAIN', '', 'ZAINAB KHATOON', '', '5/, SAPGACHI FIST LANE, KOLKATA - 700039', '', '', '', '', '', '9123628439', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9123628439', '9123628439', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(34, 1, '', '', 'ZAUBIA NASIM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1575', '1575', '', '', '', 'NASIM AHMED', '', 'MAYSA KHATOON', '', '9/F, TOPSIA OAD, KOL - 39', '', '', '', '', '', '7003008112', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003008112', '7003008112', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(35, 1, '', '', 'ZOYA AFIQUE', '2011-03-10', '', 'FEMALE', '', '', '', '', '', '', '1', '1544', '1544', '', '', '', 'MD AFIQUE', '', 'ZEENAT PAVEEN', '', '43B, GOLAM JILANI KHAN OAD, TILJALA, KOLKATA - 700039', '', '', '', '', '', '9163686377', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163686377', '9163686377', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(36, 1, '', '', 'AIMA ASHAF', '2012-02-07', '', 'FEMALE', '', '', '', '', '', '', '1', '1681', '1681', '', '', '', 'ASHAF ALI', '', 'AALIYA ALI', '', '36D/8B, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '9748806104', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748806104', '9748806104', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(37, 1, '', '', 'AQUIBA KHATOON', '2012-03-10', '', 'FEMALE', '', '', '', '', '', '', '1', '1683', '1683', '', '', '', 'ABDU AHMAN', '', 'EHANA KHATOON', '', '15H/3, B.F.OW, P.S: EKBALPOE, KOLKATA - 700027', '', '', '', '', '', '9433090965', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9433090965', '9433090965', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(38, 1, '', '', 'TUBA TAUHEED', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1624', '1624', '', '', '', 'MD TAUHEED', '', 'FAAHANA KHATUN', '', '16, SAPGACHI 1ST LANE, KOLKATA - 39', '', '', '', '', '', '7439281116', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7439281116', '7439281116', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(39, 1, '', '', 'AFEEN PAVEEN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1671', '1671', '', '', '', 'MD AFTAB ALAM', '', 'NAGIS PAVEEN', '', '17/11, TOPSIA OAD, BANSBAGAN, KOL - 39', '', '', '', '', '', '9903011882', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903011882', '9903011882', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(40, 1, '', '', 'AABIA AA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1584', '1584', '', '', '', 'MD ASHIF', '', 'SHABNAM BEGUM', '', '6/2/H/1, K.B 1st LANE. NAKELDANGA KOLKATA - 700011', '', '', '', '', '', '9830938091', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830938091', '9830938091', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(41, 1, '', '', 'SADIQUA WASIM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1694', '1694', '', '', '', 'MD WASIM', '', 'NAHID FIDOUS', '', '110/H/8, ELLIOT OAD, KOL-16', '', '', '', '', '', '9831720871', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831720871', '9831720871', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(42, 1, '', '', 'TASMIA MUSALEEN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1696', '1696', '', '', '', 'MD MUSALEEN', '', 'AHMAT KHUSHNASEEB', '', 'BLOCK C. FLAT 5. 62D, TOSIA OAD, KOLKATA - 39', '', '', '', '', '', '9903352120', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903352120', '9903352120', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(43, 1, '', '', 'ZUNAIAH S. QUAISHI', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '1', '1607', '1607', '', '', '', 'MOHAMMED SHAHBUDDIN', '', 'SHAHEEN PAVEEN', '', '25B,SHAMSUL HUDA OAD FLAT 15 A, SUFIA COUT, KOLKATA-700017', '', '', '', '', '', '9819818288', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9819818288', '9819818288', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(44, 1, '', '', 'ADIBA ISLAM', '2012-04-11', '', 'FEMALE', '', '', '', '', '', '', '1', '1711', '1711', '', '', '', 'NUUL ISLAM', '', 'KAMUN NESSA', '', '17B, TANTI BAGAN LANE, KOLKATA - 700014\n13/H/34, BAUNFELD OW, KOLKATA - 700027', '', '', '', '', '', '8274917263', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8274917263', '8274917263', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(45, 1, '', '', 'SUMAYYA MAHMOOD', '2012-05-01', '', 'FEMALE', '', '', '', '', '', '', '1', '1712', '1712', '', '', '', 'MOHAMMAD MAHMOOD ALAM', '', 'MAHJABIN MAHMOOD', '', 'TILJALA LANE, BESIDE EGAL NUSING HOME, KOLKATA - 700019', '', '', '', '', '', '7323004885', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7323004885', '7323004885', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(46, 1, '', '', 'AAIZ SOLANKI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1660', '1660', '', '', '', 'MD AFZAL SOLANKI', 'ANJUM SOLANKI', 'ANJUM SOLANKI', '', '1/1C, EKBALPOE OAD, KOL - 23', '', '', '', '', '', '9830410099', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830410099', '9830410099', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(47, 1, '', '', 'ABDUL MUHAYMIN HAFIZ', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1667', '1667', '', '', '', 'SK.HAFIZUDDIN', 'AFAT HAFIZ', 'AFAT HAFIZ', '', '25, C.N.OY OAD, KOLKATA - 700039', '', '', '', '', '', '9903819348', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903819348', '9903819348', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(48, 1, '', '', 'ABDULLAH HASIM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1571', '1571', '', '', '', 'MD HASIM', 'NILOFE', 'NILOFE', '', '61/12/14, TOPSIA OAD, KOL-39', '', '', '', '', '', '9748920456', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748920456', '9748920456', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(49, 1, '', '', 'ABDU AHIM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1682', '1682', '', '', '', 'ANZA AHMED', 'NIKHAT AHMED', 'NIKHAT AHMED', '', '45/1B SHAMSUL HUDA OAD, KOL - 17', '', '', '', '', '', '9433302855', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9433302855', '9433302855', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(50, 1, '', '', 'ABU HUAIA ANSAI', '2011-06-28', '', 'MALE', '', '', '', '', '', '', '1', '1609', '1609', '', '', '', 'IMAN ALI ANSAI', 'MEHUN NEHA', 'MEHUN NEHA', '', '8/1, HASHI STEET KOL-9', '', '', '', '', '', '9831633484', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831633484', '9831633484', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(51, 1, '', '', 'ABU SHAHMA AMANAT', '2011-04-19', '', 'MALE', '', '', '', '', '', '', '1', '1567', '1567', '', '', '', 'AMANAT ALI', 'NAAZ BANO', 'NAAZ BANO', '', '1, SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '9831896323', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831896323', '9831896323', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(52, 1, '', '', 'AHAAN KABI', '2011-06-12', '', 'MALE', '', '', '', '', '', '', '1', '1636', '1636', '', '', '', 'KABIUZZAMAN ASUL', 'FATIMA KABI', 'FATIMA KABI', '', '64,TILJALA OAD KOL-39', '', '', '', '', '', '9831981604', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831981604', '9831981604', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(53, 1, '', '', 'AYAAN HOSSAIN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1613', '1613', '', '', '', 'NAUSHAD ALAM', 'SHAHJAHAN BEGUM', 'SHAHJAHAN BEGUM', '', '38/1/HY/3, SAMSUL HUDA OAD, KOLKATA - 17', '', '', '', '', '', '8777737469', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8777737469', '8777737469', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(54, 1, '', '', 'BILAL IMAN', '2011-01-29', '', 'MALE', '', '', '', '', '', '', '1', '1661', '1661', '', '', '', 'IMAN ASHID', 'SUBIA IMAN', 'SUBIA IMAN', '', '187, PAK STEET KOL - 17', '', '', '', '', '', '8100461161', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100461161', '8100461161', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(55, 1, '', '', 'FADHEEL AMAN ANSAI', '2011-09-28', '', 'MALE', '', '', '', '', '', '', '1', '1689', '1689', '', '', '', 'MD NEMATULLAH ANSAI', 'AKHTAI BEGUM', 'AKHTAI BEGUM', '', '6, JANNAGA OAD, EID GAH GALI, KOL- 17', '', '', '', '', '', '9831240901', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831240901', '9831240901', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(56, 1, '', '', 'HAMDAN NASIM', '2011-03-14', '', 'MALE', '', '', '', '', '', '', '1', '1635', '1635', '', '', '', 'SHAHNAWAZ NASIM', 'SHAGUFTA NISHAT AYYUBI', 'SHAGUFTA NISHAT AYYUBI', '', '16, SI SYEED AHMED OAD KOL-14', '', '', '', '', '', '9674061561', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674061561', '9674061561', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(57, 1, '', '', 'MD ANAS ALI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1637', '1637', '', '', '', 'MD ASGA ALI', 'NOO SABA', 'NOO SABA', '', '6B, KUSTIA OAD KOLKATA - 700039', '', '', '', '', '', '9831937217', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831937217', '9831937217', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(58, 1, '', '', 'MD AYAAN SHAMIM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1591', '1591', '', '', '', 'SHAMIM SHAFI', 'ESHMA PAVEEN', 'ESHMA PAVEEN', '', '48, MCLEOD STEET, KOL - 17', '', '', '', '', '', '7980120003', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980120003', '7980120003', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(59, 1, '', '', 'MD AYAN AHMED', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1679', '1679', '', '', '', 'PAWEZ AHMED', 'TAHEA BEGUM', 'TAHEA BEGUM', '', '15A, IPON STEET, KOLKATA - 16', '', '', '', '', '', '9830129586', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830129586', '9830129586', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(60, 1, '', '', 'MD FAHAAN SHAHNAWAZ', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1666', '1666', '', '', '', 'MD SHAHNAWAZ', 'FAIDA KHATOON', 'FAIDA KHATOON', '', '4/1B, CONVENT LANE, KOLKATA - 15', '', '', '', '', '', '7278606203', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7278606203', '7278606203', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(61, 1, '', '', 'MD FAISH LODHI', '', '', 'MALE', '', '', '', '', '', '', '1', '1627', '1627', '', '', '', 'MD FAHAN LODHI', 'SHABIN LODHI', 'SHABIN LODHI', '', '1A/2, TILJALA SHIBTALA LANE, KOL-39', '', '', '', '', '', '7980511139', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980511139', '7980511139', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(62, 1, '', '', 'MD FUZAIL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1695', '1695', '', '', '', 'MD SAIF', 'AFOZA TASMIN', 'AFOZA TASMIN', '', 'HAQUE COMPLEX.  BLOCK C, 3D FLOO, FLAT NO. 4. 62D, TOPSIA OAD, KOL - 39', '', '', '', '', '', '7003644243', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003644243', '7003644243', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(63, 1, '', '', 'MD HAMZAH', '2011-06-18', '', 'MALE', '', '', '', '', '', '', '1', '1593', '1593', '', '', '', 'MD.MUSTAKIM', 'AYESHA BANO', 'AYESHA BANO', '', '16/A, BIGHT STEET KOL-17', '', '', '', '', '', '9831196592', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831196592', '9831196592', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(64, 1, '', '', 'MD HOSSAIN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1578', '1578', '', '', '', 'MD WASHIM', 'AZIA SULTANA', 'AZIA SULTANA', '', '1/1A H/2, KAVI MD IQBAL OAD, KOL - 23', '', '', '', '', '', '9007452311', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007452311', '9007452311', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(65, 1, '', '', 'MD JAAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1640', '1640', '', '', '', 'MD SHABBI ALAM', 'ISA ZAEEN', 'ISA ZAEEN', '', '13/D, CHAMO KHAN SAMA LANE. KOLKATA-700017', '', '', '', '', '', '9831283091', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831283091', '9831283091', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(66, 1, '', '', 'MD SALEH SABI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1672', '1672', '', '', '', 'MD SABI', 'SUMAIYA SABI', 'SUMAIYA SABI', '', '2A, D BIESH GUHA STEET, KOL - 17', '', '', '', '', '', '9831538553', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831538553', '9831538553', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(67, 1, '', '', 'MD SALIK', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1589', '1589', '', '', '', 'MD ABID', 'NASIMA ABID', 'NASIMA ABID', '', '18, CHAMU KHANSAMA LANE, KOL - 17', '', '', '', '', '', '6290159383', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '6290159383', '6290159383', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(68, 1, '', '', 'MD SAYEM ALI', '2011-04-08', '', 'MALE', '', '', '', '', '', '', '1', '1673', '1673', '', '', '', 'TAHI HUSSAIN', 'AJIA PAVEEN', 'AJIA PAVEEN', '', '15/H/4, BIBI BAGAN LANE KOL-15', '', '', '', '', '', '9883686994', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883686994', '9883686994', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(69, 1, '', '', 'MD SHAHEE ALAM', '2011-10-29', '', 'MALE', '', '', '', '', '', '', '1', '1586', '1586', '', '', '', 'MD SHAMIM ALAM', 'SALEHA KHATOON', 'SALEHA KHATOON', '', '8/B, G J KHAN OAD, KOL - 39', '', '', '', '', '', '8274801275', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8274801275', '8274801275', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(70, 1, '', '', 'MD SHEEZAN ALI', '2011-10-25', '', 'MALE', '', '', '', '', '', '', '1', '1602', '1602', '', '', '', 'ALI ASLAM', 'SHAKA PAVEEN', 'SHAKA PAVEEN', '', '2H, TILJALA LANE, KOL - 19', '', '', '', '', '', '8820112533', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8820112533', '8820112533', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(71, 1, '', '', 'MD WAZID', '2011-05-20', '', 'MALE', '', '', '', '', '', '', '1', '1608', '1608', '', '', '', 'MD.SAJID', 'UKSHA AA', 'UKSHA AA', '', '7/1 H, TOPSIA LANE  ( ABINASH CHOWDHUY LANE ) KOL-46', '', '', '', '', '', '9836148661', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836148661', '9836148661', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(72, 1, '', '', 'MD ZAYAN TANVI', '2011-07-29', '', 'MALE', '', '', '', '', '', '', '1', '1634', '1634', '', '', '', 'TANVI YOUSUF', 'NIKHAT PAVEEN', 'NIKHAT PAVEEN', '', 'H/4/8/3, AHII PUKU 1ST LANE KOL-19', '', '', '', '', '', '9831290524', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831290524', '9831290524', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(73, 1, '', '', 'MD. MUZAMMIL AZAZ', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1570', '1570', '', '', '', 'MD AZAZ', 'TAANNUM JAHAN', 'TAANNUM JAHAN', '', 'AIHAYAT ESIDENCY. 4A, G J KHAN OAD, KOL-39', '', '', '', '', '', '9831449151', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831449151', '9831449151', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(74, 1, '', '', 'MOHAMMAD AMMA ALI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1604', '1604', '', '', '', 'MD WAQUA DANISH', 'ZOYA SEEMEEN', 'ZOYA SEEMEEN', '', '14 B, KAAYA OAD KOL-17', '', '', '', '', '', '9831312172', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831312172', '9831312172', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(75, 1, '', '', 'MOHAMMED INSHAL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '1', '1693', '1693', '', '', '', 'MD IFANULLAH', 'ATIYA IFAN', 'ATIYA IFAN', '', '6/14, KUSTIA OAD, 3D FLOO, KOLKATA - 39', '', '', '', '', '', '9007333233', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007333233', '9007333233', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(76, 1, '', '', 'OMA SHAHID', '2012-08-28', '', 'MALE', '', '', '', '', '', '', '1', '1585', '1585', '', '', '', 'MD SHAHID AKHTE', 'KAHKASHAN NEELUFE', 'KAHKASHAN NEELUFE', '', 'G.J.KHAN OAD TOPSIA KOLKATA-7000039', '', '', '', '', '', '9986418606', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9986418606', '9986418606', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(77, 1, '', '', 'S.M.ABUZA ASHAD', '2010-04-02', '', 'MALE', '', '', '', '', '', '', '1', '1678', '1678', '', '', '', 'S.M. ASHAD', 'MEHUN NISSA', 'MEHUN NISSA', '', '6/2/H, AHII PUKU 1ST LANE KOL - 19', '', '', '', '', '', '8420498621', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420498621', '8420498621', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(78, 1, '', '', 'SK FAHAN ALI', '2012-02-12', '', 'MALE', '', '', '', '', '', '', '1', '1662', '1662', '', '', '', 'SK.HAIDE ALI', 'FATEMA ZOHA', 'FATEMA ZOHA', '', '10, CHOWBAGA OAD KOL-39', '', '', '', '', '', '9748665555', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748665555', '9748665555', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(79, 1, '', '', 'SK SAIFUL ISLAM', '2011-07-16', '', 'MALE', '', '', '', '', '', '', '1', '1541', '1541', '', '', '', 'SAHIDUL ISLAM', 'SABANA BEGAM', 'SABANA BEGAM', '', '19C/2, TILJALA SHIBTALA LANE, KOLKATA - 700039', '', '', '', '', '', '9831755869', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831755869', '9831755869', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(80, 1, '', '', 'SYED MOHAMMAD USHAAN QUADI', '2009-09-08', '', 'MALE', '', '', '', '', '', '', '1', '1595', '1595', '', '', '', 'SYED MOHAMMAD QUADI', 'SYEDA SHAZMA QUADI', 'SYEDA SHAZMA QUADI', '', '1ST FLOO 3 GEEN PAK KOL-19', '', '', '', '', '', '9830613404', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830613404', '9830613404', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(81, 1, '', '', 'AAFIN MANSOO', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1598', '1598', '', '', '', 'MANSOO ALAM', '', 'FAZANA YASMIN', '', '42, TOPSIA OAD, KOL-39', '', '', '', '', '', '9051914739', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9051914739', '9051914739', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(82, 1, '', '', 'AALIYA KALAM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1568', '1568', '', '', '', 'MD KALAMUDDIN', '', 'SHAMIMA KHATOON', '', '16, KUSTIA MASJID BAI LANE,TOPSIA, KOLKATA-700039', '', '', '', '', '', '9831260342', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831260342', '9831260342', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(83, 1, '', '', 'AFSHA IZWAN', '2012-05-26', '', 'FEMALE', '', '', '', '', '', '', '2', '1629', '1629', '', '', '', 'MD IZWAN', '', 'NASHEEN JAHAN', '', '170/H/30, KESHAB CHANDA SEN STEET, KOLKATA - 700009 ', '', '', '', '', '', '9831590640', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831590640', '9831590640', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(84, 1, '', '', 'AIMAN SAFAAZ', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1614', '1614', '', '', '', 'SAFAAZ ALAM', '', 'IZWANA KHATOON', '', '7/2A, MIAJAAN OSTAGE LANE, KOLKATA - 17', '', '', '', '', '', '9051047816', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9051047816', '9051047816', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(85, 1, '', '', 'ALIA HAQUE', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1631', '1631', '', '', '', 'ZIAUL HAQUE', '', 'FIDAUS PAVEEN', '', '7/1/H/5, GAS STEET. KOLKATA-700009', 'AAFIN MANSOO', '11.09.11', '', '', '', '9330954536', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330954536', '9330954536', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(86, 1, '', '', 'ALIFA HUSSAIN ', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1659', '1659', '', '', '', 'KABI HUSSAIN', '', 'KAINAT KHANAM', '', '35, ALIMUDDIN STEET. KOLKATA-700016', 'AALIYA KALAM', '15.03.12', '', '', '', '9903632305', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903632305', '9903632305', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(87, 1, '', '', 'ALIZA AYAT KHAN', '2011-11-30', '', 'FEMALE', '', '', '', '', '', '', '2', '1619', '1619', '', '', '', 'HAIDE KHAN', '', 'SHABNAM KHAN', '', '11, BIBI BAGAN LANE (TANGA) KOLKATA-700015', 'AFSHA IZWAN', '26.05.12', '', '', '', '8981593607', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8981593607', '8981593607', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(88, 1, '', '', 'AQLIMA ASAFI', '2011-11-28', '', 'FEMALE', '', '', '', '', '', '', '2', '1685', '1685', '', '', '', 'MD EHTESHAMUDDIN', '', 'NUZHAT BANO', '', '25/1/9, TOPSIA OAD, KOLKATA-700039', 'AIMAN SAFAAZ', '20.02.12', '', '', '', '9831719134', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831719134', '9831719134', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(89, 1, '', '', 'AQSA KHAN', '2011-05-27', '', 'FEMALE', '', '', '', '', '', '', '2', '1658', '1658', '', '', '', 'SHADAB KHAN', '', 'AYESHA SHAMIM', '', '8/3 MOMINPU OAD KOLKATA-700023', 'ALIA HAQUE', '22.03.12', '', '', '', '9748582199', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748582199', '9748582199', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(90, 1, '', '', 'AISHA FATMA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1616', '1616', '', '', '', 'IMTEYAZ AHMED', '', 'IFFAT AA', '', '31A, M O LANE, KOL - 17', 'ALIFA HUSSAIN ', '08.06.11', '', '', '', '9831348959', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831348959', '9831348959', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(91, 1, '', '', 'AYESHA SIDDIQUA', '2011-12-28', '', 'FEMALE', '', '', '', '', '', '', '2', '1617', '1617', '', '', '', 'ABDUL SAMAD', '', 'SAJIDA SIDDIQUI', '', '17/12, TOPSIA OAD. KOLKATA-700039', 'ALIZA AYAT KHAN', '30.11.11', '', '', '', '9933475540', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9933475540', '9933475540', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(92, 1, '', '', 'BUSHA ELAHI', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1642', '1642', '', '', '', 'MD IFANULLAH', '', 'NAZIA PAWEEN', '', '20B, D BIESH GUHA STEET, KOL - 17', 'AQLIMA ASAFI', '28.11.11', '', '', '', '9748626314', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748626314', '9748626314', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(93, 1, '', '', 'EEAM NASIM', '2019-02-06', '', 'FEMALE', '', '', '', '', '', '', '2', '1633', '1633', '', '', '', 'MD NASIM', '', 'AYESHA SK', '', '53/14A, TILJALA OAD. KOLKATA - 700039', 'AQSA KHAN', '27.05.11', '', '', '', '9681774551', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681774551', '9681774551', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(94, 1, '', '', 'HABIBA ELAHI', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1644', '1644', '', '', '', 'MD IMANULLAH', '', 'AZIZAH KHATOON', '', '20B, D BIESH GUHA STEET, KOL - 17', 'AISHA FATMA', '20.01.12', '', '', '', '9831867452', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831867452', '9831867452', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(95, 1, '', '', 'HUMAIAH AFEEN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1625', '1625', '', '', '', 'FAIZ ASDUL AFIN', '', 'KANIZ FATIMAH', '', '29/A/2, G.J.KHAN OAD. KOLKATA-700039', 'AYESHA SIDDIQUA', '28.12.11', '', '', '', '8757546040', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8757546040', '8757546040', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(96, 1, '', '', 'INAYA SAYED', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1597', '1597', '', '', '', 'PAVEZ ALAM', '', 'FAHA PAVEZ', '', '153, PAK STEET KOLKATA-700017', 'BUSHA ELAHI', '15.11.11', '', '', '', '7007690451', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7007690451', '7007690451', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(97, 1, '', '', 'ISA SHADAB', '2011-02-28', '', 'FEMALE', '', '', '', '', '', '', '2', '1569', '1569', '', '', '', 'MD SHADAB AHMANI', '', 'FALAK NAAZ', '', 'BL-C. F-3. FL-1. 59C, GOLAM JILANI KHAN OAD, LP-68/16/5, KOLKATA - 700039', 'EEAM NASIM', '24.12.11', '', '', '', '9836756378', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836756378', '9836756378', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(98, 1, '', '', 'KANIZ FATIMA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1573', '1573', '', '', '', 'MD MUSTAFA', '', 'KHADIJA KHATOON', '', '3, KASAI PAA LANE, PAK CICUS, KOL - 17', 'HABIBA ELAHI', '14.06.11', '', '', '', '7059269718', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7059269718', '7059269718', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(99, 1, '', '', 'MAIUM SHAFIQUE', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1677', '1677', '', '', '', 'MD.SHAFIQUE', '', 'NAGHMA SHAFIQUE', '', '49/1,TALTALA LANE KOLKATA-700016', 'HUMAIAH AFEEN', '05.07.11', '', '', '', '9339436531', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339436531', '9339436531', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(100, 1, '', '', 'MEHPAA AAMI', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1599', '1599', '', '', '', 'AMI MATIN', '', 'ZEBA PAWEEN', '', '6/2 M.M.ALI OAD KOLKATA-700023', 'INAYA SAYED', '10.02.12', '', '', '', '8240932101', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240932101', '8240932101', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(101, 1, '', '', 'NUAIN IMTIAZ', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1688', '1688', '', '', '', 'SM. IMTIAZ', '', 'NUSAT IMTIAZ', '', '9, NEW KASIA BAGAN LANE. KOLKATA - 700017', 'ISA SHADAB', '28.02.11', '', '', '', '9830646572', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830646572', '9830646572', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(102, 1, '', '', 'AFIA KHAZA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1680', '1680', '', '', '', 'MD KHALIL', '', 'MEHZABEEN BANO', '', '52, BECKBAGAN OW, KOL - 17', 'KANIZ FATIMA', '02.09.11', '', '', '', '9830930079', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830930079', '9830930079', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(103, 1, '', '', 'SADDAF ASHAD', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1576', '1576', '', '', '', 'ASHAD ALAM', '', 'JASMINA BEGUM', '', '11/A, ABHINASH CHOWDHUY LANE. KOLKATA - 700046', 'MAIUM SHAFIQUE', '14.08.11', '', '', '', '9830605503', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830605503', '9830605503', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(104, 1, '', '', 'SHABAH', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1583', '1583', '', '', '', 'SHAHUKH G. KHAN', '', 'AZNEEN S. KHAN', '', '9/H/3 MAHE ALI LANE TANGA KOLKATA - 700015', 'MEHPAA AAMI', '14.10.11', '', '', '', '9903438440', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903438440', '9903438440', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(105, 1, '', '', 'SUFIYA JAMAL', '2011-10-28', '', 'FEMALE', '', '', '', '', '', '', '2', '1630', '1630', '', '', '', 'SAFAAZ JAMAL', '', 'SANA FATMA', '', '2/L, TILJALA LANE, KOL - 19', 'NUAIN IMTIAZ', '20.01.12', '', '', '', '9883321161', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883321161', '9883321161', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(106, 1, '', '', 'SUFIYA PAVEEN', '2019-02-06', '', 'FEMALE', '', '', '', '', '', '', '2', '1610', '1610', '', '', '', 'MD IBAHIM', '', 'AUNAK PAVEEN', '', '2, KUSTIA MASJID BAI LANE. KOLKATA-700039', 'AFIA KHAZA', '07.08.11', '', '', '', '9831361357', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831361357', '9831361357', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(107, 1, '', '', 'SYEDA ABISH FAZAL', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1590', '1590', '', '', '', 'ISHTEYAQUE ALAM', '', 'SAMEEA WALI', '', '4, WALIULLAH LANE, KOL - 16', 'SADDAF ASHAD', '07.03.12', '', '', '', '8100013177', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100013177', '8100013177', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(108, 1, '', '', 'ZAMEEN HEYAT', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '2', '1654', '1654', '', '', '', 'NADIM HEYAT', '', 'SHAFAQUE HEYAT', '', '47/1/H/1, PHOOL BAGAN OAD, KOL - 14', 'SHABAH', '07.02.12', '', '', '', '9831253842', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831253842', '9831253842', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(109, 1, '', '', 'ANAS ANWA', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1611', '1611', '', '', '', 'MOHAMMAD ANWA', 'JUHI PAVEEN', 'JUHI PAVEEN', '', '297/1/H, A P C OAD, KOLKATA - 700009', 'SUFIYA JAMAL', '28.10.11', '', '', '', '8691226854', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8691226854', '8691226854', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(110, 1, '', '', 'AHAM ALAM', '2011-03-30', '', 'MALE', '', '', '', '', '', '', '2', '1592', '1592', '', '', '', 'SHOAIB ALAM', 'KHALDA NIKHAT PAVEEN', 'KHALDA NIKHAT PAVEEN', '', '13, KOMEDAN BAGAN LANE, KOLKATA-700016', 'SUFIYA PAVEEN', '24.11.11', '', '', '', '8583869901', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8583869901', '8583869901', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(111, 1, '', '', 'ASHIUDDIN AHMED', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1612', '1612', '', '', '', 'KAMALUDDIN AHMED', 'PAPIA AHMED', 'PAPIA AHMED', '', '4, MOMINPOE OAD. KOLKATA - 700023', 'SYEDA ABISH FAZAL', '11.10.11', '', '', '', '9830702309', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830702309', '9830702309', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(112, 1, '', '', 'ATIQ SYED', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1657', '1657', '', '', '', 'MOHAMMAD SAIYEED', 'KAHKASHA NAAZ', 'KAHKASHA NAAZ', '', '16F/1, C.N.OY OAD. KOLKATA-700039', 'ZAMEEN HEYAT', '16.09.11', '', '', '', '9831148179', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831148179', '9831148179', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(113, 1, '', '', 'ATTAU AHIM', '2012-03-18', '', 'MALE', '', '', '', '', '', '', '2', '1548', '1548', '', '', '', 'MD SHAHANNAWAZ', 'AZIA KHATOON', 'AZIA KHATOON', '', '2C/H/4, CHATU BABU LANE, KOLKATA - 700014', '', '', '', '', '', '9830781403', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830781403', '9830781403', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(114, 1, '', '', 'AZMATUDDIN KHAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1664', '1664', '', '', '', 'AZHAUDDIN KHAN', 'ZUBIA KHAN', 'ZUBIA KHAN', '', '26, AI CHAAN GHOSH LANE. KOLKATA-700039', '', '', '', '', '', '9681057656', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681057656', '9681057656', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(115, 1, '', '', 'ZUNAID ALAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1603', '1603', '', '', '', 'PAVEZ ALAM', 'SHAHIN PAVEEN', 'SHAHIN PAVEEN', '', '29/A/H-12, PALM AVENUE, KOLKATA - 700019', '', '', '', '', '', '8617280670', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8617280670', '8617280670', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(116, 1, '', '', 'MD ABDULLAH', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1668', '1668', '', '', '', 'MD YOUSUF', 'YUSA NOO', 'YUSA NOO', '', '87/1, IPON STEET. KOLKATA - 700016', '', '', '', '', '', '9681095239', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681095239', '9681095239', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(117, 1, '', '', 'MD AFFAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1655', '1655', '', '', '', 'MD FAIYAZ NASI', 'ZABA SHAHEEN', 'ZABA SHAHEEN', '', '37, TOPSIA OAD, SANSA APATMENT BLOCK 4th FLOO, KOLKATA-700039', '', '', '', '', '', '9903512476', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903512476', '9903512476', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(118, 1, '', '', 'MD AFZAL HUSSAIN', '2012-01-27', '', 'MALE', '', '', '', '', '', '', '2', '1572', '1572', '', '', '', 'MD SHAMIMUDDIN', 'NOOJAHAN KHATOON', 'NOOJAHAN KHATOON', '', '15/H/4, BIBI BAGAN LANE KOLKATA - 700015', '', '', '', '', '', '9831178244', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831178244', '9831178244', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(119, 1, '', '', 'MD AMAN HUSSAIN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1582', '1582', '', '', '', 'MD IMTIAZ HUSSAIN ', 'TABASSUM PAVEEN', 'TABASSUM PAVEEN', '', '297/1/H/5, A.P.C.OAD KOLKATA-700009', '', '', '', '', '', '9903177106', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903177106', '9903177106', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(120, 1, '', '', 'MD AQUIB', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1650', '1650', '', '', '', 'ALAMGI', 'KHUSBOO PAVEEN', 'KHUSBOO PAVEEN', '', '6B, G J KHAN OAD, 2ND FLOO, KOL - 39', '', '', '', '', '', '7980136511', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980136511', '7980136511', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(121, 1, '', '', 'MD ASHIF', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1687', '1687', '', '', '', 'MD ABDUL WAHID', 'MS KH SULTANA', 'MS KH SULTANA', '', '28A, D BIESH GUHA STEET KOLKATA -700017', '', '', '', '', '', '8837059846', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8837059846', '8837059846', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(122, 1, '', '', 'MD ASHAF', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1690', '1690', '', '', '', 'JAMIL AHMED', 'SABENOO KHATOON', 'SABENOO KHATOON', '', '52,BECK BAGAN OW KOLKATA-700017', '', '', '', '', '', '9831354165', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831354165', '9831354165', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(123, 1, '', '', 'MD HASAN SAUD', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1601', '1601', '', '', '', 'MD SAUD', 'MS AKSHANDA SAUD', 'MS AKSHANDA SAUD', '', '36D/1E/2, TOPSIA OAD.(EAST) KOLKATA - 700039', '', '', '', '', '', '9038730496', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038730496', '9038730496', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(124, 1, '', '', 'MD HUSSAIN MEHEBAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1645', '1645', '', '', '', 'MD MEHEBAN SHEIK', 'NILOFE MEHEBAN', 'NILOFE MEHEBAN', '', '36D/1E/2, TOPSIA OAD.(EAST) KOLKATA - 700039', '', '', '', '', '', '9883612602', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883612602', '9883612602', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(125, 1, '', '', 'MD HUZAIFA ', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1623', '1623', '', '', '', 'LATE MD JAWED', 'NISHAT FATMA', 'NISHAT FATMA', '', 'WEST CHOWBAGA GULSAN COLONY AHMAT MANZIL. KOLKATA-700100', '', '', '', '', '', '7890060086', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890060086', '7890060086', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(126, 1, '', '', 'MD ISMAIL QUAISHI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1665', '1665', '', '', '', 'SK SHAZADA', 'FAHAT PAVEEN', 'FAHAT PAVEEN', '', '5, KASAI PAA LANE. KOLKATA - 700017', '', '', '', '', '', '8820219029', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8820219029', '8820219029', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(127, 1, '', '', 'MD NABEEL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1615', '1615', '', '', '', 'MD SHAKIL', 'SAMSHAD BEGUM', 'SAMSHAD BEGUM', '', '29/A/H/34, PALM AVENUE. KOLKATA-700019', '', '', '', '', '', '7003619138', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003619138', '7003619138', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(128, 1, '', '', 'MD SADIQUE AKHTA', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1692', '1692', '', '', '', 'MD SAJID AKHTA', 'TABASSUM AA', 'TABASSUM AA', '', '85/P, TOPSIA OAD, KOLKATA - 39', '', '', '', '', '', '7003191885', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003191885', '7003191885', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(129, 1, '', '', 'MD SAIFUL ISLAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1641', '1641', '', '', '', 'HAJI MD ISLAM', 'SAHAJAHAN KHATOON', 'SAHAJAHAN KHATOON', '', '6/A, CONVENT LANE, KOL - 15', '', '', '', '', '', '9903688456', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903688456', '9903688456', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(130, 1, '', '', 'MD ZAID AFIQUE', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1580', '1580', '', '', '', 'MD AFIQUE', 'AZOO TAMANNA', 'AZOO TAMANNA', '', '11B TILJALA SIBTALA LANE KOLKATA-700039', '', '', '', '', '', '7044141771', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7044141771', '7044141771', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(131, 1, '', '', 'MD. INAAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1675', '1675', '', '', '', 'MD. ISLAM', 'SHAHNAZ BEGUM', 'SHAHNAZ BEGUM', '', '147/1 P.G.OAD. KOLKATA - 700039', '', '', '', '', '', '9681554130', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681554130', '9681554130', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(132, 1, '', '', 'MD. AIYAAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1669', '1669', '', '', '', 'MD YOUSUF', 'YUSA NOO', 'YUSA NOO', '', '87/1, IPON STEET. KOLKATA - 700016', '', '', '', '', '', '9681095239', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681095239', '9681095239', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(133, 1, '', '', 'MOHAMMAD AQAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1621', '1621', '', '', '', 'MD AFFAQUE ALAM', 'MOBINA KHATOON', 'MOBINA KHATOON', '', '64B BACK BAGAN OW KOLKATA-700017', '', '', '', '', '', '8240658483', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240658483', '8240658483', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(134, 1, '', '', 'MUDASSI JAWED', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1674', '1674', '', '', '', 'ASFA JAWED', 'UKSANA SABEEN', 'UKSANA SABEEN', '', 'BAAUNI, BEGUSAAI BIHA - 851126', '', '', '', '', '', '9934862880', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9934862880', '9934862880', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(135, 1, '', '', 'MUDASSI AHMAN SIDDIQUE', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1577', '1577', '', '', '', 'MAHBOOB AHMAN', 'NIKHAT PAVEEN', 'NIKHAT PAVEEN', '', '4, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9123318981', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9123318981', '9123318981', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(136, 1, '', '', 'OBAID ALI', '2011-05-30', '', 'MALE', '', '', '', '', '', '', '2', '1649', '1649', '', '', '', 'NADEEM ALI', 'SAMIUN NISHA', 'SAMIUN NISHA', '', '15/2, TOPSIA 2nd LANE. KOLKATA - 700039', '', '', '', '', '', '9804835826', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9804835826', '9804835826', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(137, 1, '', '', 'AJAK AHMAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1618', '1618', '', '', '', 'HAFIZU AHMAN', 'SHABNAM BEGUM', 'SHABNAM BEGUM', '', '9/H/1 AJAB ALI LANE KOLKATA - 700023', '', '', '', '', '', '7439253723', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7439253723', '7439253723', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(138, 1, '', '', 'UQBANULLAH', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1698', '1698', '', '', '', 'MD.SAMI ALAM', 'ZAEEN KHATOON', 'ZAEEN KHATOON', '', '18,DAGAH OAD KOLKATA-700017', '', '', '', '', '', '9007491835', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007491835', '9007491835', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(139, 1, '', '', 'SAAQIB AHMED KHAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1691', '1691', '', '', '', 'MUJIBA AHMAN KHAN', 'SAHANAA BEGUM', 'SAHANAA BEGUM', '', '6/2, M.M.ALI OAD. KOLKATA-700023', '', '', '', '', '', '9831615661', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831615661', '9831615661', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(140, 1, '', '', 'SAFWAN AHMED', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1676', '1676', '', '', '', 'AZI AHMED', 'SHIEEN AHMED', 'SHIEEN AHMED', '', '147, JB, WEST CHOWBAGHA, KOLKATA - 700105', '', '', '', '', '', '9674999388', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674999388', '9674999388', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(141, 1, '', '', 'SHAYAAN ISHAD', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1564', '1564', '', '', '', 'ISHAD HOSSAIN', 'OSHNI BEGUM', 'OSHNI BEGUM', '', '25/1/2, TOPSIA OAD.KOLKATA - 700039', '', '', '', '', '', '9903522104', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903522104', '9903522104', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(142, 1, '', '', 'SK AYAAN SIDEQUE', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1620', '1620', '', '', '', 'SK. IMTYAZ', 'AFIA PAVEEN', 'AFIA PAVEEN', '', '66H/4, TILJALA MASJID BAI LANE. KOLKATA-700039', '', '', '', '', '', '9007727432', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007727432', '9007727432', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(143, 1, '', '', 'SK GOLAM HASSAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1670', '1670', '', '', '', 'SK GOLAM SABI', 'FEOZA BEGUM', 'FEOZA BEGUM', '', '16, BIGHT STEET KOLKATA - 700017', '', '', '', '', '', '9831694421', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831694421', '9831694421', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(144, 1, '', '', 'TAHA UZAI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1653', '1653', '', '', '', 'IMTIAZ ENAYAT', 'TAHEA KHATOON', 'TAHEA KHATOON', '', '54B, MOFIDUL ISLAM LANE. KOLKATA-700014', '', '', '', '', '', '9681898145', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681898145', '9681898145', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(145, 1, '', '', 'ZAID AHMED', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1639', '1639', '', '', '', 'SAGHI AHMED', 'ESHMA KHATOON', 'ESHMA KHATOON', '', '17, BECK BAGAN OW. KOLKATA - 700017', '', '', '', '', '', '9831447768', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831447768', '9831447768', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(146, 1, '', '', 'ASALAN WASI', '2011-04-04', '', 'MALE', '', '', '', '', '', '', '2', '1699', '1699', '', '', '', 'FAOOQUE WASI', 'SHAHINA WASI', 'SHAHINA WASI', '', '13/2/H/1, PATWA BAGAN LANE, KOLKATA - 700009', '', '', '', '', '', '9674937707', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674937707', '9674937707', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(147, 1, '', '', 'MD.ALMAS ALTAF', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '2', '1704', '1704', '', '', '', 'MD.ALTAF AHMED', 'FAZANA ALTAF', 'FAZANA ALTAF', '', '39/H/3, SHAMSUL HUDA OAD, KOLKATA - 700017', '', '', '', '', '', '9748622140', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748622140', '9748622140', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(148, 1, '', '', 'AABDA NAZI', '2010-07-03', '', 'FEMALE', '', '', '', '', '', '', '3', '1381', '1381', '', '', '', 'NAZI KHAN', '', 'KHAIUN NISHA', '', '37,KAAYA OAD KOL-17', '', '', '', '', '', '9831143278', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831143278', '9831143278', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(149, 1, '', '', 'AABIYA MOHAMMADI', '2010-06-22', '', 'FEMALE', '', '', '', '', '', '', '3', '1411', '1411', '', '', '', 'KHUAM SULTAN', '', 'MOFAZIA KHUAM', '', '2, SANDAL STEET 1ST FLOO KOL-16', '', '', '', '', '', '8420384794', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420384794', '8420384794', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(150, 1, '', '', 'ADEEBA SAQUIB', '2011-07-29', '', 'FEMALE', '', '', '', '', '', '', '3', '1404', '1404', '', '', '', 'MOHD SAQUIB', '', 'ENAYAT PEWEEN', '', '2B/H/55, GAS STEET, AJABAZA, KOL -11', '', '', '', '', '', '7044056022', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7044056022', '7044056022', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(151, 1, '', '', 'AFISHAM ALAM', '2010-10-24', '', 'FEMALE', '', '', '', '', '', '', '3', '1457', '1457', '', '', '', 'MD.ANIS ALAM', '', 'MUSAAT ANIS', '', '296/1/H/4/9, APC OAD KOL-9', '', '', '', '', '', '9143494482', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9143494482', '9143494482', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(152, 1, '', '', 'ALFEYA FATMA', '2010-06-11', '', 'FEMALE', '', '', '', '', '', '', '3', '1385', '1385', '', '', '', 'MD.FAHIM', '', 'KAHKASHA PAVEEN', '', '16/D,BECK BAGAN OW KOL-17', '', '', '', '', '', '9681376971', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681376971', '9681376971', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(153, 1, '', '', 'AMNA MAYAM ISMAIL', '2011-04-18', '', 'FEMALE', '', '', '', '', '', '', '3', '1481', '1481', '', '', '', 'ABDUL BASIT ISMAIL', '', 'FAZANA BASIT', '', '4,JANNAGA 2ND LANE KOL-14', '', '', '', '', '', '9831550593', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831550593', '9831550593', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(154, 1, '', '', 'AYESHA KALAM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '3', '1266', '1266', '', '', '', 'ABUL KALAM MONDAL', '', 'JAHANAA PAVEEN', '', '42/1B, SHAMSUL HUDA OAD. KOLKATA-700017', '', '', '', '', '', '9332032393', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9332032393', '9332032393', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(155, 1, '', '', 'AYESHA KHATOON', '2010-04-15', '', 'FEMALE', '', '', '', '', '', '', '3', '1382', '1382', '', '', '', 'MD.HASIB AHMED', '', 'SHABANA KHATOON', '', '15/H MIAJAN OSTAGA LANE KOL-17', '', '', '', '', '', '9830281798', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830281798', '9830281798', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(156, 1, '', '', 'HIBBA IQBAL', '2010-05-28', '', 'FEMALE', '', '', '', '', '', '', '3', '1433', '1433', '', '', '', 'MD. IQBAL', '', 'KAHKASHAN IQBAL', '', '39/1/H/4, SI SYED AHMED OAD,  KOL - 14', '', '', '', '', '', '9051564186', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9051564186', '9051564186', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(157, 1, '', '', 'HUMAIA JAMEEL', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '3', '1408', '1408', '', '', '', 'JAMEEL AHMED', '', 'SHAGUFTA PAVEEN', '', '71/2, TOPSIA OAD, KOL-39', '', '', '', '', '', '9330029339', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330029339', '9330029339', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(158, 1, '', '', 'IFA IFTEKA', '2010-07-13', '', 'FEMALE', '', '', '', '', '', '', '3', '1281', '1281', '', '', '', 'IFTEKA AHMED', '', 'MAHJABEEN KHATOON', '', 'P-2,39,B KIMBE STEET KOL-17', '', '', '', '', '', '8420775513', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420775513', '8420775513', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(159, 1, '', '', 'IMA WASI', '2010-10-08', '', 'FEMALE', '', '', '', '', '', '', '3', '1307', '1307', '', '', '', 'SHAMSAD ALAM', '', 'IAM NAAZ', '', '6. BANSI DUTTA OAD KOL - 14', '', '', '', '', '', '8100065808', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100065808', '8100065808', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(160, 1, '', '', 'INSHIAH IMAN', '2011-01-23', '', 'FEMALE', '', '', '', '', '', '', '3', '1448', '1448', '', '', '', 'MD.IMAN ', '', 'TAANA KHATOON', '', '40/A, MOFIDUL ISLAM LANE KOL-14', '', '', '', '', '', '9831693624', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831693624', '9831693624', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(161, 1, '', '', 'ISHNA HABIBA', '2010-10-16', '', 'FEMALE', '', '', '', '', '', '', '3', '1232', '1232', '', '', '', 'NAUSHAD ALAM', '', 'NAZIA PAWEEN', '', '458 G.T .OAD SHIBPU HOW-02', '', '', '', '', '', '9804999699', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9804999699', '9804999699', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(162, 1, '', '', 'MADEEHA AHI', '2011-03-24', '', 'FEMALE', '', '', '', '', '', '', '3', '1451', '1451', '', '', '', 'MD.MOIN', '', 'YAMEEN KHANAM', '', '17, NUULHA DOCTO LANE KOL-17', '', '', '', '', '', '9831786443', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831786443', '9831786443', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(163, 1, '', '', 'MAHAM OHIN KAMAL', '2010-05-22', '', 'FEMALE', '', '', '', '', '', '', '3', '1513', '1513', '', '', '', 'MD.AFI KAMAL', '', 'TAANNUM KAMAL', '', '18A, KUSTIA MASJIDBAI LANE KOL-39', '', '', '', '', '', '9748848511', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748848511', '9748848511', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(164, 1, '', '', 'MAYAM JAWED', '2011-04-25', '', 'FEMALE', '', '', '', '', '', '', '3', '1357', '1357', '', '', '', 'JAWED AKHTE', '', 'UHI TABASSUM', '', '85 H,TOPSIA OAD KOL-39', '', '', '', '', '', '9831073865', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831073865', '9831073865', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(165, 1, '', '', 'MAYAM QAIS', '2010-08-14', '', 'FEMALE', '', '', '', '', '', '', '3', '1406', '1406', '', '', '', 'QAIS AHMED', '', 'AFEEN AKHTE', '', '2E/3, CANTOPHE LANE, KOL - 14', '', '', '', '', '', '9830602286', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830602286', '9830602286', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(166, 1, '', '', 'MEHDIN MISBAH', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '3', '1379', '1379', '', '', '', 'JAWED AHMED', '', 'IZWANA BEGUM', '', '36/1, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9831895452', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831895452', '9831895452', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(167, 1, '', '', 'NAFISHA SULTANA', '2010-09-15', '', 'FEMALE', '', '', '', '', '', '', '3', '1337', '1337', '', '', '', 'MD.ZAHI ABBAS', '', 'JESMIN BEGUM', '', '14,B AHII PUKU 2ND LANE KOL-19', '', '', '', '', '', '9800060182', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9800060182', '9800060182', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(168, 1, '', '', 'NOO SIDDIQUA', '2011-04-15', '', 'FEMALE', '', '', '', '', '', '', '3', '1488', '1488', '', '', '', 'MD UMI', '', 'FAHAT JABEEN', '', '7/H/9 AHIIPUKU 2ND LANE BECK BAGAN KOL - 19', '', '', '', '', '', '9163034469', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163034469', '9163034469', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(169, 1, '', '', 'QUDSIAH NAAZ', '2010-04-13', '', 'FEMALE', '', '', '', '', '', '', '3', '1387', '1387', '', '', '', 'TANWEE EBADULLAH', '', 'NAZIA SULTANA', '', '13/3 MAHENDA OY LANE KOL-46', '', '', '', '', '', '9073758038', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9073758038', '9073758038', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(170, 1, '', '', 'AMEESHA SADAF', '2011-06-03', '', 'FEMALE', '', '', '', '', '', '', '3', '1233', '1233', '', '', '', 'ISHAD AHMED', '', 'SHAZIA SADAF', '', '214 G.T.OAD SHIBPU', '', '', '', '', '', '9831769959', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831769959', '9831769959', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(171, 1, '', '', 'SEHISH ZABEEN', '2010-10-26', '', 'FEMALE', '', '', '', '', '', '', '3', '1507', '1507', '', '', '', 'GULAM ABBANI', '', 'NAZANA KHATOON', '', 'VILL: KHEON. PO - BAGODIH, DIST: GIIDIH, JHAKHAND', '', '', '', '', '', '8961266290', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8961266290', '8961266290', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(172, 1, '', '', 'SUNDUSH MIDDEY', '2010-08-08', '', 'FEMALE', '', '', '', '', '', '', '3', '1276', '1276', '', '', '', 'MIDUL MUKASUDDIN MIDDEY', '', 'SALMA MIDDEY', '', '22/1/H/9/2, BIGHT STEET KOL-19', '', '', '', '', '', '8017427324', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8017427324', '8017427324', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(173, 1, '', '', 'TAZEEN TALHA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '3', '1462', '1462', '', '', '', 'TALHA TANWI', '', 'ASHI TALHA', '', '70C/H/1, TILJALA OAD, KOLKATA - 46', '', '', '', '', '', '8420266017', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420266017', '8420266017', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(174, 1, '', '', 'UME HABIBA', '2010-02-20', '', 'FEMALE', '', '', '', '', '', '', '3', '1452', '1452', '', '', '', 'ZAHID HUSSAIN', '', 'AFAT NAAZ', '', '1/2 B BICKFIELD LANE TOPSIA KOL-39', '', '', '', '', '', '8100883588', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100883588', '8100883588', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(175, 1, '', '', 'ZAAA ALAM', '2011-01-22', '', 'FEMALE', '', '', '', '', '', '', '3', '1280', '1280', '', '', '', 'SABBI ALAM', '', 'MANWAA KHATOON', '', '21/H/5, SHAMSUL DUHA OAD KOL-17', '', '', '', '', '', '6290229480', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '6290229480', '6290229480', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(176, 1, '', '', 'ZIKAH AFAQUE', '2010-10-01', '', 'FEMALE', '', '', '', '', '', '', '3', '1418', '1418', '', '', '', 'AFAQUE SHAMIM', '', 'SADAF FIDAUS SHAKIL', '', '2,ADHA GOBINDA SAHALANE KOL-17', '', '', '', '', '', '9831640500', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831640500', '9831640500', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(177, 1, '', '', 'ZOYA AKHTA', '2011-10-21', '', 'FEMALE', '', '', '', '', '', '', '3', '1236', '1236', '', '', '', 'AKHTA HUSSAIN', '', 'SHAMIMA BEGUM', '', '19/H/19 BIBI BAGAN LANE KOL-15', '', '', '', '', '', '9339849911', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339849911', '9339849911', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(178, 1, '', '', 'ALFIA SHE', '2010-03-26', '', 'FEMALE', '', '', '', '', '', '', '3', '1529', '1529', '', '', '', 'KHUSHID ALAM', '', 'SANJIDA BEGUM', '', '3/1, NAKELDANGA MAIN OAD, KOLKATA - 700011', '', '', '', '', '', '9339775333', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339775333', '9339775333', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(179, 1, '', '', 'AYESHA HUSSAIN', '2011-08-14', '', 'FEMALE', '', '', '', '', '', '', '3', '1579', '1579', '', '', '', 'ASHAD HOSSAIN', '', 'NAHEED HOSSAIN', '', '76, PINCEP STEET, KOLKATA - 700072', '', '', '', '', '', '8910056490', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8910056490', '8910056490', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(180, 1, '', '', 'UZMA ALI', '2009-11-07', '', 'FEMALE', '', '', '', '', '', '', '3', '1260', '1260', '', '', '', 'MD ALI', '', 'TAHEEN ALI', '', '100 MADAN MOHUN BUMAN STEET KOL - 07', '', '', '', '', '', '9007924328', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007924328', '9007924328', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(181, 1, '', '', 'AYESHA FATHMA', '2011-07-07', '', 'FEMALE', '', '', '', '', '', '', '3', '1537', '1537', '', '', '', 'SHAMI AHMED SIDDIQUI', '', 'SHAGUFTA PAVEEN', '', 'B/235/1, TILJALA OAD, KOLKATA - 700046', '', '', '', '', '', '9674761794', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674761794', '9674761794', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(182, 1, '', '', 'ABDUL AHMAN', '2011-01-29', '', 'MALE', '', '', '', '', '', '', '3', '1293', '1293', '', '', '', 'THAMIM ANSAI', '', 'BASHEEA BEGUM', '', '16A, TILJALA LANE, KOL - 39', '', '', '', '', '', '9038224133', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038224133', '9038224133', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(183, 1, '', '', 'AHNAF FAOOQUE', '2010-11-28', '', 'MALE', '', '', '', '', '', '', '3', '1331', '1331', '', '', '', 'FAOOQUE AZAM', '', 'SHABANA FAOOQUE', '', '1/B/H/5, CHHATU BABU LANE, KOL - 14', '', '', '', '', '', '9331040693', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331040693', '9331040693', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(184, 1, '', '', 'AKIF TAHMID', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1466', '1466', '', '', '', 'MD ABUSAYEED', '', 'NASIMA KHATUN', '', '50, LOWE ANGE, KOL - 19 // VILL: CHATAIDUBI. PO+PS: LALGOLA. DIST: MUSHIDABAD.742148', '', '', '', '', '', '6290872335', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '6290872335', '6290872335', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(185, 1, '', '', 'ASH ALI', '2011-02-09', '', 'MALE', '', '', '', '', '', '', '3', '1327', '1327', '', '', '', 'ASLAM ALI', '', 'TABASSU AA BEGUM', '', '15/2, TOPSIA 2ND LANE KOL-39', '', '', '', '', '', '7278642396', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7278642396', '7278642396', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(186, 1, '', '', 'DANIYAL ASAD', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1257', '1257', '', '', '', 'MD ASAD', '', 'TAZYEEN ASAD', '', 'ALHAMD APATMENT. BLOCK C. 4TH FLOO. 33, AI CHAAN GHOSH LANE, KOL - 39', '', '', '', '', '', '9674287321', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674287321', '9674287321', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(187, 1, '', '', 'FAHAN ALAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1361', '1361', '', '', '', 'MD JAMSHED ALAM', '', 'SHAGUFTA PAVEEN', '', '19, TOPSIA OAD, KOL - 39', '', '', '', '', '', '7890889920', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890889920', '7890889920', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(188, 1, '', '', 'HAMZAH ALI', '2010-05-05', '', 'MALE', '', '', '', '', '', '', '3', '1306', '1306', '', '', '', 'ASGHA ALI', '', 'NAGHMA SULTANA', '', '5B,DILKHUSHA STEET KOL-17', '', '', '', '', '', '9830979205', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830979205', '9830979205', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(189, 1, '', '', 'KAZIM AKAN AHMED', '2011-04-20', '', 'MALE', '', '', '', '', '', '', '3', '1512', '1512', '', '', '', 'SHAMIM AHMED', '', 'MAHJABEEN NAAZ', '', '37/4, PATTA GALI, AKBA MANZIL, WATGUNJ, KHIDDIPU, KOL-23', '', '', '', '', '', '9330884557', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330884557', '9330884557', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(190, 1, '', '', 'MD FAIZAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1346', '1346', '', '', '', 'AMZAN ALI', '', 'SAMA BEGUM', '', '10, ISMAIL STEET. KOLKATA - 700014', '', '', '', '', '', '8910740370', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8910740370', '8910740370', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(191, 1, '', '', 'MD FAWWAZ QAISE', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1343', '1343', '', '', '', 'MD IMTIYAZ QAISE', '', 'TABASSUM PAVEEN', '', '10/3, TALBAGAN LANE, 3D FLOO, KOL - 17', '', '', '', '', '', '8100408377', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100408377', '8100408377', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(192, 1, '', '', 'MD HASAN', '2010-12-12', '', 'MALE', '', '', '', '', '', '', '3', '1334', '1334', '', '', '', 'MD.ABULLAIS', '', 'NAZIA KHATOON', '', '2/H/6, HATI BAGAN OAD, KOL-14', '', '', '', '', '', '9831519911', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831519911', '9831519911', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(193, 1, '', '', 'MD KHUAM SHAFIQUE', '2011-03-01', '', 'MALE', '', '', '', '', '', '', '3', '1256', '1256', '', '', '', 'SHAFIQULLAH', '', 'FAHAT JABEEN', '', '70C/H/2, TILJALA OAD, KOLKATA - 700046', '', '', '', '', '', '9681061971', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681061971', '9681061971', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(194, 1, '', '', 'MD SAIF ALI', '2010-02-16', '', 'MALE', '', '', '', '', '', '', '3', '1333', '1333', '', '', '', 'GHULAM ALI', '', 'FAIDA BEGUM', '', '67, BIGHT STEET, KOL - 19 NEA D. PAL', '', '', '', '', '', '9830523208', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830523208', '9830523208', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(195, 1, '', '', 'MD SAIF SUFI', '2010-09-06', '', 'MALE', '', '', '', '', '', '', '3', '1372', '1372', '', '', '', 'MD SUFYAN', '', 'ZAHIDA BEGUM', '', '37, TOPSIA 2ND LANE, KOLKATA - 700039', '', '', '', '', '', '9748223864', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748223864', '9748223864', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(196, 1, '', '', 'MD TAMIM HASSAN', '2009-11-23', '', 'MALE', '', '', '', '', '', '', '3', '966', '966', '', '', '', 'MD TANWEE HASSAN', '', 'AHAT TANWEE', '', '2A, AJA AJ NAAYAN STEET, KOL - 9', '', '', '', '', '', '7890664846', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890664846', '7890664846', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(197, 1, '', '', 'MD. AYAAN', '2011-02-26', '', 'MALE', '', '', '', '', '', '', '3', '1339', '1339', '', '', '', 'GHOLAM SHAKI', '', 'SABIHA TABASSUM', '', '8F, TOPSIA 1ST LANE, KOL - 39', '', '', '', '', '', '9831904438', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831904438', '9831904438', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(198, 1, '', '', 'MD. FAHEEZ IBA', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1321', '1321', '', '', '', 'MD IBA', '', 'GULNAZ BANO', '', '3, DEEDA BUX LANE, KOL - 16', '', '', '', '', '', '9007876517', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007876517', '9007876517', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(199, 1, '', '', 'MD.AALAYMEEN EJAZ', '2010-06-24', '', 'MALE', '', '', '', '', '', '', '3', '1450', '1450', '', '', '', 'MD.EJAZ ALAM', '', 'FAHAT JABEEN', '', 'B/76/H/13, LINTON STEET 3d FLOO KOL-14', '', '', '', '', '', '8910033746', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8910033746', '8910033746', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(200, 1, '', '', 'MOHAMMAD ABBAS ALI', '2010-05-30', '', 'MALE', '', '', '', '', '', '', '3', '1297', '1297', '', '', '', 'MD.WAQUA DANISH', '', 'ZOYA SEEMEEN', '', '14 B, KAAYA OAD KOL-17', '', '', '', '', '', '9831312172', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831312172', '9831312172', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(201, 1, '', '', 'MOHAMMED ABU TALHA', '2010-10-26', '', 'MALE', '', '', '', '', '', '', '3', '1229', '1229', '', '', '', 'MOHAMMED PAWEZ AIF', '', 'UBY PAVEEN', '', 'SANSA APATMENT. 37, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '8100943525', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100943525', '8100943525', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(202, 1, '', '', 'MOHAMMED AFFAN ALI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1386', '1386', '', '', '', 'ASIF ALI', '', 'SHAHEEN PAWEEN', '', '20F, TOPSIA OAD, KOL - 39', '', '', '', '', '', '8777530496', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8777530496', '8777530496', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(203, 1, '', '', 'MOHAMMED JALALUDDIN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1305', '1305', '', '', '', 'SIKANDA BACHA', '', 'FATHIMA BIBI', '', '16A, TILJALA LANE, KOL - 39', '', '', '', '', '', '9163930101', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163930101', '9163930101', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(204, 1, '', '', 'ASHID HAMMAD', '2010-09-30', '', 'MALE', '', '', '', '', '', '', '3', '1501', '1501', '', '', '', 'MOOSA IMAM', '', 'NISHA SABBIH', '', 'VILL: KHEON. PO - BAGODIH, DIST: GIIDIH, JHAKHAND', '', '', '', '', '', '8293012979', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8293012979', '8293012979', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(205, 1, '', '', 'SHAHID MIDDYA', '2010-06-04', '', 'MALE', '', '', '', '', '', '', '3', '1270', '1270', '', '', '', 'MAIDUL ISLAM MIDDYA', '', 'FATEMA ZOHA KHATOON', '', '50,B TALTALA LANE KOL - 16', '', '', '', '', '', '8697224221', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8697224221', '8697224221', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(206, 1, '', '', 'SHAYEQUE AKHTE', '2010-04-16', '', 'MALE', '', '', '', '', '', '', '3', '1474', '1474', '', '', '', 'MD.WASIM AKHTE', '', 'SHABANA BEGUM', '', '13/E, BECHULAL OAD KOL - 14', '', '', '', '', '', '8420164645', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420164645', '8420164645', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(207, 1, '', '', 'SHAZIB KALAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1288', '1288', '', '', '', 'ISHAD KALAM', '', 'NAHEDA PEWEEN', '', '84A, TOPSIA OAD. KOLKATA-700039', '', '', '', '', '', '9831266581', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831266581', '9831266581', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(208, 1, '', '', 'SHEIKH SHAMSHE ALAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1358', '1358', '', '', '', 'SK. SHAMIM ALAM', '', 'SAJJO ANI', '', '62, TOPSIA OAD. KOLKATA - 700039', '', '', '', '', '', '9903605547', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903605547', '9903605547', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(209, 1, '', '', 'SK MD AKHIBUL ISLAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1309', '1309', '', '', '', 'SK MD HAUN', '', 'AFIA BEGUM', '', '6, JHOWTALLA LANE, KOL - 17', '', '', '', '', '', '9836422908', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836422908', '9836422908', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(210, 1, '', '', 'SK SHAHID JAHANGI', '2010-01-21', '', 'MALE', '', '', '', '', '', '', '3', '1414', '1414', '', '', '', 'SK.JAHANGI', '', 'SHAGUFTA QUMA JAHAN', '', '19/4, G.J.KHAN OAD KOLKATA - 39', '', '', '', '', '', '9831103783', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831103783', '9831103783', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(211, 1, '', '', 'SK. TAWHEED PAWAZ', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1520', '1520', '', '', '', 'SK ASED ALI', '', 'PAMIN SULTANA', '', '7B,  CHAMO KHAN SAMA LANE. KOLKATA - 700017', '', '', '', '', '', '9331521718', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331521718', '9331521718', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(212, 1, '', '', 'SULEMAN AKHTA', '2010-08-26', '', 'MALE', '', '', '', '', '', '', '3', '1329', '1329', '', '', '', 'JAMIL AKHTA', '', 'SHIEEN AKHTA', '', 'B29/H/1A PALM AVENUE. KOLKATA - 700019', '', '', '', '', '', '9831750331', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831750331', '9831750331', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(213, 1, '', '', 'USAID ALI ZAMADA', '2010-05-10', '', 'MALE', '', '', '', '', '', '', '3', '1500', '1500', '', '', '', 'FAIYAZ ALI ZAMADA', '', 'NOOJAHAN  ZAMADA', '', 'NAJA NAGA  P.O- HAOA 24 PGS.( NOTH )', '', '', '', '', '', '8820357315', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8820357315', '8820357315', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(214, 1, '', '', 'YAHYA KHAN', '', '', 'MALE', '', '', '', '', '', '', '3', '1492', '1492', '', '', '', 'ABDULLAH KHAN', '', 'SHAFEEQA KHAN', '', '12, ELLIOT LANE, KOL - 16', '', '', '', '', '', '7596922210', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7596922210', '7596922210', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(215, 1, '', '', 'ZIDAN SIDDIQUE', '2011-04-25', '', 'MALE', '', '', '', '', '', '', '3', '1240', '1240', '', '', '', 'SAFAAZ AHMED', '', 'TALAT JAHAN', '', '62K TOPSIA OAD KOL-39', '', '', '', '', '', '9339664700', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339664700', '9339664700', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(216, 1, '', '', 'KAZI MD NOMAN', '2010-12-15', '', 'MALE', '', '', '', '', '', '', '3', '1542', '1542', '', '', '', 'KAZI MANIUL ISLAM', '', 'SUJATAN NISHA', '', '41, B.B.GANGULY STEET, KOLKATA - 700012', '', '', '', '', '', '9830334427', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830334427', '9830334427', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(217, 1, '', '', 'MOHAMMAD EBAHIM', '2011-05-17', '', 'MALE', '', '', '', '', '', '', '3', '1561', '1561', '', '', '', 'MD AHTESHAM', '', 'AZA TABASSUM', '', '4B/3, TOPSIA 2ND LANE, KOLKATA - 700039', '', '', '', '', '', '9748222119', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748222119', '9748222119', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(218, 1, '', '', 'MD BILAL', '2010-10-08', '', 'MALE', '', '', '', '', '', '', '3', '1562', '1562', '', '', '', 'MD EHAN', '', 'HUMAIA EHAN', '', '8N/1, TOPSIA 2ND LANE, KOLKATA - 700039', '', '', '', '', '', '9804141493', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9804141493', '9804141493', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(219, 1, '', '', 'MD AMAANULLAH KHAN', '2011-03-01', '', 'MALE', '', '', '', '', '', '', '3', '1558', '1558', '', '', '', 'MD GHULAM GHAUS KHAN', '', 'SAMIMA KHATOON', '', '27/B, D. C. DEY OAD, KOLKATA - 700015', '', '', '', '', '', '9331541589', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331541589', '9331541589', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(220, 1, '', '', 'SHIZAN WASI', '2010-06-23', '', 'MALE', '', '', '', '', '', '', '3', '1700', '1700', '', '', '', 'MD MUAD', '', 'SHAMSUN NISHA', '', '297/1/H/20, A.P.C. OAD, KOLKATA - 700009', '', '', '', '', '', '7980926638', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980926638', '7980926638', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(221, 1, '', '', 'MD ILYASEEN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '3', '1521', '1521', '', '', '', 'TAHSEEN AHMED', '', 'ZEENAT KHATOON', '', '97/4, TOPSIA OAD (S), KOL - 39', '', '', '', '', '', '9038965725', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038965725', '9038965725', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(222, 1, '', '', 'ABIDA ELAHI', '2009-08-22', '', 'FEMALE', '', '', '', '', '', '', '4', '1419', '1419', '', '', '', 'MD.IFANULLAH ', '', 'NAZIA PAVEEN', '', '20B, D.BIESH GUHA STEET KOL-17', '', '', '', '', '', '9830643107', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830643107', '9830643107', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(223, 1, '', '', 'ADIBA HASIB', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '4', '1460', '1460', '', '', '', 'MD HASIB', '', 'SUFIYA NAAZ', '', '32 A/1-B, TALTALA LANE, KOLKATA - 700016', '', '', '', '', '', '9831399136', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831399136', '9831399136', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(224, 1, '', '', 'ADIFAH AZAM', '2010-12-10', '', 'FEMALE', '', '', '', '', '', '', '4', '1362', '1362', '', '', '', 'MD.NAYAB AZAM', '', 'NAHID FATMA', '', '61 C/1 TOPSIA OAD KOL -39', '', '', '', '', '', '9903669646', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903669646', '9903669646', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(225, 1, '', '', 'AISHA ASHAF KHAN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '4', '1369', '1369', '', '', '', 'ASHAF KHAN', '', 'LATE TABASSUM AHMAN', '', '42H/10, JANNAGA OAD, KOL - 17', '', '', '', '', '', '9331426761', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331426761', '9331426761', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(226, 1, '', '', 'AISHAH FATMA', '2019-02-06', '', 'FEMALE', '', '', '', '', '', '', '4', '1254', '1254', '', '', '', 'ASIF JAMAL', '', 'SAJDA KHATOON', '', '16, KUSTIA MASJID BAI LANE, KOL-39', '', '', '', '', '', '8420478312', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420478312', '8420478312', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(227, 1, '', '', 'ALEENA NAAZ', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '4', '1312', '1312', '', '', '', 'MD IMTIYAZ AHMED', '', 'MUSAAT JAHAN', '', '48, CANAL EAST OAD, KOL - 11', '', '', '', '', '', '9681020057', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681020057', '9681020057', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(228, 1, '', '', 'ALFISHA AZOO', '2010-04-17', '', 'FEMALE', '', '', '', '', '', '', '4', '1477', '1477', '', '', '', 'IFAN AZOO', '', 'WASIMA KHATOON', '', '29/H/21, LINTON STEET, KOL - 14', '', '', '', '', '', '9831987709', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831987709', '9831987709', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(229, 1, '', '', 'ALIAH NAUSHAD', '2011-04-29', '', 'FEMALE', '', '', '', '', '', '', '4', '1302', '1302', '', '', '', 'MD NAUSHAD', '', 'ZEBA AHMED', '', '7/H/12, KASAI PAA LANE, KOL - 17', '', '', '', '', '', '9903109010', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903109010', '9903109010', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(230, 1, '', '', 'AIFA ALAM', '2010-10-06', '', 'FEMALE', '', '', '', '', '', '', '4', '1310', '1310', '', '', '', 'MD IMTIAZ ALAM', '', 'ASHIKA ALAM', '', '11A,/ 11 CHISTOPHE OAD KOL-14', '', '', '', '', '', '9831480171', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831480171', '9831480171', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(231, 1, '', '', 'AUSHA NAAZ', '2011-08-19', '', 'FEMALE', '', '', '', '', '', '', '4', '1441', '1441', '', '', '', 'MD CHAND', '', 'SAHZAMINA KHATOON', '', '7/2/H/4 D M.N CHATTEJEE SAANI KOL-9', '', '', '', '', '', '9903340786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903340786', '9903340786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(232, 1, '', '', 'FALAK NAAZ', '2010-03-25', '', 'FEMALE', '', '', '', '', '', '', '4', '1252', '1252', '', '', '', 'EJAZ ALAM', '', 'TAANNUM JAHAN', '', '4,A.G.J KHAN OAD TOPSIA KOL-39 (HAYAT ESIDENCY)', '', '', '', '', '', '9831449151', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831449151', '9831449151', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(233, 1, '', '', 'FAQEHA EHTESHAM', '2010-12-31', '', 'FEMALE', '', '', '', '', '', '', '4', '1273', '1273', '', '', '', 'MD.EHTESHAM', '', 'TAMANNA PAVEEN', '', '51/S/1, SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '8981493911', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8981493911', '8981493911', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(234, 1, '', '', 'IQA ALAM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '4', '1350', '1350', '', '', '', 'AFTAB ALAM', '', 'NASEEN ALAM', '', '4/2B/H/1, BHUKAILASH OAD, KOL - 23', '', '', '', '', '', '8240396352', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240396352', '8240396352', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(235, 1, '', '', 'MAIYAM KHAN', '2010-09-16', '', 'FEMALE', '', '', '', '', '', '', '4', '1471', '1471', '', '', '', 'FIOZ KHAN', '', 'ANJUM AA', '', '17/H/5, M.M. ALI OAD, KOLKTA - 700023', '', '', '', '', '', '8420490675', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420490675', '8420490675', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(236, 1, '', '', 'OZAIN FAOOQUI', '2019-02-06', '', 'FEMALE', '', '', '', '', '', '', '4', '1292', '1292', '', '', '', 'PAVEZ HAIDE', '', 'AHNUMA KHATOON', '', '31/1, PEMENTLE STEET. KOLKATA - 700016', '', '', '', '', '', '8100231048', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100231048', '8100231048', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(237, 1, '', '', 'SANA AFEEN', '2009-03-18', '', 'FEMALE', '', '', '', '', '', '', '4', '1435', '1435', '', '', '', 'MD.ASHAD', '', 'MUZAMIL ASHAD', '', '71/1A/H/3 TILJALA LANE KOL-46', '', '', '', '', '', '9339158111', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339158111', '9339158111', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(238, 1, '', '', 'SHAFIA KALIM', '2011-01-22', '', 'FEMALE', '', '', '', '', '', '', '4', '1403', '1403', '', '', '', 'MD KALIMUDDIN', '', 'KAUSA TABASSUM', '', '2A, TOPSIA OAD, KOL -39', '', '', '', '', '', '9874289091', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874289091', '9874289091', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(239, 1, '', '', 'SUMAYYA AUFI', '2011-12-25', '', 'FEMALE', '', '', '', '', '', '', '4', '1494', '1494', '', '', '', 'MUMTAZ AUFI', '', 'ANJUM AA', '', '17/B SAMSHUL HUDA OAD KOL-17', '', '', '', '', '', '9330935640', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330935640', '9330935640', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(240, 1, '', '', 'TALLA AZMI', '2010-10-22', '', 'FEMALE', '', '', '', '', '', '', '4', '1483', '1483', '', '', '', 'MD.FAKHUDDIN', '', 'SHAISTA PAVEEN', '', '4, SUHAWADY AVENUE KOL-17', '', '', '', '', '', '9831587753', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831587753', '9831587753', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(241, 1, '', '', 'TASHEEN AA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '4', '1398', '1398', '', '', '', 'MD AIF ', '', 'ANSA PAVEEN', '', '4/1, BECHULAL OAD, PADDAPUKU, KOL - 14', '', '', '', '', '', '9831351775', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831351775', '9831351775', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(242, 1, '', '', 'TASMIYA SHAKI', '2010-09-22', '', 'FEMALE', '', '', '', '', '', '', '4', '1508', '1508', '', '', '', 'SYED ABDUL SHAKI', '', 'SHABISTAN SHAKI', '', '11, KUSTIA OAD KOL-39', '', '', '', '', '', '9903012960', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903012960', '9903012960', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(243, 1, '', '', 'ZATASHA WASI', '2011-07-04', '', 'FEMALE', '', '', '', '', '', '', '4', '1489', '1489', '', '', '', 'DAULAT AZA', '', 'TAANNUM JAHAN', '', '13/2H/1, PATWA BAGAN LANE, KOL-9', '', '', '', '', '', '9038503865', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038503865', '9038503865', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(244, 1, '', '', 'ZIKA AHMED', '2010-07-26', '', 'FEMALE', '', '', '', '', '', '', '4', '1464', '1464', '', '', '', 'AFOZE AHMED', '', 'TASNEEM KAUSA', '', '3,H/2, AJA DENENDA STEET KOL-9', '', '', '', '', '', '9831997376', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831997376', '9831997376', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(245, 1, '', '', 'ZOYA ALAM - 1', '2009-08-22', '', 'FEMALE', '', '', '', '', '', '', '4', '1294', '1294', '', '', '', 'MEHTAB ALAM', '', 'GULNAZ ALAM', '', '12/2, TOPSIA 2ND LANE, KOL-39', '', '', '', '', '', '9836633016', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836633016', '9836633016', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(246, 1, '', '', 'ZUFA FEOZE', '2010-12-02', '', 'FEMALE', '', '', '', '', '', '', '4', '1286', '1286', '', '', '', 'MD.FEOZE', '', 'ZEENAT FEOZE', '', '9/J TOPSIA OAD KOL-39', '', '', '', '', '', '9903768768', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903768768', '9903768768', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(247, 1, '', '', 'UMME KULSUM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '4', '1347', '1347', '', '', '', 'MD HUMAYUN ALI', '', 'KEHKASHAN HUMAYUN', '', '3, JANNAGA 2ND LANE, KOLKATA - 700014', '', '', '', '', '', '9831678692', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831678692', '9831678692', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(248, 1, '', '', 'EYASMIN KHATOON', '2010-06-19', '', 'FEMALE', '', '', '', '', '', '', '4', '1723', '1723', '', '', '', 'SK ALI AHMED', '', 'SAKINA BEGAM', '', '30/C, TILJALA OAD, KOLKATA - 700039', '', '', '', '', '', '9748670893', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748670893', '9748670893', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(249, 1, '', '', 'AHYAN BIN EYAZ', '1970-01-01', '', 'MALE', '', '', '', '', '', '', '4', '1430', '1430', '', '', '', 'EYAZ AHMAD KHAN', '', 'SUFIA PEVEEN', '', '9 G.J.KHAN OAD KOL-39', '', '', '', '', '', '9062992926', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062992926', '9062992926', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(250, 1, '', '', 'AEEB SAQUIB ANAS', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '4', '1410', '1410', '', '', '', 'SAQUIB ANAS', '', 'SANA SAQUIB', '', '4TH FLOO AFZAL MANZIL 13/A PHEAS LANE', '', '', '', '', '', '9007787011', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007787011', '9007787011', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(251, 1, '', '', 'AQAM ALAM', '2010-09-03', '', 'MALE', '', '', '', '', '', '', '4', '1439', '1439', '', '', '', 'MEHFOOZ ALAM', '', 'SHAHANA ALAM', '', 'B/46/E/H/3 GOA CHAND OAD KOL-14', '', '', '', '', '', '9007797753', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007797753', '9007797753', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(252, 1, '', '', 'AYAN KHAN', '2010-10-23', '', 'MALE', '', '', '', '', '', '', '4', '1438', '1438', '', '', '', 'SHAHEED KHAN', '', 'UKSHE BEGUM', '', '26, G J KHAN OAD, KOLKATA - 7000039', '', '', '', '', '', '9163241117', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163241117', '9163241117', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(253, 1, '', '', 'AYAAN AHMAN', '2010-10-21', '', 'MALE', '', '', '', '', '', '', '4', '1424', '1424', '', '', '', 'NAVID AHMAN', '', 'AFSHAN NAVID', '', '2, SAYED AMI ALI AVENUE FLAT NO- 4 KOL-17', '', '', '', '', '', '9831189916', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831189916', '9831189916', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(254, 1, '', '', 'FAHAN ALI HAIDE', '2011-01-29', '', 'MALE', '', '', '', '', '', '', '4', '1295', '1295', '', '', '', 'ZULFIQUA ALI HAIDE', '', 'GAZALA HAIDE', '', '37/1A, MOMINPU OAD, EKBALPUE, KOL - 23', '', '', '', '', '', '7003400619', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003400619', '7003400619', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(255, 1, '', '', 'HUZAIFA TANJIM', '2010-10-02', '', 'MALE', '', '', '', '', '', '', '4', '1467', '1467', '', '', '', 'LATE TANJIM ALAM', '', 'NAGMA NISHAT', '', '4/59, CONVENT LANE KOL-15', '', '', '', '', '', '8100092880', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100092880', '8100092880', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(256, 1, '', '', 'JUNAID HUSSAIN', '2009-05-12', '', 'MALE', '', '', '', '', '', '', '4', '1247', '1247', '', '', '', 'AFAKAT HUSSAIN', '', 'SAIDA KHATOON', '', 'B-29/A/H/13, PALM AVENUE, KOLKATA - 700019', '', '', '', '', '', '9831134718', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831134718', '9831134718', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(257, 1, '', '', 'KHAIULLAH ASHIM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '4', '1436', '1436', '', '', '', 'KHAIUL SHAMS', '', 'SAJDA SHAMS', '', '2C/H/8, CHATU BABU LANE, ENTALLY, KOL - 14', '', '', '', '', '', '9681880303', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681880303', '9681880303', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(258, 1, '', '', 'MD ABAAN', '2010-08-24', '', 'MALE', '', '', '', '', '', '', '4', '1399', '1399', '', '', '', 'MD.AIF', '', 'SONAM AIF', '', '46/H/1 GOA CHAND OAD KOL-14', '', '', '', '', '', '9831892028', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831892028', '9831892028', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(259, 1, '', '', 'MD ABDULLAH OMA IBAHIM', '2010-08-02', '', 'MALE', '', '', '', '', '', '', '4', '1458', '1458', '', '', '', 'MD.OMA IBAHIM', '', 'SADAF OMA IBAHIM', '', '3, JANNAGA OAD 2ND LANE KOL-14', '', '', '', '', '', '9331978351', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331978351', '9331978351', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(260, 1, '', '', 'MD ASAD', '2010-06-25', '', 'MALE', '', '', '', '', '', '', '4', '1440', '1440', '', '', '', 'MD CHAND', '', 'SAHZAMINA KHATOON', '', '7/2/H/4 D M.N CHATTEJEE SAANI KOL-9', '', '', '', '', '', '9903340786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903340786', '9903340786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(261, 1, '', '', 'MD IBAHIM ALI AHMED', '2011-02-01', '', 'MALE', '', '', '', '', '', '', '4', '1490', '1490', '', '', '', 'MUZAFFA ALI AHMED', '', 'KOHINOO IBAHIM', '', '30B, CANTOPHE LANE, KOL-14', '', '', '', '', '', '9007100522', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007100522', '9007100522', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(262, 1, '', '', 'MD JUNAID IMAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '4', '1459', '1459', '', '', '', 'MD IMAN', '', 'MAHJABEEN BEGUM', '', '26/H/3, MAKET STEET, KOL - 87', '', '', '', '', '', '7687957934', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7687957934', '7687957934', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(263, 1, '', '', 'MD AIHANUDDIN', '2009-12-02', '', 'MALE', '', '', '', '', '', '', '4', '1325', '1325', '', '', '', 'MD.NOOUDDIN ', '', 'NASIM BEGUM', '', '9/1 TOPSIA LANE. KOLKATA - 700039', '', '', '', '', '', '8910898548', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8910898548', '8910898548', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(264, 1, '', '', 'MD SAIF AZA', '2011-02-01', '', 'MALE', '', '', '', '', '', '', '4', '1246', '1246', '', '', '', 'MD ALAUDDIN', '', 'ANGUI KHATOON', '', '10/2/H/6 WATGUNJ STEET KOL-23 (2ND FLOO)', '', '', '', '', '', '9331570013', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331570013', '9331570013', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(265, 1, '', '', 'MD SHADAN SHAMIM AZA', '2010-05-20', '', 'MALE', '', '', '', '', '', '', '4', '1287', '1287', '', '', '', 'SHAMIM AHMED KHAN', '', 'ASHIDA BANO', '', '8, KHATAL BIG. AVINASH CHOWDHUY LANE KOL-46', '', '', '', '', '', '9874244236', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874244236', '9874244236', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(266, 1, '', '', 'MD YAWA MALLIK', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '4', '1437', '1437', '', '', '', 'IMTEYAZ AHMED', '', 'IFFAT AA', '', '31/A, MAIJAN OSTAGA LANE. KOLKATA - 17', '', '', '', '', '', '9831348959', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831348959', '9831348959', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(267, 1, '', '', 'MD ZOHAI', '2010-07-26', '', 'MALE', '', '', '', '', '', '', '4', '1432', '1432', '', '', '', 'SHAFUDDIN ZAYAB', '', 'FAHAT NISA', '', '48, MCLEOD STEET, KOL - 17', '', '', '', '', '', '9088454215', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9088454215', '9088454215', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(268, 1, '', '', 'MD. ABUZA ASAF', '2010-10-27', '', 'MALE', '', '', '', '', '', '', '4', '1284', '1284', '', '', '', 'MD EHTESHAMUDDIN', '', 'NUZHAT BANO', '', '25/1/9, TOPSIA OAD, KOL-39', '', '', '', '', '', '9831719134', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831719134', '9831719134', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(269, 1, '', '', 'MD. JAYESHUDDIN', '2011-01-10', '', 'MALE', '', '', '', '', '', '', '4', '1389', '1389', '', '', '', 'MD.SHAHABUDDIN ', '', 'ANSAI SULTANA', '', '70/B/H/2 TILJALA OAD KOL-46', '', '', '', '', '', '9339532321', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339532321', '9339532321', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(270, 1, '', '', 'MD. ZOHAB NASIM', '2010-02-08', '', 'MALE', '', '', '', '', '', '', '4', '1394', '1394', '', '', '', 'MD. NASIM', '', 'NAHID NASIM', '', '21, TALTALA BAZA STEET KOL - 14', '', '', '', '', '', '9903549035', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903549035', '9903549035', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(271, 1, '', '', 'MD.AMI JAMAL', '2010-07-24', '', 'MALE', '', '', '', '', '', '', '4', '1342', '1342', '', '', '', 'MD.JAMALUDDIN', '', 'GULSHAN AA', '', 'B/22/1/H/4, BIGHT STEET KOL-17', '', '', '', '', '', '9748547411', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748547411', '9748547411', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(272, 1, '', '', 'MD.FAIZ HUSSAIN', '2010-09-18', '', 'MALE', '', '', '', '', '', '', '4', '1317', '1317', '', '', '', 'MD.NADEEM ANJUM', '', 'SONI BEGUM', '', '33,AHII PUKU OAD KOL-19', '', '', '', '', '', '8961697708', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8961697708', '8961697708', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(273, 1, '', '', 'MIZAN HUSSAIN', '2010-09-25', '', 'MALE', '', '', '', '', '', '', '4', '1301', '1301', '', '', '', 'NASI HUSSAIN', '', 'TABASSUM QAMA', '', '15/H/4, BIBI BAGAN LANE KOL-15', '', '', '', '', '', '9836623428', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836623428', '9836623428', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(274, 1, '', '', 'MOHAMMAD SOHAIL ALAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '4', '1298', '1298', '', '', '', 'SHAMSHAD ALAM', '', 'SHAMINA KHATOON', '', '31, TOPSIA OAD (S), KOL - 46', '', '', '', '', '', '7980742591', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980742591', '7980742591', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(275, 1, '', '', 'MUAWIYA HASSAN KHAN', '2019-02-06', '', 'MALE', '', '', '', '', '', '', '4', '1368', '1368', '', '', '', 'MUSHID HASSAN KHAN', '', 'ASHAFI KHAN', '', '42H/10, JANNAGA OAD, KOL - 17', '', '', '', '', '', '9674156950', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674156950', '9674156950', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(276, 1, '', '', 'NOUMAN HOSSAIN', '2009-11-08', '', 'MALE', '', '', '', '', '', '', '4', '1431', '1431', '', '', '', 'IFAN HOSSAIN', '', 'FAIDA HOSSAIN', '', '3/H/1, JHOWTALA LANE KOL-17', '', '', '', '', '', '9330066990', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330066990', '9330066990', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(277, 1, '', '', 'IJWAN ALI', '2010-12-30', '', 'MALE', '', '', '', '', '', '', '4', '1264', '1264', '', '', '', 'ANWA ALI', '', 'SABIKUN NAHA', '', '4H/3, CONVENT LANE, KOL - 15', '', '', '', '', '', '9231937315', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9231937315', '9231937315', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(278, 1, '', '', 'SAIF ALI', '2010-06-25', '', 'MALE', '', '', '', '', '', '', '4', '1374', '1374', '', '', '', 'SHAWKAT ALI', '', 'YASMEEN KHATOON', '', '32A/1W AICHAAN GHOSH LANE KOL-39', '', '', '', '', '', '9903629898', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903629898', '9903629898', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(279, 1, '', '', 'SK BELAL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '4', '1499', '1499', '', '', '', 'SK SHAHABUDDIN', '', 'SAHNAJ KHATOON', '', '29/A/H/43, PALM AVENUE KOLKATA-700019', '', '', '', '', '', '9748086907', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748086907', '9748086907', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(280, 1, '', '', 'SK. SADIM SAEED', '2010-10-08', '', 'MALE', '', '', '', '', '', '', '4', '1324', '1324', '', '', '', 'SK. JUMMAN SAEED', '', 'SHAMMI SAEED', '', '45, TILJALA OAD KOL - 46', '', '', '', '', '', '9681941575', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681941575', '9681941575', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(281, 1, '', '', 'SYED ABDUL KHALEQ', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '4', '1420', '1420', '', '', '', 'SYED ISHAD AHMAD', '', 'SAHISTA PAVEN', '', '24D/1, KUSTIA OAD. KOLKATA - 700039', '', '', '', '', '', '8442847963', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8442847963', '8442847963', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(282, 1, '', '', 'TANWEE ASLAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '4', '1484', '1484', '', '', '', 'MD ATAULLAH ASLAM', '', 'SHAMIMA KHATOON', '', '15, CHAMU KHAN SAMA LANE, KOL - 17', '', '', '', '', '', '9903207046', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903207046', '9903207046', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(283, 1, '', '', 'UZAI SHAKIL', '2011-10-12', '', 'MALE', '', '', '', '', '', '', '4', '1239', '1239', '', '', '', 'AFTAB ALAM', '', 'UZMA SHAKIL', '', '36/D/M TOPSIA OAD KOL-39', '', '', '', '', '', '9339452399', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339452399', '9339452399', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(284, 1, '', '', 'NAZI IMTIAZ', '2011-05-09', '', 'MALE', '', '', '', '', '', '', '4', '1559', '1559', '', '', '', 'MD IMTIAZ ALI', '', 'NAAZ PAVEEN', '', 'E/42, GULSHAN COLONY, P.S. ANANDOPU, KOLKATA - 700105', '', '', '', '', '', '8906650566', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8906650566', '8906650566', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(285, 1, '', '', 'AALIYA ONAIZA MOHSIN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1503', '1503', '', '', '', 'SHAH AIFF MD MOHSIN', '', 'SHAHANA MOHSIN', '', '44/4A/2 C.N.OY OAD KOLKATA - 700039', '', '', '', '', '', '8777372607', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8777372607', '8777372607', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(286, 1, '', '', 'ALAINA SHAHNAWAZ', '2011-01-20', '', 'FEMALE', '', '', '', '', '', '', '5', '1351', '1351', '', '', '', 'SHAHNAWAZ AHMED', '', 'SHIBA AFEEN', '', '11, B/1 TOPSIA 2ND LANE KOL 39', '', '', '', '', '', '9681144849', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681144849', '9681144849', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(287, 1, '', '', 'AMATUL FATMA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1502', '1502', '', '', '', 'FAUK AZA', '', 'ESHMA PAVEEN', '', '467 G.T. OAD SHIBPU HOWAH-711102', '', '', '', '', '', '9163974090', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163974090', '9163974090', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(288, 1, '', '', 'AEESHA FIDAUS', '2010-12-20', '', 'FEMALE', '', '', '', '', '', '', '5', '1318', '1318', '', '', '', 'FIDAUS AGHIB', '', 'FATMA SHAMIN', '', '26 B, D. SUESH SAKA OAD. ENTALLY, KOLKATA - 700014', '', '', '', '', '', '9674047425', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674047425', '9674047425', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(289, 1, '', '', 'ASWA PAVEEN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1504', '1504', '', '', '', 'MD SHAMS TABEZ', '', 'NAJDAH TABSSUM', '', '29/A/40 PALM AVENUE KOLKATA-700019', '', '', '', '', '', '9631958544', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9631958544', '9631958544', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(290, 1, '', '', 'AYANA VANI', '2010-06-01', '', 'FEMALE', '', '', '', '', '', '', '5', '1476', '1476', '', '', '', 'NISA AHMED WANI', '', 'SHAGUFTA  JAHAN', '', '48, TOPSIA OAD SOUTH KOL-46', '', '', '', '', '', '9874118301', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874118301', '9874118301', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(291, 1, '', '', 'AYESHA BANO', '2011-03-26', '', 'FEMALE', '', '', '', '', '', '', '5', '1249', '1249', '', '', '', 'MUKTASID HASHIM', '', 'AKIYA BANO', '', '2B, D BIESH GUHA STEET KOL-17', '', '', '', '', '', '9903321170', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903321170', '9903321170', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(292, 1, '', '', 'AYESHA IQBAL', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1291', '1291', '', '', '', 'MD IQBAL ALAM', '', 'HAZA IQBAL', '', '16B, SAPGACHI 1ST LANE, 3D FLOO, KOLKATA - 39', '', '', '', '', '', '7003655643', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003655643', '7003655643', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(293, 1, '', '', 'AYESHA JEELANI', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1480', '1480', '', '', '', 'GHULAM JEELANI', '', 'TABASSUM AA', '', ' MISBAHUL COMPLEX 62D, TOPSIA OAD, OPP. BILAL MASJID. KOLKATA - 700039 ', '', '', '', '', '', '8777891167', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8777891167', '8777891167', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(294, 1, '', '', 'AYESHA NOO', '2010-05-01', '', 'FEMALE', '', '', '', '', '', '', '5', '1275', '1275', '', '', '', 'MD NAIYE', '', 'SALEHA KHATOON', '', '111/A TOPSIA OAD. KOL 39', '', '', '', '', '', '9831236209', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831236209', '9831236209', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(295, 1, '', '', 'FATIMA ZOHA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1415', '1415', '', '', '', 'MD SK SAJID', '', 'ESHMA BANU', '', '10/1, SAAPGACHI 1ST LANE. KOLKATA - 700039', '', '', '', '', '', '8420094103', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420094103', '8420094103', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(296, 1, '', '', 'HAFSA KHATOON', '2010-06-11', '', 'FEMALE', '', '', '', '', '', '', '5', '1349', '1349', '', '', '', 'BELAL HUSSAIN', '', 'ZUBAEDA KHATOON', '', 'FIST FLOO 4, CEMATOIUM STEET KOL-14', '', '', '', '', '', '8240379487', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240379487', '8240379487', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(297, 1, '', '', 'HALIMA LABEEBA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1345', '1345', '', '', '', 'A.S.MUHAMMAD SHAMSUL HUTHA', '', 'S.S.AHIMA ZAINAB', '', 'EKTA FLOAL APATMENT. 27, CHISTOPHE OAD, BLOCK-1 KOLKATA - 700046', '', '', '', '', '', '9883124454', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883124454', '9883124454', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(298, 1, '', '', 'ITEQA TANWEE', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1289', '1289', '', '', '', 'MD QUBAN ALI', '', 'TANWEE JAHAN', '', '4/H/4, COMMISSAIAT BASTI LANE, HASTING, KOL-22', '', '', '', '', '', '8420643296', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420643296', '8420643296', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(299, 1, '', '', 'MAHVISH MAHTAB', '', '', 'FEMALE', '', '', '', '', '', '', '5', '1506', '1506', '', '', '', 'MAHTAB ALAM', '', 'YASMEEN KHATUN', '', 'MAHABA APATMENT. 5, G J KHAN OAD, KOLKATA - 700039', '', '', '', '', '', '8274829087', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8274829087', '8274829087', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(300, 1, '', '', 'MEHA ASHAD', '2010-08-25', '', 'FEMALE', '', '', '', '', '', '', '5', '1491', '1491', '', '', '', 'MD.ASHAD ', '', 'NASIN NAAZ', '', '29/H/32, LINTON STEET KOL-14', '', '', '', '', '', '9831139230', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831139230', '9831139230', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(301, 1, '', '', 'NAJMUS SAKIB', '2011-01-30', '', 'FEMALE', '', '', '', '', '', '', '5', '1267', '1267', '', '', '', 'SAKIB MULLICK', '', 'SUFIA SHAMIN', '', '9/3, TOPSIA 1ST LANE, KOL - 39', '', '', '', '', '', '9903163933', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903163933', '9903163933', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(302, 1, '', '', 'NILOFA FIDOUSE', '2010-04-04', '', 'FEMALE', '', '', '', '', '', '', '5', '1316', '1316', '', '', '', 'SYED OOHULLAH ', '', 'AZIA TABASSUM', '', '16/H/4, BECK BAGAN OW KOL-17', '', '', '', '', '', '8981710637', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8981710637', '8981710637', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(303, 1, '', '', 'SABIA KHATOON', '2010-09-29', '', 'FEMALE', '', '', '', '', '', '', '5', '1344', '1344', '', '', '', 'SAHID AKHTE', '', 'SUFIA SAHID', '', '29/1D, MIAJAAN OSTAGA LANE. KOLKATA-700017', '', '', '', '', '', '8336846305', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8336846305', '8336846305', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(304, 1, '', '', 'SHAZEE SULTAN', '2011-03-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1308', '1308', '', '', '', 'SULTAN AHMED', '', 'SHABA SULTAN', '', '12, CICUS OW, KOL-17', '', '', '', '', '', '9831016722', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831016722', '9831016722', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(305, 1, '', '', 'SHEZA NOO ABEDIN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1446', '1446', '', '', '', 'SOHAN ABEDIN', '', 'SABANA ABEDIN', '', 'HEITAGE APATMENT. BLOCK 6, FLAT 3A. 72, TILJALA OAD, KOL - 46', '', '', '', '', '', '9007517393', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007517393', '9007517393', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(306, 1, '', '', 'SUMAIYA BANO', '2010-09-26', '', 'FEMALE', '', '', '', '', '', '', '5', '1250', '1250', '', '', '', 'PEVEZ HASIM', '', 'AFSANA BEGUM', '', '2B, D BIESH GUHA STEET KOL-17', '', '', '', '', '', '9903892786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903892786', '9903892786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(307, 1, '', '', 'TUBA AHMED', '2011-02-14', '', 'FEMALE', '', '', '', '', '', '', '5', '1429', '1429', '', '', '', 'MOHAMMAD AJU', '', 'NASIM BEGUM', '', '30/H/3, DOCTO SUESH SAKA OAD KOL-14', '', '', '', '', '', '9674832625', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674832625', '9674832625', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(308, 1, '', '', 'WAJIHA ZEHA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1313', '1313', '', '', '', 'MD IFTEKHA ALAM', '', 'NAFISA ALAM', '', '105/2, KAAYA OAD, KOLKATA - 17', '', '', '', '', '', '9088399184', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9088399184', '9088399184', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(309, 1, '', '', 'YUSHA KHAN', '2010-09-10', '', 'FEMALE', '', '', '', '', '', '', '5', '1370', '1370', '', '', '', 'IMAN KHAN', '', 'NAFISA KHAN', '', 'B,40/H/5 SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '9874631269', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874631269', '9874631269', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(310, 1, '', '', 'ZAIMA HUSSAIN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1472', '1472', '', '', '', 'MD SHAHID HUSSAIN', '', 'NAZNEEN HUSSAIN', '', '11, NAWAB SIAJUL ISLAM LANE, KOLKATA - 700016', '', '', '', '', '', '9830308565', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830308565', '9830308565', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(311, 1, '', '', 'ZAINAB FATIMA', '2010-12-16', '', 'FEMALE', '', '', '', '', '', '', '5', '1366', '1366', '', '', '', 'MD.SHAKEEL ALAM', '', 'SHAZIA SANAM', '', '10/1B, TOPSIA OAD 2nd LANE  KOL-39', '', '', '', '', '', '8981403412', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8981403412', '8981403412', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(312, 1, '', '', 'ZAIA FATIMA', '2011-05-05', '', 'FEMALE', '', '', '', '', '', '', '5', '1311', '1311', '', '', '', 'FIOZ AHMED', '', 'AFIN FIOZ', '', '9,G.J. KHAN OAD KOL-39', '', '', '', '', '', '9831792192', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831792192', '9831792192', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(313, 1, '', '', 'ZOYA ALAM - 2', '2010-09-10', '', 'FEMALE', '', '', '', '', '', '', '5', '1405', '1405', '', '', '', 'SHAHANAWAZ ALAM', '', 'MUMTAZ BEGUM', '', ' 16/H/2,BIGHT STEET KOL-17', '', '', '', '', '', '8420499120', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420499120', '8420499120', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(314, 1, '', '', 'HANIA FATMA ', '2010-09-28', '', 'FEMALE', '', '', '', '', '', '', '5', '1523', '1523', '', '', '', 'ABID HOSSAIN', '', 'SHAHEEN FATMA', '', '84 A/1, TOPSIA OAD KOLKATA 39', '', '', '', '', '', '9903491398', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903491398', '9903491398', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(315, 1, '', '', 'ZAINAB MOIN - YTE', '2010-10-09', '', 'FEMALE', '', '', '', '', '', '', '5', '1525', '1525', '', '', '', 'MD MOINUDDIN', '', 'NUSAT MOIN', '', '27, CANTOPHE LANE KOL 14', '', '', '', '', '', '8981010357', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8981010357', '8981010357', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(316, 1, '', '', 'AAFIYA JAHANGI', '2010-01-04', '', 'FEMALE', '', '', '', '', '', '', '15', '1178', '1178', '', '', '', 'MD.SAFAAZ JAHANGI', '', 'NIKHAT PAVEEN', '', 'I/181, PAHAPU OAD M.A.Z HIGH SCHOOL KOL-24', '', '', '', '', '', '8420870801', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420870801', '8420870801', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(317, 1, '', '', 'AALIMAH ELAHI', '2010-06-14', '', 'FEMALE', '', '', '', '', '', '', '15', '1113', '1113', '', '', '', 'MD.MOOSA ELAHI', '', 'AMAA MOOSA', '', '25A,CICUS AVENUE KOL - 17', '', '', '', '', '', '9748362929', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748362929', '9748362929', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(318, 1, '', '', 'AAMEEN SIDDIQUI', '2009-02-10', '', 'FEMALE', '', '', '', '', '', '', '15', '1096', '1096', '', '', '', 'SK ISHAD ALI', '', 'NAZNEEN PAVEEN', '', '3,A NAWAB ABDUL LATIF STEET KOL-16', '', '', '', '', '', '9748973786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748973786', '9748973786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(319, 1, '', '', 'AAFIYA IFAN', '2009-12-26', '', 'FEMALE', '', '', '', '', '', '', '15', '1549', '1549', '', '', '', 'MD IFAN  ', '', 'MUSSAAT NAZ', '', '5/W, SAPGACHI 1ST LANE, KOLKATA - 700039', '', '', '', '', '', '9748902722', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748902722', '9748902722', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(320, 1, '', '', 'AEEBAH IFAN', '2010-06-26', '', 'FEMALE', '', '', '', '', '', '', '15', '1530', '1530', '', '', '', 'MD IFAN AHMED', '', 'AZOO IFAN', '', '61/B, G.J.KHAN OAD, KOLKATA - 700039', '', '', '', '', '', '9661124201', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9661124201', '9661124201', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(321, 1, '', '', 'ADIBA SHAKIL', '2009-12-24', '', 'FEMALE', '', '', '', '', '', '', '15', '1138', '1138', '', '', '', 'SHAKIL AHMED', '', 'NAZIA YUSUF', '', '8/L TOPSIA 1ST LANE KOL-39', '', '', '', '', '', '9831535418', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831535418', '9831535418', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(322, 1, '', '', 'AFIFA IBAHIM', '2009-06-30', '', 'FEMALE', '', '', '', '', '', '', '15', '1416', '1416', '', '', '', 'SK.IBAHIM', '', 'IZWANA', '', '7/B,H,12 TILJALA LANE KOL-19 (EAK ADI BALLYGUNJ SCHOOL)', '', '', '', '', '', '9831234904', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831234904', '9831234904', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(323, 1, '', '', 'AFZA AKAM', '2010-04-30', '', 'FEMALE', '', '', '', '', '', '', '15', '1409', '1409', '', '', '', 'AKAM HOSSAIN', '', 'UKHSANA KHATOON', '', '32/14, AI CHAAN GHOSH LANE KOL - 39', '', '', '', '', '', '9831672912', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831672912', '9831672912', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(324, 1, '', '', 'AIMAN AZAM', '2009-09-09', '', 'FEMALE', '', '', '', '', '', '', '15', '1363', '1363', '', '', '', 'MD.NAYAB AZAM', '', 'NAHID FATMA', '', '61/C 11, TOPSIA OAD KOL-39', '', '', '', '', '', '9903669646', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903669646', '9903669646', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(325, 1, '', '', 'AKSHA ZIA', '2009-03-20', '', 'FEMALE', '', '', '', '', '', '', '15', '1040', '1040', '', '', '', 'ZIA UL HAQUE', '', 'UBINA ZIA', '', '9, SAPGACHI 1ST LANE, KOL - 39', '', '', '', '', '', '9874185621', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874185621', '9874185621', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(326, 1, '', '', 'AL ISHAA AHMED', '2009-06-04', '', 'FEMALE', '', '', '', '', '', '', '15', '1028', '1028', '', '', '', 'MD KALIM AHMED', '', 'HAMIDA KHAN', '', '17/H/6, BECK BAGAN OW, KOL - 17', '', '', '', '', '', '8013630263', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8013630263', '8013630263', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(327, 1, '', '', 'ALISA AFZAL', '2009-06-25', '', 'FEMALE', '', '', '', '', '', '', '15', '1011', '1011', '', '', '', 'MD AFZAL', '', 'SITAA KHATOON', '', '7/H/5, KASAI PAA LANE KOL - 17', '', '', '', '', '', '7003287492', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003287492', '7003287492', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(328, 1, '', '', 'AMMAAAH FATEMAH', '2009-08-27', '', 'FEMALE', '', '', '', '', '', '', '15', '1046', '1046', '', '', '', 'MEAJ AHMED', '', 'AFA ISAFIL', '', '3, BANSHI DUTTA OAD, KOL-14', '', '', '', '', '', '9831507367', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831507367', '9831507367', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(329, 1, '', '', 'AFA HUSSAIN', '2009-06-26', '', 'FEMALE', '', '', '', '', '', '', '15', '1019', '1019', '', '', '', 'TAHA HUSSAIN', '', 'SHAMIMA BANO', '', '147, NAKEL DANGA MAIN OAD KOL-11', '', '', '', '', '', '9231880325', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9231880325', '9231880325', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(330, 1, '', '', 'AIBA FAOOQUE', '2009-06-25', '', 'FEMALE', '', '', '', '', '', '', '15', '1330', '1330', '', '', '', 'FAOOQUE AZAM', '', 'SHABANA FAOOQUE', '', '1/B/H/5, CHHATU BABU LANE, KOL - 14', '', '', '', '', '', '9331040693', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331040693', '9331040693', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(331, 1, '', '', 'AIBA IMAN', '2010-01-23', '', 'FEMALE', '', '', '', '', '', '', '15', '1136', '1136', '', '', '', 'MD IMAN', '', 'NAZIA PAVEEN', '', '9.G.J.KHAN OAD KOL - 39', '', '', '', '', '', '9038569326', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038569326', '9038569326', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(332, 1, '', '', 'ASMA SIDDIQUA ISMAIL', '2009-08-21', '', 'FEMALE', '', '', '', '', '', '', '15', '1185', '1185', '', '', '', 'MD ANWAUS SAYEED', '', 'SADIA MAIAM', '', '4, JANNAGA 2ND LANE, KOL - 14', '', '', '', '', '', '9831387525', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831387525', '9831387525', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(333, 1, '', '', 'ASAFA IMAN', '2009-06-21', '', 'FEMALE', '', '', '', '', '', '', '15', '970', '970', '', '', '', 'IMAN MAHMOOD', '', 'AFSAA NAZNEE', '', '5/H/6, BIBI BAGAN LANE, KOL - 15', '', '', '', '', '', '9831354267', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831354267', '9831354267', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(334, 1, '', '', 'ATIQAH HAQUE', '2009-12-28', '', 'FEMALE', '', '', '', '', '', '', '15', '1336', '1336', '', '', '', 'MD NOOUL HAQUE', '', 'NUSAT HAQUE', '', '100/H/4/1, DILKUSHA STEET, KOL - 17', '', '', '', '', '', '8420660966', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420660966', '8420660966', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(335, 1, '', '', 'AYESHA ANJUM', '2010-02-12', '', 'FEMALE', '', '', '', '', '', '', '15', '1021', '1021', '', '', '', 'ANJUM JAMIL', '', 'NILOFA NAAZ', '', 'H-17, GHULAM ABBAS LANE, GADEN EACH, KOL-24', '', '', '', '', '', '9038767341', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038767341', '9038767341', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(336, 1, '', '', 'AYESHA ANWA', '2009-06-19', '', 'FEMALE', '', '', '', '', '', '', '15', '1044', '1044', '', '', '', 'MD.ANWA SEAJ', '', 'JUHI PAVEEN', '', 'T-155-J KESHAB CHANDA SEN STEET KOL-9', '', '', '', '', '', '8282881898', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8282881898', '8282881898', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(337, 1, '', '', 'AYESHA BINT SHAHNAWAZ', '2010-07-02', '', 'FEMALE', '', '', '', '', '', '', '15', '1171', '1171', '', '', '', 'SHAHNAWAZ ALI AHMED AI', '', 'ADA SHAISTA SUBBUH', '', '30/B, CANTOPHE LANE, KOL - 14', '', '', '', '', '', '8961102599', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8961102599', '8961102599', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(338, 1, '', '', 'AYESHA IBAHIM', '2009-03-01', '', 'FEMALE', '', '', '', '', '', '', '15', '1251', '1251', '', '', '', 'ABDUL IBAHIM', '', 'SHABNAM BEGUM', '', '15A, MIATAN OSTAGA LANE KOL-17', '', '', '', '', '', '9748871544', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748871544', '9748871544', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(339, 1, '', '', 'FAIZA YASHFEEN', '2009-10-01', '', 'FEMALE', '', '', '', '', '', '', '15', '973', '973', '', '', '', 'SAFAAZ ZAHI', '', 'GULISTAN PAVEEN', '', '464, G T OAD, SHIBPU, HOWAH - 02', '', '', '', '', '', '7003237800', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003237800', '7003237800', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(340, 1, '', '', 'FAHAT SABA ALAM', '2009-08-12', '', 'FEMALE', '', '', '', '', '', '', '15', '1141', '1141', '', '', '', 'MD.SADE ALAM', '', 'SABANA KHATOON', '', '26/5/C G.J KHAN OAD KOLKATA - 39', '', '', '', '', '', '9748099786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748099786', '9748099786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(341, 1, '', '', 'FATIMA BINT ALI KHAN', '2009-06-04', '', 'FEMALE', '', '', '', '', '', '', '15', '1397', '1397', '', '', '', 'MOHD. ALI EZA KHAN', '', 'TABASSUM KHANUM', '', '10, CEMATOIUM STEET, KOL-14', '', '', '', '', '', '9007892241', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007892241', '9007892241', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(342, 1, '', '', 'HAIQA INAM', '2009-11-08', '', 'FEMALE', '', '', '', '', '', '', '15', '1428', '1428', '', '', '', 'MD.INAM UDDIN', '', 'HUSNAA BEGUM', '', '20B, MAKET STEET KOL-87 1ST FLOO', '', '', '', '', '', '8961432713', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8961432713', '8961432713', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(343, 1, '', '', 'HAMSHA KHATOON', '2010-01-02', '', 'FEMALE', '', '', '', '', '', '', '15', '1008', '1008', '', '', '', 'SK NAIMUDDIN ', '', 'AJINA KHATOON', '', '16C SAPGACHI 1ST LANE KOL - 39', '', '', '', '', '', '9748008181', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748008181', '9748008181', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(344, 1, '', '', 'HIBA KHAN', '2009-12-25', '', 'FEMALE', '', '', '', '', '', '', '15', '1427', '1427', '', '', '', 'HASIB KHAN', '', 'SABINA KHAN', '', '1, PEMENTLE STEET KOL-16', '', '', '', '', '', '9674443816', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674443816', '9674443816', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(345, 1, '', '', 'HOOIYA SIDDIQUA', '2009-09-11', '', 'FEMALE', '', '', '', '', '', '', '15', '1126', '1126', '', '', '', 'KHUSHID ANWA', '', 'AYESHA AKHTE', '', '98/H/14, LILNTON STEET KOL-14', '', '', '', '', '', '9339563858', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339563858', '9339563858', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(346, 1, '', '', 'IISHA KHAN', '2009-12-11', '', 'FEMALE', '', '', '', '', '', '', '15', '1022', '1022', '', '', '', 'PAVEJ ALAM KHAN', '', 'NAHID KHAN', '', '1C, CANTOPHE LANE KOL-14', '', '', '', '', '', '9339756843', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339756843', '9339756843', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(347, 1, '', '', 'KULSUM BINT WASIM', '2009-05-25', '', 'FEMALE', '', '', '', '', '', '', '15', '1092', '1092', '', '', '', 'MD WASIM', '', 'BILKES SK', '', '46,H/12, SHAMSUL HUDA OAD KOL- - 17', '', '', '', '', '', '9681661575', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681661575', '9681661575', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(348, 1, '', '', 'KULSUM WASI', '2009-10-13', '', 'FEMALE', '', '', '', '', '', '', '15', '1258', '1258', '', '', '', 'AKHTE ALI WASI', '', 'ASHIDA BEGUM', '', '34/1B LOWE ANGE KOL - 19', '', '', '', '', '', '9831819939', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831819939', '9831819939', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(349, 1, '', '', 'LAMIYA KHAN', '2009-04-18', '', 'FEMALE', '', '', '', '', '', '', '15', '1475', '1475', '', '', '', 'SHAMS BAI KHAN', '', 'SHAGUFTA KHAN', '', '26/1 DEBENDA CHANDA DEY OAD KOL-15', '', '', '', '', '', '9007623588', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007623588', '9007623588', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(350, 1, '', '', 'MAHE NOO KHATOON', '2009-12-22', '', 'FEMALE', '', '', '', '', '', '', '15', '1402', '1402', '', '', '', 'NAUSHAD ALI', '', 'SABA JABEEN', '', '30/7 JHOWTALA OAD KOLK - 17', '', '', '', '', '', '9088070067', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9088070067', '9088070067', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(351, 1, '', '', 'MALAK SHAHID', '2009-11-11', '', 'FEMALE', '', '', '', '', '', '', '15', '1384', '1384', '', '', '', 'SHAHID SAFAAZ', '', 'MUSAAT SHAHID', '', '40,H/1 SHAMSUL HUDA OAD, KOL -17', '', '', '', '', '', '9830972057', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830972057', '9830972057', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(352, 1, '', '', 'MANTASHA SAJID', '2009-05-18', '', 'FEMALE', '', '', '', '', '', '', '15', '1497', '1497', '', '', '', 'MD SAJID AKHTA', '', 'TABBASSUM AA', '', '85/P TOPSIA OAD KOL-39', '', '', '', '', '', '7003191885', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003191885', '7003191885', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(353, 1, '', '', 'MEHA KHAN', '2009-04-26', '', 'FEMALE', '', '', '', '', '', '', '15', '1062', '1062', '', '', '', 'MD.SHAKIL AHMED', '', 'MAJDA KHATOON', '', '8/D, 1ST LANE SANP GACHI ( TOPSIA ) KOL-39', '', '', '', '', '', '9903948680', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903948680', '9903948680', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(354, 1, '', '', 'MEHWISH FEOZE', '2010-01-14', '', 'FEMALE', '', '', '', '', '', '', '15', '1478', '1478', '', '', '', 'MD SOHAIL FEOZE', '', 'MEHEEN SOHAIL', '', '41,B SHAMSUL HUDA OAD, KOL-17', '', '', '', '', '', '7044302343', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7044302343', '7044302343', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(355, 1, '', '', 'AMSHA ANAM', '2009-10-21', '', 'FEMALE', '', '', '', '', '', '', '15', '1090', '1090', '', '', '', 'MD ANAMUL HAQUE', '', 'SHAHEEN PAVEEN', '', 'PIME ESIDENCY. 61B, G J KHAN OAD, KOL - 39', '', '', '', '', '', '9163348182', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163348182', '9163348182', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(356, 1, '', '', 'SAFIA FAIZ ', '2010-06-16', '', 'FEMALE', '', '', '', '', '', '', '15', '1172', '1172', '', '', '', 'FAIZ AHMED', '', 'TAOQEEDA KHATOON', '', '22, KUSTIA MASJID BAI LANE, KOLKATA - 39', '', '', '', '', '', '9007947401', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007947401', '9007947401', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(357, 1, '', '', 'SAA FATMA', '2009-06-28', '', 'FEMALE', '', '', '', '', '', '', '15', '1377', '1377', '', '', '', 'MD IZWAN KHAN', '', 'NASIMA BANO', '', '41D,TOPSIA OAD KOL - 39', '', '', '', '', '', '8240160144', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240160144', '8240160144', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(358, 1, '', '', 'NADIA KHAI', '2010-01-16', '', 'FEMALE', '', '', '', '', '', '', '15', '1565', '1565', '', '', '', 'ABDULLAH', '', 'SHAZIA KHANAM', '', '2B/H/10, D. M.N. CHATTEJEE SAANI, KOLKATA - 700009', '', '', '', '', '', '9681986070', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681986070', '9681986070', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(359, 1, '', '', 'KAINAT ALI', '2008-03-13', '', 'FEMALE', '', '', '', '', '', '', '15', '1536', '1536', '', '', '', 'MD ALI', '', 'LATE. PAVEEN ALI', '', '91, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '8336881531', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8336881531', '8336881531', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(360, 1, '', '', 'ABU SAEED', '2008-01-29', '', 'MALE', '', '', '', '', '', '', '15', '659', '659', '', '', '', 'SK NAJUL', '', 'HASINA KHATOON', '', '13H/11, ELIOT LANE,KOL -16', '9875472682', '', '', '', '', '9875472682', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9875472682', '9875472682', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(361, 1, '', '', 'ASHAMAAN SAYEED', '2009-07-23', '', 'MALE', '', '', '', '', '', '', '15', '1296', '1296', '', '', '', 'MOHAMMED SAYEED', '', 'NAAZNEEN SAYEED', '', '235, TILJALA OAD, KOL - 46', '8820278784', '', '', '', '', '8820278784', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8820278784', '8820278784', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(362, 1, '', '', 'AWAISH MOIN ANSAI', '2009-02-27', '', 'MALE', '', '', '', '', '', '', '15', '1314', '1314', '', '', '', 'SIAJ UDDIN  ', '', 'SHAGUFTA MOIN ANSAI', '', '155/H/4 KESHAB CHANDA SEN STEET KOL- 09', '9903303182', '', '', '', '', '9903303182', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903303182', '9903303182', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(363, 1, '', '', 'BISMIL HOSSAIN', '2009-05-09', '', 'MALE', '', '', '', '', '', '', '15', '1326', '1326', '', '', '', 'JAVED HOSSAIN', '', 'AUNAK PAVEEN', '', '7/H/4, HATI BAGAN OAD KOL-14', '9830763502', '', '', '', '', '9830763502', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830763502', '9830763502', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(364, 1, '', '', 'FAAZ KHAN', '2009-12-29', '', 'MALE', '', '', '', '', '', '', '15', '1137', '1137', '', '', '', 'ANZA KHAN', '', 'UMMATI KHAN', '', '6A, KUSTIA OAD, KOL- 39', '9830837498', '', '', '', '', '9830837498', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830837498', '9830837498', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(365, 1, '', '', 'HUMZA ABBASI', '2010-02-27', '', 'MALE', '', '', '', '', '', '', '15', '1356', '1356', '', '', '', 'NEHAL UDDIN ABBASI', '', 'KAMUN NESHA', '', '22, B H/6 BECK BAGAN OW KOL-17', '9831299284', '', '', '', '', '9831299284', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831299284', '9831299284', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(366, 1, '', '', 'LUQMAN SABAH ISMAIL', '2009-12-06', '', 'MALE', '', '', '', '', '', '', '15', '1168', '1168', '', '', '', 'D.NOOUS SABAH ISMAIL', '', 'AZMAT AA NOO', '', '4, JANNAGA 2ND LANE, KOL - 14', '9831058963', '', '', '', '', '9831058963', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831058963', '9831058963', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(367, 1, '', '', 'MAHID MALLICK', '2009-11-22', '', 'MALE', '', '', '', '', '', '', '15', '992', '992', '', '', '', 'MAIDUL HAQUE', '', 'AJMIA BEGAM', '', '', '9474468131', '', '', '', '', '9474468131', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9474468131', '9474468131', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(368, 1, '', '', 'MD AHSANUL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '15', '1047', '1047', '', '', '', 'MD NASI', '', 'MUSAAT PAVEEN', '', '3/3D/1, MAULANA ABUL KALAM AZAD SAANI, KOL - 11', '9062524710', '', '', '', '', '9062524710', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062524710', '9062524710', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(369, 1, '', '', 'MD ANAS ALI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '15', '1074', '1074', '', '', '', 'MD SHAKIL AHMED', '', 'ESHMA FAHAT', '', '71/C, MOFIDUL ISLAM LANE, KOL - 14', '9038560860', '', '', '', '', '9038560860', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038560860', '9038560860', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(370, 1, '', '', 'MD FADAN', '2010-01-27', '', 'MALE', '', '', '', '', '', '', '15', '969', '969', '', '', '', 'ISTIYAK AHMED', '', 'FAZANA FAIZIE', '', 'NAFIS APAT. BLOCK F. 4TH FLOO. 55/B, G J KHAN OAD, TOPSIA, KOLKATA - 39', '9163012116', '', '', '', '', '9163012116', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163012116', '9163012116', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(371, 1, '', '', 'MD FAHAN ', '2009-02-19', '', 'MALE', '', '', '', '', '', '', '15', '1140', '1140', '', '', '', 'MD. HASHIM', '', 'FAHAT BEGUM', '', '92C/1,TOPSIA OAD KOL - 39', '9339702186', '', '', '', '', '9339702186', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339702186', '9339702186', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(372, 1, '', '', 'MD FAHAN ALI ', '2009-01-18', '', 'MALE', '', '', '', '', '', '', '15', '1151', '1151', '', '', '', 'MD ALI ', '', 'AFEEN SULTANA', '', '4/1/H/7 NAWAB ABDUL LATIF STEET KOL - 16', '9874785315', '', '', '', '', '9874785315', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874785315', '9874785315', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(373, 1, '', '', 'MD IBAHIM ABID', '2009-11-12', '', 'MALE', '', '', '', '', '', '', '15', '1150', '1150', '', '', '', 'MD.ABID', '', 'UBINA TABASSUM', '', '6, ALIMUDDIN STEET KOL-16', '7980797133', '', '', '', '', '7980797133', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980797133', '7980797133', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(374, 1, '', '', 'Md ISHAD ALI', '2009-10-20', '', 'MALE', '', '', '', '', '', '', '15', '1051', '1051', '', '', '', 'MD. ALI', '', 'ESHMA KHATOON', '', '43B, TILJALA OAD KOL - 46', '7890449907', '', '', '', '', '7890449907', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890449907', '7890449907', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(375, 1, '', '', 'MD MAAZ ISHAD', '2009-12-25', '', 'MALE', '', '', '', '', '', '', '15', '1038', '1038', '', '', '', 'MD. ISHAD ALAM', '', 'SHABNUM PAVEEN', '', '41/A, TILJALA LANE, KOL - 39', '9038594824', '', '', '', '', '9038594824', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038594824', '9038594824', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(376, 1, '', '', 'MD AYYANUDDIN', '2009-05-02', '', 'MALE', '', '', '', '', '', '', '15', '1082', '1082', '', '', '', 'MD.BASHA JAME', '', 'OUSHAN AA', '', '14, TOPSIA 2ND LANE, KOL-39', '9883461303', '', '', '', '', '9883461303', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883461303', '9883461303', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(377, 1, '', '', 'MD EHANULLAH', '2009-08-21', '', 'MALE', '', '', '', '', '', '', '15', '1036', '1036', '', '', '', 'ABDUL AHIM', '', 'AZIA BEGUM', '', '4, MOIA STEET, KOL - 17', '9831329239', '', '', '', '', '9831329239', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831329239', '9831329239', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(378, 1, '', '', 'MD SAADAB KHAN', '2009-09-24', '', 'MALE', '', '', '', '', '', '', '15', '1455', '1455', '', '', '', 'ZUBE KHAN', '', 'NASEEN KHATOON', '', '35/A/H/2, WATGUNJ STEET, KOLKATA - 700023', '9883158163', '', '', '', '', '9883158163', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883158163', '9883158163', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(379, 1, '', '', 'MD SHAHID ALAM', '2009-08-02', '', 'MALE', '', '', '', '', '', '', '15', '1352', '1352', '', '', '', 'MD.SADIQUE ALAM', '', 'KAINAT ALAM', '', '22/4A, KABITITHA SAANI KIDDEPU KOL - 23', '8697937149', '', '', '', '', '8697937149', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8697937149', '8697937149', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(380, 1, '', '', 'MD SHAYAAN HOSSAIN', '2009-04-01', '', 'MALE', '', '', '', '', '', '', '15', '1443', '1443', '', '', '', 'MD SIKANDA', '', 'TABASSUM JAHAN', '', '40,H/4 SHAMSUL HUDA OAD KOLKATA - 17', '8100828416', '', '', '', '', '8100828416', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100828416', '8100828416', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(381, 1, '', '', 'MD SOHAIL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '15', '864', '864', '', '', '', 'MD. SHAID', '', 'NASEEN BEGUM', '', '85/Z/1B, TOPSIA OAD, KOL - 39', '9831050963', '', '', '', '', '9831050963', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831050963', '9831050963', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(382, 1, '', '', 'MD TALHA ANSA', '2009-06-15', '', 'MALE', '', '', '', '', '', '', '15', '1089', '1089', '', '', '', 'MD ANSA', '', 'MS HENA KAUSA', '', '2A, TOPSIA OAD KOL - 39', '9874589888', '', '', '', '', '9874589888', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874589888', '9874589888', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(383, 1, '', '', 'MD TAUSIF', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '15', '1056', '1056', '', '', '', 'ASIF IQBAL', '', 'SHAMIMA IQBAL', '', '27A, AGA MEHDI STEET, KOL - 16', '9883555284', '', '', '', '', '9883555284', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883555284', '9883555284', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(384, 1, '', '', 'MD TOUSIF AHMED', '2008-01-30', '', 'MALE', '', '', '', '', '', '', '15', '1006', '1006', '', '', '', 'SHAHABUDDIN AHMED', '', 'HUSNE AA', '', '5C/1 TOPSIA 2ND LANE KOL-39', '9903126219', '', '', '', '', '9903126219', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903126219', '9903126219', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(385, 1, '', '', 'MD. AISH HASHIB', '2009-03-01', '', 'MALE', '', '', '', '', '', '', '15', '1461', '1461', '', '', '', 'MD.HASHIB', '', 'SUFIYA NAZ', '', '24A/3 KUSTIA MASJID BAI KOL39', '9831399136', '', '', '', '', '9831399136', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831399136', '9831399136', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(386, 1, '', '', 'MD. ZAID  ', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '15', '1303', '1303', '', '', '', 'MD SALAUDDIN', '', 'BANO BEGUM', '', '95/2, D LAL MOHAN BHATTACHAJEE OAD, KOL - 14', '9903349553', '', '', '', '', '9903349553', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903349553', '9903349553', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(387, 1, '', '', 'MD. ZAID ALAM', '2008-08-26', '', 'MALE', '', '', '', '', '', '', '15', '1496', '1496', '', '', '', 'MD MAHFOOZ ALAM', '', 'HENA FATMA', '', '42/2A, TOPSIA OAD, KOL - 39', '9831503061', '', '', '', '', '9831503061', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831503061', '9831503061', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(388, 1, '', '', 'MD.ISMAIL', '2009-07-09', '', 'MALE', '', '', '', '', '', '', '15', '1445', '1445', '', '', '', 'MD.KHALIL', '', 'MEHZABIN BANO', '', '52, BECK BAGAN OW KOL-17', '9830930079', '', '', '', '', '9830930079', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830930079', '9830930079', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(389, 1, '', '', 'MD.UZAI SALAHUDDIN', '2009-10-30', '', 'MALE', '', '', '', '', '', '', '15', '1393', '1393', '', '', '', 'MD.SALAHUDDIN ', '', 'BUSHA NAAZ', '', '2/2,TILJALA OAD KOL - 46', '9831187913', '', '', '', '', '9831187913', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831187913', '9831187913', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(390, 1, '', '', 'MOHAMMAD HAAMIZ IMAN', '2009-09-25', '', 'MALE', '', '', '', '', '', '', '15', '1449', '1449', '', '', '', 'MOHAMMED IMAN', '', 'TAANA IMAN', '', '40/A,MOFIDUL ISLAM LANE KOL - 14', '9831693624', '', '', '', '', '9831693624', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831693624', '9831693624', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(391, 1, '', '', 'MOHAMMAD MUKHTAUL BILAL', '2009-04-06', '', 'MALE', '', '', '', '', '', '', '15', '1149', '1149', '', '', '', 'NAUSHAD AKHTA', '', 'NAZIA ZAFA', '', '15A/1, G.J.KHAN OAD, KOL - 29', '9433080078', '', '', '', '', '9433080078', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9433080078', '9433080078', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(392, 1, '', '', 'MOHAMMAD ZAID ABEDIN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '15', '1054', '1054', '', '', '', 'ZAINUL ABEDIN', '', 'CHAMAN AA BEGUM', '', '15/1/1C, MAYU BHANJ OAD, EKBALPOE, KOL - 23', '9163150365', '', '', '', '', '9163150365', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163150365', '9163150365', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(393, 1, '', '', 'MOHAMMED HAMZA', '2009-11-24', '', 'MALE', '', '', '', '', '', '', '15', '1271', '1271', '', '', '', 'WALI MOHAMMED', '', 'SANA ALI', '', '4, CHAMU KHANSAMA LANE KOL - 17', '9903538713', '', '', '', '', '9903538713', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903538713', '9903538713', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(394, 1, '', '', 'MOHD MEZAN HAYAT', '2010-08-15', '', 'MALE', '', '', '', '', '', '', '15', '978', '978', '', '', '', 'MOZAMMIL HAYAT', '', 'ANI SHAHEEN', '', '36/1E/1K, TOPSIA OAD, KOLKATA - 700039', '9007906075', '', '', '', '', '9007906075', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007906075', '9007906075', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(395, 1, '', '', 'MOHD. OSHAN AFTAB', '2009-08-06', '', 'MALE', '', '', '', '', '', '', '15', '1470', '1470', '', '', '', 'AFTAB ALAM', '', 'SAIA AFTAB', '', '19, MCLEOD STEET KOL-17', '9073885930', '', '', '', '', '9073885930', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9073885930', '9073885930', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(396, 1, '', '', 'MD AHYAAN ASFAQUE', '2009-09-05', '', 'MALE', '', '', '', '', '', '', '15', '1552', '1552', '', '', '', 'MD ASFAQUE', '', 'SALEHA ASFAQUE', '', '2/A, DALU SAKA LANE, KOLKATA - 700023', '9007834059', '', '', '', '', '9007834059', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007834059', '9007834059', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(397, 1, '', '', 'UBAID ALI AFZAL', '2009-08-05', '', 'MALE', '', '', '', '', '', '', '15', '1001', '1001', '', '', '', 'GAUHA AFZAL', '', 'SHADAB AFZAL', '', '147, WEST CHOUBAGA (TILJALA LP-14/54) KOLKATA - 700015', '9836007961', '', '', '', '', '9836007961', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836007961', '9836007961', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(398, 1, '', '', 'ZUNAI KHAN', '2009-08-23', '', 'MALE', '', '', '', '', '', '', '15', '1060', '1060', '', '', '', 'JAVED KHAN', '', 'DANISH SHAHEEN KHAN', '', '4/1G CONVENT LANE KOL-15', '9831067155', '', '', '', '', '9831067155', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831067155', '9831067155', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(399, 1, '', '', 'SHADAN WASI', '2008-10-24', '', 'MALE', '', '', '', '', '', '', '15', '1526', '1526', '', '', '', 'MD FAOOQUE WASI', '', 'SHAHINA WASI', '', '13/2 H/1 PATWA BAGAN LANE KOL 09', '9674937707', '', '', '', '', '9674937707', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674937707', '9674937707', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(400, 1, '', '', 'MD. AYYAN KHAN', '2009-08-18', '', 'MALE', '', '', '', '', '', '', '15', '1509', '1509', '', '', '', 'MD. DILSHAD KHAN', '', 'YASMIN KHAN', '', '4,JANNAGA 2ND LANE KOL-14', '7044666695', '', '', '', '', '7044666695', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7044666695', '7044666695', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(401, 1, '', '', 'MUHAMMAD AFZAL SADIQUE', '2010-05-05', '', 'MALE', '', '', '', '', '', '', '15', '1557', '1557', '', '', '', 'LT GHULAM SADIQUE IQBAL', '', 'NAZNEEN JAHAN', '', '23/1/1A, MOFIDUL ISLAM LANE, KOLKATA - 700014', '8334946286', '', '', '', '', '8334946286', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8334946286', '8334946286', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(402, 1, '', '', 'MOHAMMAD ASALAN IQBAL', '2010-09-10', '', 'MALE', '', '', '', '', '', '', '15', '1543', '1543', '', '', '', 'MD ASIF IQBAL', '', 'NAGMA AHMAN', '', '110/H/7B, ELLIOT OAD, KOLKATA - 700016', '6200136191', '', '', '', '', '6200136191', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '6200136191', '6200136191', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(403, 1, '', '', 'ADIBA AHMAN', '2010-01-30', '', 'FEMALE', '', '', '', '', '', '', '16', '1265', '1265', '', '', '', 'HASIBU AHMAN', '', ' SUAIYA EHMAN', '29/A/H/47, PALM AVENUE, KOLKATA - 700019', '29/A/H/47, PALM AVENUE, KOLKATA - 700019', '', '', '', '', '', '9007884212', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007884212', '9007884212', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(404, 1, '', '', 'AFIA HAQUE', '2009-03-30', '', 'FEMALE', '', '', '', '', '', '', '16', '1282', '1282', '', '', '', 'ZIAUL HAQUE', '', 'FIDOUS PAVEEN', '23/A GOA CHAND LANE KOL - 14 3d FLOO', '23/A GOA CHAND LANE KOL - 14 3d FLOO', '', '', '', '', '', '9330954536', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330954536', '9330954536', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(405, 1, '', '', 'AFIFA JABEEN', '2009-10-27', '', 'FEMALE', '', '', '', '', '', '', '16', '1392', '1392', '', '', '', 'IZWANUL AZAM', '', 'UHI GAZALA', '114/E, TOPSIA OAD, KOL-39', '114/E, TOPSIA OAD, KOL-39', '', '', '', '', '', '9903671913', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903671913', '9903671913', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(406, 1, '', '', 'AFSHEEN HASSAN', '2009-10-10', '', 'FEMALE', '', '', '', '', '', '', '16', '1135', '1135', '', '', '', 'ZAHID HUSSAN', '', 'NAZZISH HASSAN', '3/1, A, NIL MADHAB SEN LANE KOL-17', '3/1, A, NIL MADHAB SEN LANE KOL-17', '', '', '', '', '', '7980842092', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980842092', '7980842092', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(407, 1, '', '', 'AMIAN HUSSAIN', '2009-08-31', '', 'FEMALE', '', '', '', '', '', '', '16', '981', '981', '', '', '', 'LATE AMIUDDIN HUSSAIN', '', 'AMIN HUSSAIN', '1E, TILJALA LANE, KOLKATA - 39', '1E, TILJALA LANE, KOLKATA - 39', '', '', '', '', '', '7980816434', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980816434', '7980816434', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(408, 1, '', '', 'AFIYA ASHID', '2009-12-26', '', 'FEMALE', '', '', '', '', '', '', '16', '1268', '1268', '', '', '', 'ABDUL ASHID', '', 'NASIMA ASHID', '66, BIGHT STEET, KOL - 19', '66, BIGHT STEET, KOL - 19', '', '', '', '', '', '9831154206', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831154206', '9831154206', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(409, 1, '', '', 'AYESHA IMAM', '2010-03-01', '', 'FEMALE', '', '', '', '', '', '', '16', '1469', '1469', '', '', '', 'AZHA IMAM', '', 'IZWANA IMAM', '4, TILJALA LANE KOL-39', '4, TILJALA LANE KOL-39', '', '', '', '', '', '9331456409', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331456409', '9331456409', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(410, 1, '', '', 'FAMIA TAHEEM', '2009-04-05', '', 'FEMALE', '', '', '', '', '', '', '16', '1364', '1364', '', '', '', 'MD IFTEKHA ALAM', '', 'ALIYA KHANAM', '23,A MOFIDUL ISLAM LANE KOLKATA -14', '23,A MOFIDUL ISLAM LANE KOLKATA -14', '', '', '', '', '', '7044745632', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7044745632', '7044745632', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(411, 1, '', '', 'FATIMAH ESHAL AZAM', '2009-09-08', '', 'FEMALE', '', '', '', '', '', '', '16', '1320', '1320', '', '', '', 'MOHAMMED AZAM', '', 'SHADAB NOO ISLAM', '29, ELLIOT LANE KOLKATA - 16 ', '29, ELLIOT LANE KOLKATA - 16 ', '', '', '', '', '', '9903274819', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903274819', '9903274819', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(412, 1, '', '', 'HUMAIAH INTEKHAB', '2009-11-20', '', 'FEMALE', '', '', '', '', '', '', '16', '1283', '1283', '', '', '', 'D. SK. INTEKA ALAM', '', 'MAMTAJ KHATUN', '4/2/H/2, MOMINPU OAD, KOL -23', '4/2/H/2, MOMINPU OAD, KOL -23', '', '', '', '', '', '9143057533', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9143057533', '9143057533', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(413, 1, '', '', 'MAHOSE ANA', '2009-06-22', '', 'FEMALE', '', '', '', '', '', '', '16', '1422', '1422', '', '', '', 'MD.TAJUDDIN', '', 'MANTASHA BEGUM', '18Z/2 TOPSIA OAD KOL-39', '18Z/2 TOPSIA OAD KOL-39', '', '', '', '', '', '9330865073', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330865073', '9330865073', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(414, 1, '', '', 'MASOOA FATIMA', '2009-01-13', '', 'FEMALE', '', '', '', '', '', '', '16', '1338', '1338', '', '', '', 'MD.WASIM ', '', 'ZUBIYA PAVEEN', '5E, PALM AVENUE KOL-19', '5E, PALM AVENUE KOL-19', '', '', '', '', '', '9831109920', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831109920', '9831109920', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(415, 1, '', '', 'MUBASAIN BANU', '2009-11-28', '', 'FEMALE', '', '', '', '', '', '', '16', '1487', '1487', '', '', '', 'HAJI MD.JAMIL AHMED', '', 'SABE NOO BANU', '52 BECK BAGAN OW KOL-17', '52 BECK BAGAN OW KOL-17', '', '', '', '', '', '9831354165', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831354165', '9831354165', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(416, 1, '', '', 'NUZHAT HAFIZ', '2009-07-05', '', 'FEMALE', '', '', '', '', '', '', '16', '1375', '1375', '', '', '', 'SK.HAFIZUDDIN', '', 'AFAT HAFIZ', '25,C.N.OY OAD KOL - 39', '25,C.N.OY OAD KOL - 39', '', '', '', '', '', '9836909903', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836909903', '9836909903', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(417, 1, '', '', 'QAMA SIDDIQUA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '16', '1453', '1453', '', '', '', 'SYED QUAMUZZAMA', '', 'IZWANA PAVEEN', '47A, NOTH ANGE, KOLKATA - 700017', '47A, NOTH ANGE, KOLKATA - 700017', '', '', '', '', '', '9007939493', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007939493', '9007939493', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(418, 1, '', '', 'AHBA AFEEN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '16', '1315', '1315', '', '', '', 'AHBA HUSSAIN', '', 'NAZMA BEGUM', '3/20, NAKELDANGA MAIN OAD KOLKATA-11', '3/20, NAKELDANGA MAIN OAD KOLKATA-11', '', '', '', '', '', '9748840122', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748840122', '9748840122', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(419, 1, '', '', 'AHELA SAJJAD', '2009-12-12', '', 'FEMALE', '', '', '', '', '', '', '16', '1355', '1355', '', '', '', 'MD SAJJAD ALAM', '', 'NOO AFSHAN', '47/48,TILJALA  MASJID BAI LANE KOL - 39', '47/48,TILJALA  MASJID BAI LANE KOL - 39', '', '', '', '', '', '9830565832', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830565832', '9830565832', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(420, 1, '', '', 'AKHSHANDA ALAM', '2009-10-20', '', 'FEMALE', '', '', '', '', '', '', '16', '1059', '1059', '', '', '', 'ZUBAI ALAM', '', 'TAANNUM ALAM', '35/3/D, TOPSIA OAD, KOL - 39', '35/3/D, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9903194100', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903194100', '9903194100', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(421, 1, '', '', 'IDA ALAM', '2009-08-20', '', 'FEMALE', '', '', '', '', '', '', '16', '1473', '1473', '', '', '', 'MD. AFTAB ALAM', '', 'YASMIN ALAM', '2L, ADHA GOBINDA SAHA LANE, KOL - 17', '2L, ADHA GOBINDA SAHA LANE, KOL - 17', '', '', '', '', '', '9007600587', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007600587', '9007600587', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(422, 1, '', '', 'UMAAN ALAM', '2009-10-13', '', 'FEMALE', '', '', '', '', '', '', '16', '1231', '1231', '', '', '', 'MD. ANAS ALAM', '', 'BENAZI KHAN', '80 A/12 TOPSIA OAD KOLKATA 700039', '80 A/12 TOPSIA OAD KOLKATA 700039', '', '', '', '', '', '6290215207', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '6290215207', '6290215207', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(423, 1, '', '', 'SADIQUA ALAM', '2010-02-12', '', 'FEMALE', '', '', '', '', '', '', '16', '1442', '1442', '', '', '', 'JAHANGI ALAM', '', 'SHAMIMA ALAM', '4B/4 TOPSIA 2ND LANE KOL-39', '4B/4 TOPSIA 2ND LANE KOL-39', '', '', '', '', '', '9903314941', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903314941', '9903314941', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(424, 1, '', '', 'SAMIA TANVEE', '2009-08-22', '', 'FEMALE', '', '', '', '', '', '', '16', '1106', '1106', '', '', '', 'TANVEE ALI ', '', 'ASHIFTA TANVEE', '27A, PICNIC GADEN OAD KOL - 39', '27A, PICNIC GADEN OAD KOL - 39', '', '', '', '', '', '9884973043', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9884973043', '9884973043', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(425, 1, '', '', 'SEHISH AKHTE', '2009-09-07', '', 'FEMALE', '', '', '', '', '', '', '16', '1034', '1034', '', '', '', 'IMTIAZ AKHTE', '', 'ASHIA AKHTE', '36/E, AGHA MEHDI STEET KOL - 16', '36/E, AGHA MEHDI STEET KOL - 16', '', '', '', '', '', '8961611236', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8961611236', '8961611236', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(426, 1, '', '', 'SHAMEEN FATMA', '2009-09-16', '', 'FEMALE', '', '', '', '', '', '', '16', '1087', '1087', '', '', '', 'MD SHAIQUE', '', 'SHABNAM SULTANA', '114/1, COLLIN STEET, KOL - 16', '114/1, COLLIN STEET, KOL - 16', '', '', '', '', '', '9007291430', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007291430', '9007291430', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(427, 1, '', '', 'SK.SAHEENA BEGUM', '2010-10-22', '', 'FEMALE', '', '', '', '', '', '', '16', '1100', '1100', '', '', '', 'SK.OUSHAN ALI', '', 'SALMA KHATOON', '37, TOPSIA OAD KOL-46', '37, TOPSIA OAD KOL-46', '', '', '', '', '', '9143348668', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9143348668', '9143348668', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(428, 1, '', '', 'SUJAN KHAN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '16', '1400', '1400', '', '', '', 'MUJIBA AHMAN KHAN', '', 'SAHANAA BEGUM', '6/2, M.M.ALI OAD. KOLKATA-700023', '6/2, M.M.ALI OAD. KOLKATA-700023', '', '', '', '', '', '9831615661', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831615661', '9831615661', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(429, 1, '', '', 'SUMBUL TALHA', '2019-02-06', '', 'FEMALE', '', '', '', '', '', '', '16', '1463', '1463', '', '', '', 'TALHA TANWI', '', 'ASHI TALHA', '70C/H/1, TILJALA OAD, KOLKATA - 46', '70C/H/1, TILJALA OAD, KOLKATA - 46', '', '', '', '', '', '8420266017', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420266017', '8420266017', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(430, 1, '', '', 'SYEDA DAAB', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '16', '1328', '1328', '', '', '', 'MD ALAM', '', 'MEHJABEEN ALAM', '46A, BIGHT STEET. KOLKATA-700017', '46A, BIGHT STEET. KOLKATA-700017', '', '', '', '', '', '9748435398', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748435398', '9748435398', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(431, 1, '', '', 'TAAHIAH FAATIMAH', '2009-04-02', '', 'FEMALE', '', '', '', '', '', '', '16', '1212', '1212', '', '', '', 'TAIQUE SHAKEEL', '', 'FAAH AHMED', '3/7A, GEEN PAK,TILJALA LANE,. KOL - 39', '3/7A, GEEN PAK,TILJALA LANE,. KOL - 39', '', '', '', '', '', '9883250124', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883250124', '9883250124', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(432, 1, '', '', 'TUBA AMAN', '2009-04-05', '', 'FEMALE', '', '', '', '', '', '', '16', '1413', '1413', '', '', '', 'MD.NEMATULLAH ANSAI', '', 'AKHTAI KHATOON', '6, JAN NAGA OAD, KOL- 17', '6, JAN NAGA OAD, KOL- 17', '', '', '', '', '', '9831240901', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831240901', '9831240901', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(433, 1, '', '', 'UMA SIDDIQUE', '2010-02-05', '', 'FEMALE', '', '', '', '', '', '', '16', '1207', '1207', '', '', '', 'IMAN AHMED SIDDIQUE', '', 'ULFAT JAHAN', '11/2 H/14, MOULANA MOHMMAD ALI KOL -23', '11/2 H/14, MOULANA MOHMMAD ALI KOL -23', '', '', '', '', '', '9831330319', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831330319', '9831330319', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(434, 1, '', '', 'UMANAH SIDDIQUE', '2009-09-11', '', 'FEMALE', '', '', '', '', '', '', '16', '1088', '1088', '', '', '', 'MD ABU BAK SIDDIQUE', '', 'MS IFAT SIDDIQUE', ' 16/EC.N. OY OAD KOL- 39', ' 16/EC.N. OY OAD KOL- 39', '', '', '', '', '', '9883920696', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883920696', '9883920696', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(435, 1, '', '', 'UZAIA MAHMOOD', '2009-12-10', '', 'FEMALE', '', '', '', '', '', '', '16', '1259', '1259', '', '', '', 'SK MAHMOOD', '', 'AHAMATI BEGUM', '52B, G J KHAN OAD, KOLKATA - 700039', '52B, G J KHAN OAD, KOLKATA - 700039', '', '', '', '', '', '9831895536', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831895536', '9831895536', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(436, 1, '', '', 'YASHFIN NIZAM', '2009-09-12', '', 'FEMALE', '', '', '', '', '', '', '16', '1340', '1340', '', '', '', 'SK.NIZAMUDDIN', '', 'SHAMIN NIZAM', '29A/H/47 PALM AVENUE KOL - 19', '29A/H/47 PALM AVENUE KOL - 19', '', '', '', '', '', '7003901337', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003901337', '7003901337', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(437, 1, '', '', 'YASHAH ALAM', '2009-03-16', '', 'FEMALE', '', '', '', '', '', '', '16', '1421', '1421', '', '', '', 'ISHAD ALAM', '', 'NAFISA ALAM', '7,KOMEDAN BAGAN LANE KOL - 16', '7,KOMEDAN BAGAN LANE KOL - 16', '', '', '', '', '', '9903007649', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903007649', '9903007649', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(438, 1, '', '', 'ZAAA AHMED', '2009-07-29', '', 'FEMALE', '', '', '', '', '', '', '16', '1341', '1341', '', '', '', 'MOHAMMED ZAFA', '', 'ESHMA ZAFA', 'B/29/C/H/3, PALM AVENUE, KOL - 19', 'B/29/C/H/3, PALM AVENUE, KOL - 19', '', '', '', '', '', '9007871001', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007871001', '9007871001', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(439, 1, '', '', 'ZAINAB OMA IBAHIM', '2009-08-14', '', 'FEMALE', '', '', '', '', '', '', '16', '1166', '1166', '', '', '', 'MD OMA IBAHIM', '', 'SADAF OMA', '3, JANNAGA 2ND LANE,  KOL - 14', '3, JANNAGA 2ND LANE,  KOL - 14', '', '', '', '', '', '9836378987', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836378987', '9836378987', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(440, 1, '', '', 'ZAINAB ZAMA', '2010-02-19', '', 'FEMALE', '', '', '', '', '', '', '16', '1300', '1300', '', '', '', 'MD QAMUZZAMA', '', 'SABINA ALI', '168/E TILJALA OAD KOL - 46', '168/E TILJALA OAD KOL - 46', '', '', '', '', '', '8585812454', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8585812454', '8585812454', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(441, 1, '', '', 'ZOYA ASHFAQUE', '2010-04-25', '', 'FEMALE', '', '', '', '', '', '', '16', '1426', '1426', '', '', '', 'MD ASHFAQUE', '', 'ANJUM ASHFAQUE', '16H/4, BECK BAGAN OW. KOLKATA - 700017', '16H/4, BECK BAGAN OW. KOLKATA - 700017', '', '', '', '', '', '8420320443', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420320443', '8420320443', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(442, 1, '', '', 'ZUNAIAH AHMED', '2009-07-25', '', 'FEMALE', '', '', '', '', '', '', '16', '1390', '1390', '', '', '', 'AFI AHMED', '', 'UBINA AFI', '153, PAK STEET, KOL - 17(ALI MANSION 1st FLOO)', '153, PAK STEET, KOL - 17(ALI MANSION 1st FLOO)', '', '', '', '', '', '8240404398', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240404398', '8240404398', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(443, 1, '', '', 'TUZZAEN HUSSAIN', '2009-02-21', '', 'FEMALE', '', '', '', '', '', '', '16', '1697', '1697', '', '', '', 'MD SAJID HUSSAIN', '', 'NOO JAHAN HUSSAIN', '148/A/H/5, CENTAL AVENUE, KOLKATA - 700007', '148/A/H/5, CENTAL AVENUE, KOLKATA - 700007', '', '', '', '', '', '9339730982', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339730982', '9339730982', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(444, 1, '', '', 'UKAYA KHAN - TF CAU', '2009-10-16', '', 'FEMALE', '', '', '', '', '', '', '16', '1720', '1720', '', '', '', 'MUSHTAQUE KHAN', '', 'NOOSABHA KHATOON', '7B, NEW KASIA BAGAN LANE, KOLKATA - 700017', '7B, NEW KASIA BAGAN LANE, KOLKATA - 700017', '', '', '', '', '', '9007321328', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007321328', '9007321328', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(445, 1, '', '', 'AHSN INTEKHAB DUANI', '2009-11-30', '', 'MALE', '', '', '', '', '', '', '16', '1290', '1290', '', '', '', 'ABDUL KALAM', '', 'HEENA DUANI', '', '8/1 AHII PUKU 1ST LANE KOLKATA -19', '', '', '', '', '', '9748045838', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748045838', '9748045838', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(446, 1, '', '', 'AIZ ALI', '2010-01-17', '', 'MALE', '', '', '', '', '', '', '16', '1373', '1373', '', '', '', 'MD.ISHAD ALI', '', 'NAJMUL ALI', '', '7B/H/9, TILJALA LANE, KOL-19', '', '', '', '', '', '9748424340', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748424340', '9748424340', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(447, 1, '', '', 'ATIF SAMAD', '2008-11-20', '', 'MALE', '', '', '', '', '', '', '16', '1468', '1468', '', '', '', 'ABDUL SAMAD', '', 'SAJIDA SIDDIQUE', '', '17/12,TOPSIA OAD KOL - 39 (NEA BAITUL MUAZZAM MASJID)', '', '', '', '', '', '9933475540', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9933475540', '9933475540', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(448, 1, '', '', 'AYAAZ AHAMED', '2009-11-24', '', 'MALE', '', '', '', '', '', '', '16', '1456', '1456', '', '', '', 'IMTIYAZ AHMED', '', 'FAIDA BEGUM', '', '45/1B BIGHT STEET KOL-17', '', '', '', '', '', '9903291737', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903291737', '9903291737', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(449, 1, '', '', 'AYAN KHAN', '2009-04-01', '', 'MALE', '', '', '', '', '', '', '16', '1482', '1482', '', '', '', 'SIKANDA KHAN ', '', 'UBY PAVEEN', '', '7B,H/6, DEHI SEAMPU OAD KOL - 14', '', '', '', '', '', '7890908196', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890908196', '7890908196', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(450, 1, '', '', 'IMAN ALAM', '2009-05-07', '', 'MALE', '', '', '', '', '', '', '16', '1359', '1359', '', '', '', 'ISHTIAQUE ALAM', '', 'DAAKSHAN ANJUM', '', '10A,ANJUMAN OAD KOL-14', '', '', '', '', '', '9903305915', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903305915', '9903305915', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(451, 1, '', '', 'MD ALI ISLAM', '2009-02-27', '', 'MALE', '', '', '', '', '', '', '16', '1180', '1180', '', '', '', 'MD.NAZUL ISLAM', '', 'TAMANNA PAVEEN', '', '30/1/H/1, D SUESH SAKA OAD KOL - 14', '', '', '', '', '', '9339000591', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339000591', '9339000591', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(452, 1, '', '', 'MOHAMMAD AMMA HEYAT', '2009-11-12', '', 'MALE', '', '', '', '', '', '', '16', '1323', '1323', '', '', '', 'NADIM HEYAT', '', 'SHAFAQUE HEYAT', '', '47/1/H/1, SI SYED AHMED OAD, KOL - 14', '', '', '', '', '', '9831253842', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831253842', '9831253842', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(453, 1, '', '', 'MD AYAN ALI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '16', '1417', '1417', '', '', '', 'MD ASHAD ALI', '', 'SITAA KHATOON', '', '3/H/6, JHOWTALA LANE, KOL - 17', '', '', '', '', '', '9831059468', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831059468', '9831059468', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(454, 1, '', '', 'MD HANZALA', '2010-01-31', '', 'MALE', '', '', '', '', '', '', '16', '974', '974', '', '', '', 'FIOJ ALAM', '', 'HENA KAUSA', '', '463, G T OAD, SHIBPU, HOWAH - 02', '', '', '', '', '', '9163030223', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163030223', '9163030223', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(455, 1, '', '', 'MD AZA', '2009-07-27', '', 'MALE', '', '', '', '', '', '', '16', '1365', '1365', '', '', '', 'MD FAOOQUE', '', 'SHAFI NAAZ', '', '46, BIGHT STEET, KOL-17', '', '', '', '', '', '9831513639', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831513639', '9831513639', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(456, 1, '', '', 'MD. ATAZA HASNAT', '2010-01-31', '', 'MALE', '', '', '', '', '', '', '16', '1353', '1353', '', '', '', 'ABUL HASNAT', '', 'NADA KHATOON', '', '50A/1B, DIAMOND HABOU OAD, KOL - 27', '', '', '', '', '', '9883272290', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883272290', '9883272290', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(457, 1, '', '', 'MD. HAMMAD HUSSAIN', '2010-01-15', '', 'MALE', '', '', '', '', '', '', '16', '1378', '1378', '', '', '', 'MD.TABAIZ', '', 'TAANA TAHSEEN', '', '9,KASAB BASTI 2ND LANE NAKELDANGA KOL-11', '', '', '', '', '', '9123832795', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9123832795', '9123832795', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(458, 1, '', '', 'MD. KAMIL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '16', '1263', '1263', '', '', '', 'MD ANWA', '', 'HOMA PAVEEN', '', '25/Q, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9831760231', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831760231', '9831760231', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(459, 1, '', '', 'MD. MEEZAN ALI', '2009-08-19', '', 'MALE', '', '', '', '', '', '', '16', '1447', '1447', '', '', '', 'ALI ASLAM', '', 'SHAKA PAVEEN', '', '2/H TILJALA LANE KOL-19', '', '', '', '', '', '8444930422', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8444930422', '8444930422', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(460, 1, '', '', 'MD. SAMI SAJID', '2007-05-24', '', 'MALE', '', '', '', '', '', '', '16', '1407', '1407', '', '', '', 'MD.SAJID MAHTAB', '', 'TAMANNA PAVEEN', '', '155, KAAYA OAD, KOL-17', '', '', '', '', '', '9748771621', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748771621', '9748771621', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(461, 1, '', '', 'MD. ZAID', '2009-09-19', '', 'MALE', '', '', '', '', '', '', '16', '1401', '1401', '', '', '', 'MD. KASHIF ', '', 'NIKHAT BANO', '', '89D, SHAKESPEAE SAANI KOL - 17', '', '', '', '', '', '8967061310', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8967061310', '8967061310', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(462, 1, '', '', 'MD. ZEESHANUDDIN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '16', '1371', '1371', '', '', '', 'MD BADUDDIN', '', 'NIKHAT PAVEEN', '', '16/B, BECK BAGAN OW. KOLKATA - 700016', '', '', '', '', '', '9883222459', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883222459', '9883222459', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(463, 1, '', '', 'MD.ANAS', '2010-03-01', '', 'MALE', '', '', '', '', '', '', '16', '1208', '1208', '', '', '', 'MD.ASLAM', '', 'AYESHA KHATOON', '', '1/T, WESH CHOWBAGA KHUSNUMA MAUZIL 2ND FLOO KOL- 100', '', '', '', '', '', '6290004684', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '6290004684', '6290004684', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(464, 1, '', '', 'MD.ASHAIB TASLIM', '2009-03-24', '', 'MALE', '', '', '', '', '', '', '16', '1434', '1434', '', '', '', 'MD.TASLIM', '', 'JAHANAA BEGUM', '', '16/D,BECKBAGAN OW KOL-17', '', '', '', '', '', '9831349711', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831349711', '9831349711', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(465, 1, '', '', 'MD.HAMZA ALAM', '2009-04-02', '', 'MALE', '', '', '', '', '', '', '16', '1465', '1465', '', '', '', 'MOHD.MEAJ ALAM', '', 'NASEEN NAAZ', '', '52A, SHAMSUL HUDA OAD, KOL-17', '', '', '', '', '', '9339785805', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339785805', '9339785805', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(466, 1, '', '', 'MEEZAN MOHAMMAD MEAJ', '2010-03-22', '', 'MALE', '', '', '', '', '', '', '16', '1479', '1479', '', '', '', 'MOHAMMAD MEAJ AHMED', '', 'SHAHZADI BEGUM', '', '16, SHAMSUL HUDA OAD, KOL - 17', '', '', '', '', '', '9831904603', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831904603', '9831904603', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(467, 1, '', '', 'MICAHEEL HUSSAIN', '2009-06-16', '', 'MALE', '', '', '', '', '', '', '16', '1454', '1454', '', '', '', 'IQBAL HUSSAIN', '', 'TAANA BEGUM', '', '9,TILJALA LANE KOL - 39', '', '', '', '', '', '9831997048', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831997048', '9831997048', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(468, 1, '', '', 'MOBAAK KHAN', '2008-04-10', '', 'MALE', '', '', '', '', '', '', '16', '1367', '1367', '', '', '', 'AMJAN KHAN', '', 'AIFA KHAN', '', '36/A PALM AVENUE KOLKATA - 19', '', '', '', '', '', '9830044862', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830044862', '9830044862', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(469, 1, '', '', 'MOHAMMED ABUBACKE FAUK', '2008-10-20', '', 'MALE', '', '', '', '', '', '', '16', '1304', '1304', '', '', '', 'SIKANDA BACHA', '', 'FATHIMA BIBI', '', '16A, TILJALA LANE, KOL - 39 FAZANA BUILDING NEA NISA MASJID', '', '', '', '', '', '9163930101', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163930101', '9163930101', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(470, 1, '', '', 'MOHAMMED BUHAAN ALIM', '2009-04-14', '', 'MALE', '', '', '', '', '', '', '16', '1274', '1274', '', '', '', 'ASIF ALIM', '', 'NAJIBA ALIM', '', '15, LOWE ANGE,KOL-17', '', '', '', '', '', '9123098921', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9123098921', '9123098921', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(471, 1, '', '', 'MUZAMMIL IQBAL', '2009-07-02', '', 'MALE', '', '', '', '', '', '', '16', '1142', '1142', '', '', '', 'IQBAL AHMED', '', 'SHAGUFTA IQBAL', '', '50/H/2,MUFIDUL ISLAM LANE KOL - 14', '', '', '', '', '', '9331707549', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331707549', '9331707549', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(472, 1, '', '', 'QUAYAAMUDDIN AHMED', '2008-01-01', '', 'MALE', '', '', '', '', '', '', '16', '1285', '1285', '', '', '', 'KAMALUDDIN AHMED', '', 'PAPIA AHMED', '', '4, MOMINPU OAD KOL - 23', '', '', '', '', '', '9830702309', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830702309', '9830702309', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(473, 1, '', '', 'AYYAN FIOZ', '2008-09-07', '', 'MALE', '', '', '', '', '', '', '16', '1423', '1423', '', '', '', 'FIOZ AKHTE', '', 'AFEEN SABA', '', '24, LINTON STEET, KOL - 14', '', '', '', '', '', '8584881706', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8584881706', '8584881706', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(474, 1, '', '', 'SK ANASUDDIN', '2009-05-03', '', 'MALE', '', '', '', '', '', '', '16', '1255', '1255', '', '', '', 'SK.SAHABUDDIN', '', 'OSHNI BEGUM', '', '19 A/1 G.J KHAN OAD KOL-39', '', '', '', '', '', '9831264742', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831264742', '9831264742', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(475, 1, '', '', 'SK AYAN ULLHA', '2009-11-08', '', 'MALE', '', '', '', '', '', '', '16', '1495', '1495', '', '', '', 'SK.KHALIL ULLHA', '', ' FAHAT KHAN', '', '15/1B SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '9163460372', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163460372', '9163460372', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(476, 1, '', '', 'SK. ALYAAN', '2019-02-06', '', 'MALE', '', '', '', '', '', '', '16', '1360', '1360', '', '', '', 'LATE SK SHAKIL', '', 'TAANA BEGUM', '', '51B, TILJALA LANE, KOLKATA - 46', '', '', '', '', '', '9046611834', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9046611834', '9046611834', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(477, 1, '', '', 'SK. GOLAM MUSTOFA ', '2009-05-23', '', 'MALE', '', '', '', '', '', '', '16', '1444', '1444', '', '', '', 'SK. GOLAM SABI', '', 'FIOZA BEGUM', '', '16/1/H/1, BIGHT STEET KOL - 17', '', '', '', '', '', '9831694421', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831694421', '9831694421', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(478, 1, '', '', 'ZAID AHMED', '2008-08-18', '', 'MALE', '', '', '', '', '', '', '16', '1376', '1376', '', '', '', 'SHAKIL AHMED', '', 'NAZIA AHMED', '', '42/CH/3, TILJALA OAD KOL-46', '', '', '', '', '', '9903422319', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903422319', '9903422319', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(479, 1, '', '', 'ZAYAN KHAN', '2010-02-15', '', 'MALE', '', '', '', '', '', '', '16', '1272', '1272', '', '', '', 'ABDULLAH KHAN', '', 'SHAFEEQA KHAN', '', '12/ELLIOT LANE KOL-16', '', '', '', '', '', '7596922210', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7596922210', '7596922210', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(480, 1, '', '', 'MD AQDAS ALTAF', '2010-01-27', '', 'MALE', '', '', '', '', '', '', '16', '1527', '1527', '', '', '', 'MD ALTAF AHMED', '', 'FAZANA ALTAF', '', '39/H/3 SHAMSUL HUDA OAD KOL 17', '', '', '', '', '', '9748622140', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748622140', '9748622140', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(481, 1, '', '', 'SAAD BIN OME', '2009-10-13', '', 'MALE', '', '', '', '', '', '', '16', '1717', '1717', '', '', '', 'MD MUJAHID OME', '', 'SULEKHA OME', '', '8A, CHAMU KHANSAMA LANE, KOLKATA - 700017', '', '', '', '', '', '8444011646', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8444011646', '8444011646', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(482, 1, '', '', 'ADIBA SHAFIQUE', '2009-02-26', '', 'FEMALE', '', '', '', '', '', '', '6', '944', '944', '', '', '', 'SHAFIQULLAH', '', 'FAHAT JABEEN', '', '70C/4/2, TILJALA OAD, KOL - 46', '', '', '', '', '', '9681061971', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681061971', '9681061971', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(483, 1, '', '', 'AFEEN SABA', '2008-02-09', '', 'FEMALE', '', '', '', '', '', '', '6', '579', '579', '', '', '', 'MD.SHAHID PEVEZ', '', 'NAGIS KHATOON', '', '11A, MOULVI GHOLAM SOBHAN LANE, KOL - 16', '', '', '', '', '', '9831228752', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831228752', '9831228752', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(484, 1, '', '', 'ALFIA KHAN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '912', '912', '', '', '', 'AKIB KHAN', '', 'SUFIYA KHAN', '', '2/2 TILJALA OAD KOL - 46', '', '', '', '', '', '9748580332', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748580332', '9748580332', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(485, 1, '', '', 'ALFIYA SHAKIL', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '951', '951', '', '', '', 'SHAKIL AHMAD', '', 'NUZHAT SHAKIL', '', '84/9 IPON STEET KOL - 16', '', '', '', '', '', '9339110997', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339110997', '9339110997', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(486, 1, '', '', 'ALISHA ALAM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '897', '897', '', '', '', 'ASHID ALAM', '', 'AYESHA KHATOON', '', '25/1C MOFIDUL ISLAM LANE KOL - 14', '', '', '', '', '', '9062508720', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062508720', '9062508720', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(487, 1, '', '', 'AMAA JUNAID', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '908', '908', '', '', '', 'JUNAID ALAM', '', 'KAINAT JUNAID', '', '166/H/68 KESHAB CHANDA SEN STEET KOL-09', '', '', '', '', '', '9331824772', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331824772', '9331824772', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(488, 1, '', '', 'ANABIA MEHFOOZ', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '925', '925', '', '', '', 'MAHFOOZ ALAM', '', 'M. IZWANA', '', '36/1E/1K/1 TOPSIA OAD KOL - 39', '', '', '', '', '', '9831360418', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831360418', '9831360418', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(489, 1, '', '', 'AYESHA ANJUM', '2008-10-21', '', 'FEMALE', '', '', '', '', '', '', '6', '1211', '1211', '', '', '', 'MD. ASLAM', '', 'SALMA ANJUM', '', '7A, KUSTIA OAD, KOL - 39', '', '', '', '', '', '9804147353', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9804147353', '9804147353', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(490, 1, '', '', 'AYESHA PEWEEN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '918', '918', '', '', '', 'MD. IBAHIM', '', 'TABASSUM JAHAN', '', '81 TOPSIA OAD KOL - 39', '', '', '', '', '', '9831638503', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831638503', '9831638503', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(491, 1, '', '', 'AYESHA SIDDIQUA', '2008-09-01', '', 'FEMALE', '', '', '', '', '', '', '6', '1072', '1072', '', '', '', 'NEHAL AKHTE', '', 'AUNAQ AFOZE', '', '80,COLOOTOLA STEET KOL-73', '', '', '', '', '', '9038407270', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038407270', '9038407270', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(492, 1, '', '', 'HOO AIN FATMA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '911', '911', '', '', '', 'KHAIUL SHAMS', '', 'SAJDA SHAMS', '', '2C H/8, CHATU BABU LANE ENTALLY KOL - 14', '', '', '', '', '', '9681880303', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681880303', '9681880303', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(493, 1, '', '', 'IBA ASUL', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '896', '896', '', '', '', 'AKBA ASUL', '', 'ESHMA ASUL', '', '30/H/3, D SUESH SAKA OAD PO ENTALY KOL - 14', '', '', '', '', '', '9836776819', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836776819', '9836776819', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(494, 1, '', '', 'INSA NASI', '2008-05-26', '', 'FEMALE', '', '', '', '', '', '', '6', '894', '894', '', '', '', 'NASI ANWA', '', 'HEENA PAVEEN', '', '55/C, TOPSIA OAD (SOUTH) KOL - 46', '', '', '', '', '', '9831308026', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831308026', '9831308026', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(495, 1, '', '', 'KHADIJAH BINT MUZAFFA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '932', '932', '', '', '', 'MUZAFFA ALI AHMED AI', '', 'KOHINOO IBAHIM', '', '30B CANTOPHE LANE KOL - 14', '', '', '', '', '', '9007100522', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007100522', '9007100522', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(496, 1, '', '', 'KHAIKASHA TASNEEM', '2009-04-04', '', 'FEMALE', '', '', '', '', '', '', '6', '1108', '1108', '', '', '', 'BASI AHMED', '', 'TAANNUM NIKHA', '', '32, SHAIF LANE KOLKATA - 16', '', '', '', '', '', '7278936328', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7278936328', '7278936328', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(497, 1, '', '', 'KULSUM SHAMS', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '919', '919', '', '', '', 'MD. ZEYAD SHAMS', '', 'SHIEEN PAWEEN', '', '71 AJC BOSE OAD KOL - 16', '', '', '', '', '', '6290225149', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '6290225149', '6290225149', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(498, 1, '', '', 'MAYAM BANU', '2008-09-01', '', 'FEMALE', '', '', '', '', '', '', '6', '1201', '1201', '', '', '', 'HAJI MD.JAMIL AHMED', '', 'SABE NOO BANU', '', '52 BECK BAGAN OW KOL-17', '', '', '', '', '', '9831354165', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831354165', '9831354165', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(499, 1, '', '', 'MEHWISH KHAN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '904', '904', '', '', '', 'IMAN KHAN', '', 'NAZIA KHAN', '', '7 B B BAGAN LANE PO TENGA PS ENTALLY KOL - 15', '', '', '', '', '', '7003163153', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003163153', '7003163153', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(500, 1, '', '', 'AIQA KHATOON', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '922', '922', '', '', '', 'BELAL HUSSAIN', '', 'ZUBAIDA KHATOON', '', '1st FLOO, 4 CEMATOIUM STEET KOL - 14', '', '', '', '', '', '9330990623', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330990623', '9330990623', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(501, 1, '', '', 'AMISHA AHMED', '2008-09-06', '', 'FEMALE', '', '', '', '', '', '', '6', '977', '977', '', '', '', 'SK AJU AHMED', '', 'SHABINA AHMED', '', '37, TOPSIA OAD KOL-46 (SOUTH) ', '', '', '', '', '', '9748277510', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748277510', '9748277510', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(502, 1, '', '', 'SAIQA KHANUM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '937', '937', '', '', '', 'ZAHI AHMED', '', 'KHUSHBU BEGUM', '', '10 SAPGACHI 1st LANE KOL - 39', '', '', '', '', '', '8420471621', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420471621', '8420471621', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(503, 1, '', '', 'SAYEEDA SAHANA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '924', '924', '', '', '', 'IAZUL ISLAM MIDDYA', '', 'NUSAT BANU', '', '9B- KUSTIA OAD TOPSIA KOL-39', '', '', '', '', '', '9836551140', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836551140', '9836551140', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(504, 1, '', '', 'SHOHUD QUAMA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '869', '869', '', '', '', 'MD. QAMAUDDIN', '', 'MASIHA KHATOON', '', '55B, BLOCK - D, FLAT NO - 4, G.J KHAN OAD (TPOSIA), KOL - 39', '', '', '', '', '', '9073914926', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9073914926', '9073914926', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(505, 1, '', '', 'SUFIA ALAM', '2008-10-30', '', 'FEMALE', '', '', '', '', '', '', '6', '939', '939', '', '', '', 'AUANGZEB ALAM', '', 'NIKHAT ALAM', '', '41, H/B/2, JANNAGA OAD, KOL - 17', '', '', '', '', '', '9674166201', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674166201', '9674166201', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(506, 1, '', '', 'SUMAIYA PAWEEN', '2009-02-25', '', 'FEMALE', '', '', '', '', '', '', '6', '909', '909', '', '', '', 'MD IBAHIM', '', 'AUNAK PAVEEN', '', '5/A KUSTIA MASJID BAI LANE KOL-39', '', '', '', '', '', '9831361357', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831361357', '9831361357', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(507, 1, '', '', 'TAHSEEN FATMA', '2008-12-26', '', 'FEMALE', '', '', '', '', '', '', '6', '901', '901', '', '', '', 'SK. SHAID KHAN', '', 'KANIZ FATMA', '', '7/D AVINASH CHOWDI LANE KOL - 46', '', '', '', '', '', '9831577192', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831577192', '9831577192', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(508, 1, '', '', 'TANAAZ KHAN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '906', '906', '', '', '', 'MD SAJID KHAN', '', 'NIKHAT PAVEEN', '', '64 E TOPSIA OAD P.O AND P.S -TILJALA KOL-39', '', '', '', '', '', '7890609807', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890609807', '7890609807', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(509, 1, '', '', 'UMUL SALEHA', '2008-07-29', '', 'FEMALE', '', '', '', '', '', '', '6', '952', '952', '', '', '', 'SHAHADATULLAH', '', 'AMNA KHATOON', '', 'H-17GHULAM ABBAS LANE METIA BUZ KOL-24', '', '', '', '', '', '9903896322', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903896322', '9903896322', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(510, 1, '', '', 'ZANAB BEGUM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '854', '854', '', '', '', 'SK SHAHJAHAN', '', 'MUMTAZ BEGUM', '', '26/1D, G J KHAN OAD, KOL - 39', '', '', '', '', '', '9088579828', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9088579828', '9088579828', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(511, 1, '', '', 'ZOYA NAAZ', '2008-07-30', '', 'FEMALE', '', '', '', '', '', '', '6', '916', '916', '', '', '', 'PEVEZ', '', 'NAZMA', '', '15A MUZAFFA AHMED STEET KOL - 16', '', '', '', '', '', '9830129586', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830129586', '9830129586', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(512, 1, '', '', 'MAIYA WASIM', '2008-09-04', '', 'FEMALE', '', '', '', '', '', '', '6', '1383', '1383', '', '', '', 'SYED ABUL WASIM', '', 'FIDOUS JAHAN', '', '109,DESHAPAN SASMAL OAD, TOLLYGUNGE. KOLKATTA-700033.', '', '', '', '', '', '9830769123', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830769123', '9830769123', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(513, 1, '', '', 'SIDAH ZAKI', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '6', '940', '940', '', '', '', 'ZAKI HOSSAIN', '', 'SEEMA ZAKI', '', '72/H/2, D SUDHI BOSE OAD KOL - 23', '', '', '', '', '', '9748970680', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748970680', '9748970680', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(514, 1, '', '', 'AMBA ASLAM', '2008-02-07', '', 'FEMALE', '', '', '', '', '', '', '6', '1535', '1535', '', '', '', 'MD ASLAM', '', 'ESHMI BEGUM', '', '1, TOPSIA OAD (SOUTH), P.S. TOPSIA, KOLKATA - 700046', '', '', '', '', '', '9886582332', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9886582332', '9886582332', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(515, 1, '', '', 'FATMA PAWEEN', '2008-11-20', '', 'FEMALE', '', '', '', '', '', '', '6', '1546', '1546', '', '', '', 'MD ABUZA', '', 'SIMBUL YASMIN', '', '120, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '9831261213', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831261213', '9831261213', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(516, 1, '', '', 'MAYAM BAHZAD', '2008-07-14', '', 'FEMALE', '', '', '', '', '', '', '6', '1550', '1550', '', '', '', 'BAHZAD SHAMS', '', 'SHAZIA SHAMS', '', '71, A J C BOSE OAD, KOLKATA - 700017', '', '', '', '', '', '8583829042', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8583829042', '8583829042', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(517, 1, '', '', 'AAFAT AHMED', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '917', '917', '', '', '', 'JALIL AHMED', '', 'SABANA AFOSE', '', 'C/O SK AMZAN ALI, 6/B TILJALA LANE 2nd FLOO KOL - 39', '', '', '', '', '', '9681575101', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681575101', '9681575101', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(518, 1, '', '', 'ASHAQ HUSSAIN', '2008-12-28', '', 'MALE', '', '', '', '', '', '', '6', '898', '898', '', '', '', 'AKHTA HUSSAIN', '', 'UBY HUSSAIN', '', '3/C/H/16, D MANINDA CHATTEJEESAANI, KOL - 09', '', '', '', '', '', '7003943466', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003943466', '7003943466', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(519, 1, '', '', 'DANYAL JAFY', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '935', '935', '', '', '', 'KHALID HASAN JAFY', '', 'UZMA ALAM', '', '87B GANT STEET 1st FLOO KOL - 13', '', '', '', '', '', '9062864330', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062864330', '9062864330', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(520, 1, '', '', 'ESSA AZA KHAN', '2008-03-31', '', 'MALE', '', '', '', '', '', '', '6', '871', '871', '', '', '', 'AFSA KHAN', '', 'YASMIN KHAN', '', '58 TOPSIA OAD KOL-39', '', '', '', '', '', '9331264859', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331264859', '9331264859', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(521, 1, '', '', 'FAAIZUL ISLAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '915', '915', '', '', '', 'AMINUL ISLAM', '', 'NAZIA AMIN', '', '26 SHAMSUL HUDA OAD 3d FLOO PS KAAYA KOL - 17', '', '', '', '', '', '9830008556', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830008556', '9830008556', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(522, 1, '', '', 'FIOZU AHMAN ALI', '2008-03-31', '', 'MALE', '', '', '', '', '', '', '6', '1218', '1218', '', '', '', 'ZULFIKA ALI', '', 'FOUJIA ALI', '', '23/1 B, BALU HAKKAH LANE KOL-17', '', '', '', '', '', '9830132126', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830132126', '9830132126', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(523, 1, '', '', 'FUQUAN AMAN', '2007-08-07', '', 'MALE', '', '', '', '', '', '', '6', '967', '967', '', '', '', 'AMANUL HAQUE', '', 'NISHAT AMAN', '', 'HAQUE COTTAGE. 3d FLOO. 23, DENT MISSION OAD, KOL - 23', '', '', '', '', '', '8910362166', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8910362166', '8910362166', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(524, 1, '', '', 'KH. MD AUSAFUL KAIM', '2008-05-19', '', 'MALE', '', '', '', '', '', '', '6', '1010', '1010', '', '', '', 'MD ALI YOUSUF', '', 'FATEMA BEGUM', '', '22, DEEDA BUKSH LANE, KOL - 16', '', '', '', '', '', '9874432180', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874432180', '9874432180', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(525, 1, '', '', 'MD ANAS', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '923', '923', '', '', '', 'MD NESA', '', 'SHAGUFTA JAHA', '', '48, TOPSIA OAD SOUTH KOL - 46', '', '', '', '', '', '9874118301', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874118301', '9874118301', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(526, 1, '', '', 'MD AAFAT HASNAIN', '2008-11-26', '', 'MALE', '', '', '', '', '', '', '6', '930', '930', '', '', '', 'MD SONU HASNAIN', '', 'MUSAAT HASNAIN', '', '6/14/H/8 NILMONI HALDE LANE KOL - 13', '', '', '', '', '', '9830156036', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830156036', '9830156036', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(527, 1, '', '', 'MD ISMAIL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '920', '920', '', '', '', 'MD. MUSTAFA', '', 'ANI BEGUM', '', '4/1B CONVENT LANE, KOL - 15', '', '', '', '', '', '8420952215', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420952215', '8420952215', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(528, 1, '', '', 'MD KAIF', '2008-04-29', '', 'MALE', '', '', '', '', '', '', '6', '907', '907', '', '', '', 'MD SALAUDDIN', '', 'AFAT SAHEEN', '', '64/1A MUFIDUL ISLAM LANE KOL-14', '', '', '', '', '', '9231527857', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9231527857', '9231527857', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(529, 1, '', '', 'MD MUAZZAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '884', '884', '', '', '', 'MD.ASIF', '', 'UBINA ASIF', '', '112 C TOPSIA OAD KOLKATA-700039', '', '', '', '', '', '9883716343', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883716343', '9883716343', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(530, 1, '', '', 'MD NAZI ULLAH', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '900', '900', '', '', '', 'MD. ZIAULLAH', '', 'NUSAT BEGUM', '', '48, CANAL EAST OAD, KOL - 11', '', '', '', '', '', '9903515508', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903515508', '9903515508', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(531, 1, '', '', 'MD SALMAN FASI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '899', '899', '', '', '', 'ABDUL KADE', '', 'TABASSUM KADE', '', '30/3B MIAJAN OSTAGA LANE KOL - 17', '', '', '', '', '', '8582907341', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8582907341', '8582907341', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(532, 1, '', '', 'MD SHAIQUE ALI', '2007-10-29', '', 'MALE', '', '', '', '', '', '', '6', '853', '853', '', '', '', 'MD SHAHID ALI', '', 'SULTANA PAVEEN', '', '4/1, KASAI BUSTEE 2ND LANE, KOL - 11', '', '', '', '', '', '8820826386', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8820826386', '8820826386', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(533, 1, '', '', 'MD AAMI', '2007-03-03', '', 'MALE', '', '', '', '', '', '', '6', '1241', '1241', '', '', '', 'MD ALAMGI', '', 'KHUSHMU BEGUM', '', '9A, 2ND FLOO GHOLAM JILANI KHAN OAD LP68/7 KOLKATA', '', '', '', '', '', '7980136511', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980136511', '7980136511', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(534, 1, '', '', 'MOHAMMAD ', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '949', '949', '', '', '', 'MD. SHAMIMUDDIN', '', 'KISHWA SHAMIM', '', '3B H/12, D M N CHATEJEE SAANI KOL - 09', '', '', '', '', '', '7003535881', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003535881', '7003535881', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(535, 1, '', '', 'MOHAMMAD MOKAAM', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '893', '893', '', '', '', 'WAIZUL HAQUE', '', 'NAHEED FATMA', '', '2/H/6, HATI BAGAN OAD, KOL - 73', '', '', '', '', '', '9163850640', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163850640', '9163850640', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(536, 1, '', '', 'MOHAMMED AYAAN', '2008-11-27', '', 'MALE', '', '', '', '', '', '', '6', '914', '914', '', '', '', 'MD. SOHAIL', '', 'DILSHAD BEGUM', '', '33 ELLIOT OAD KOL - 16', '', '', '', '', '', '9163925095', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163925095', '9163925095', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(537, 1, '', '', 'MOHIUDDIN MOHAMMAD HASAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '913', '913', '', '', '', 'MOHAMMAD FAOOQUE', '', 'FAINA NAZ', '', '24/2/H/12 & 27, BIGHT STEET, KOL - 17', '', '', '', '', '', '9748650610', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748650610', '9748650610', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(538, 1, '', '', 'AAFEY SHAKIL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '928', '928', '', '', '', 'ANJUM SHAKIL', '', 'AFAT SULTANA', '', '147 H/4 KESHAB CHANDA SEN STEET KOL-09', '', '', '', '', '', '9830745087', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830745087', '9830745087', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(539, 1, '', '', 'SAIF ALI', '2008-12-25', '', 'MALE', '', '', '', '', '', '', '6', '902', '902', '', '', '', 'NAUSHAD ALI', '', 'NAZNEEN PAVEEN', '', '41/C/H/7, JANNAGA OAD, P.S - BENIAPUKU PAK CICUS, KOL - 17', '', '', '', '', '', '9831984225', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831984225', '9831984225', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(540, 1, '', '', 'SHAIK AYAN', '2008-04-28', '', 'MALE', '', '', '', '', '', '', '6', '946', '946', '', '', '', 'SHAIK LAL', '', 'SHABANA LAL', '', '12/4, CHAMU SINGH LANE KOL - 11', '', '', '', '', '', '9830946834', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830946834', '9830946834', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(541, 1, '', '', 'SHAMS MAHTAB', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '938', '938', '', '', '', 'MEHTAB NADVI', '', 'YASMIN KHATOON', '', '25 MASJID BAI LANE TOPSIA  KOL - 39', '', '', '', '', '', '8420902215', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420902215', '8420902215', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(542, 1, '', '', 'SYED ABI MEHDI', '2008-10-29', '', 'MALE', '', '', '', '', '', '', '6', '921', '921', '', '', '', 'ISHTEYAQUE ALAM', '', 'SAMEEA WALI', '', '4 WALIULLAH LANE KOL - 16', '', '', '', '', '', '8100013177', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100013177', '8100013177', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(543, 1, '', '', 'WAQAS SAWOOD', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '953', '953', '', '', '', 'MD SAWOOD BAI', '', 'NAHIDA SAWOOD', '', '3/H/1 IBAHIM OAD KHIDDEPU KOL-23', '', '', '', '', '', '9748839071', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748839071', '9748839071', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(544, 1, '', '', 'ZOHAIB JAFI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '6', '947', '947', '', '', '', 'FAIZUL HAQUE JAFI', '', 'ZAIN JAFI', '', '15 MIDDLE OW KOL - 14', '', '', '', '', '', '9330814672', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330814672', '9330814672', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(545, 1, '', '', 'UBAID HUSSAIN', '2008-09-15', '', 'MALE', '', '', '', '', '', '', '6', '1245', '1245', '', '', '', 'MD ABID HUSSAIN', '', 'ZEENAT AA', '', '15/H/6/2, CHAMU SINGH LANE, KOLKATA - 700011', '', '', '', '', '', '8100236740', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100236740', '8100236740', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(546, 1, '', '', 'AAMI KHAN', '2007-08-10', '', 'MALE', '', '', '', '', '', '', '6', '1555', '1555', '', '', '', 'NAIM KHAN', '', 'ASHIYA KHATOON', '', '1/H/2, KASAI BUSTEE 1ST LANE, NAKELDANGA, KOLKATA - 700011', '', '', '', '', '', '7890100525', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890100525', '7890100525', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(547, 1, '', '', 'AASIFA KHAN', '2008-10-16', '', 'FEMALE', '', '', '', '', '', '', '7', '1023', '1023', '', '', '', 'PAVEJ ALAM KHAN', '', 'NAHID KHAN', '', '1/C, CANTOPHE LANE. KOL - 14', '', '', '', '', '', '9339756843', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339756843', '9339756843', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(548, 1, '', '', 'AEYSHA AIF', '2008-11-05', '', 'FEMALE', '', '', '', '', '', '', '7', '1099', '1099', '', '', '', 'MD.AIF', '', 'ALIYA  ASGA', '', '85,B TOPSIA OAD KOLKATA - 39', '', '', '', '', '', '8282818837', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8282818837', '8282818837', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(549, 1, '', '', 'ALISAH HUSSAIN', '2008-12-14', '', 'FEMALE', '', '', '', '', '', '', '7', '1083', '1083', '', '', '', 'MD. JAWED HUSSAIN', '', 'MEHUN NESA', '', '118/3, BELILIOUS OAD, HOWAH - 01', '', '', '', '', '', '9903334331', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903334331', '9903334331', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(550, 1, '', '', 'ANASTASIYA KHAN', '2008-07-11', '', 'FEMALE', '', '', '', '', '', '', '7', '1007', '1007', '', '', '', 'SAFAZ KHAN', '', 'FIDOUSI BEGUM', '', '61/12/21, TOPSIA OAD KOL-39', '', '', '', '', '', '9748596713', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748596713', '9748596713', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(551, 1, '', '', 'ANUM AHI', '2009-01-12', '', 'FEMALE', '', '', '', '', '', '', '7', '1076', '1076', '', '', '', 'MD MOIN', '', 'YASMEEN KHANAM', '', '17, NUULLAH D. LANE KOLKATA - 17', '', '', '', '', '', '9831786443', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831786443', '9831786443', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(552, 1, '', '', 'AYESHA FIDOUS', '2008-06-05', '', 'FEMALE', '', '', '', '', '', '', '7', '991', '991', '', '', '', 'MD AMJAD KHAN', '', 'AHAT FIDOUS', '', '82D, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '9831732548', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831732548', '9831732548', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(553, 1, '', '', 'FALAK JAHAN', '2008-11-17', '', 'FEMALE', '', '', '', '', '', '', '7', '1102', '1102', '', '', '', 'MD SHAMIMUDDIN', '', 'ESHMA SHAMIM', '', '82/B, TOPSIA OAD KOL - 39', '', '', '', '', '', '9681106468', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681106468', '9681106468', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(554, 1, '', '', 'HAM SHAHID', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '7', '905', '905', '', '', '', 'MD SHAHID', '', 'ZOYA SHAHID', '', '2B/H/24 D M N CHATTEJEE SAANI KOL - 09', '', '', '', '', '', '9330149668', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330149668', '9330149668', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(555, 1, '', '', 'HOOYA HAAM', '2008-07-28', '', 'FEMALE', '', '', '', '', '', '', '7', '1024', '1024', '', '', '', 'MD. JAVED', '', 'AUNAK JAVED', '', '41BH/2, JANNAGA OAD, KOL - 17', '', '', '', '', '', '9831442720', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831442720', '9831442720', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(556, 1, '', '', 'KAYNAT BANO', '2006-12-31', '', 'FEMALE', '', '', '', '', '', '', '7', '1213', '1213', '', '', '', 'MD.WASIM', '', 'SHABANA BANU', '', '52, BECK BAGAN OW KOL-17', '', '', '', '', '', '9831196290', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831196290', '9831196290', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(557, 1, '', '', 'KULSUM AA', '2008-11-18', '', 'FEMALE', '', '', '', '', '', '', '7', '1002', '1002', '', '', '', 'MD JAMALUDDIN', '', 'GULSHAN AA', '', 'B/22/1/H/4, BIGHT STEET, KOL-17', '', '', '', '', '', '9748186822', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748186822', '9748186822', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(558, 1, '', '', 'MAHVISH FAHEEN NAAZ', '2008-02-14', '', 'FEMALE', '', '', '', '', '', '', '7', '1042', '1042', '', '', '', 'SHAMIM AHMED', '', 'MAHJABEEN NAAZ', '', '37/4, WATGUNGE STEET KIDDEPOE KOL-23', '', '', '', '', '', '9330884557', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330884557', '9330884557', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(559, 1, '', '', 'NAUEEN NASIM', '2009-02-24', '', 'FEMALE', '', '', '', '', '', '', '7', '1063', '1063', '', '', '', 'MOHAMMED NASIM', '', 'NAFISA BEGUM', '', '46, TILJALA LANE, KOL - 39', '', '', '', '', '', '9831580224', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831580224', '9831580224', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(560, 1, '', '', 'NAZMIN ANWA', '2008-09-24', '', 'FEMALE', '', '', '', '', '', '', '7', '998', '998', '', '', '', 'ABDUL ANWA', '', 'YASMIN BEGUM', '', '29/A/H/25, PALM AVENUE, KOLKATA - 19', '', '', '', '', '', '9007821584', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007821584', '9007821584', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(561, 1, '', '', 'NESHAT FATMA', '2008-01-20', '', 'FEMALE', '', '', '', '', '', '', '7', '999', '999', '', '', '', 'ASIF JAMAL', '', 'SAJDA KHATOON', '', '16, KUSTIA MASJID BAI LANE, KOL-39', '', '', '', '', '', '8420478312', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420478312', '8420478312', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(562, 1, '', '', 'AMSHA MUJAHID', '2008-09-22', '', 'FEMALE', '', '', '', '', '', '', '7', '1013', '1013', '', '', '', 'MD. MUJAHID ANWA', '', 'ESHMA KHATOON', '', '9G, KUSTIA OAD, KOL-39', '', '', '', '', '', '7044911818', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7044911818', '7044911818', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(563, 1, '', '', 'EZWANA SHAH KHAN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '7', '875', '875', '', '', '', 'ASGA KHAN', '', 'SAJEDA BEGUM', '', '9P/1A ABHINAS CHOWDHUY LANE KOL.46', '', '', '', '', '', '9831451367', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831451367', '9831451367', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(564, 1, '', '', 'SADIA HASIM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '7', '1027', '1027', '', '', '', 'MD HASIM', '', 'NILOFE', '', '61/12/14, TOPSIA OAD, KOL-39', '', '', '', '', '', '9748920456', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748920456', '9748920456', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(565, 1, '', '', 'SAAH FATMA ASHID', '2009-03-29', '', 'FEMALE', '', '', '', '', '', '', '7', '1058', '1058', '', '', '', 'MOHD AKBE', '', 'UMME HABIBA AKBE', '', '45A, SHAMSUL HUDA OAD, KOL-17', '', '', '', '', '', '9007495159', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007495159', '9007495159', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(566, 1, '', '', 'SHIFA AHMED', '2009-02-17', '', 'FEMALE', '', '', '', '', '', '', '7', '1094', '1094', '', '', '', 'MD ZAFA AHMED SAJID', '', 'SABAHAT BANO', '', '9, NASIUDDIN OAD, KOL- 17', '', '', '', '', '', '9874719884', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874719884', '9874719884', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(567, 1, '', '', 'TAHSIN FATMA', '2008-06-24', '', 'FEMALE', '', '', '', '', '', '', '7', '1064', '1064', '', '', '', 'SK PAPPU', '', 'KAHKASHA NAZNEEN', '', '1, SAPGACHI 2ND LANE KOL - 39', '', '', '', '', '', '9836294566', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836294566', '9836294566', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(568, 1, '', '', 'TAANNUM NISHA', '2019-02-06', '', 'FEMALE', '', '', '', '', '', '', '7', '878', '878', '', '', '', 'AHMAT HOSSAIN', '', 'NOOJAHAN ', '', '42 B TILJALA OADKOL.46', '', '', '', '', '', '9903426823', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903426823', '9903426823', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(569, 1, '', '', 'TASHMIYA NOO', '2008-11-11', '', 'FEMALE', '', '', '', '', '', '', '7', '1091', '1091', '', '', '', 'NOO MOHAMMED', '', 'ISMAT PAVEEN', '', '33, AHIIPUKU OAD, P.S. KAAYA,PO. BALLYGUNJ, KOL-19', '', '', '', '', '', '9748390385', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748390385', '9748390385', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(570, 1, '', '', 'UMMUL WAA ', '2008-04-03', '', 'FEMALE', '', '', '', '', '', '', '7', '1012', '1012', '', '', '', 'MD MAQSUD ALAM', '', 'AUSHAN AA', '', '13D KOMEDAN BAGAN LANE KOL-16', '', '', '', '', '', '9339470242', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339470242', '9339470242', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(571, 1, '', '', 'YUMNAA  SHAHID', '2008-10-29', '', 'FEMALE', '', '', '', '', '', '', '7', '1018', '1018', '', '', '', 'MOHAMMAD SHAHID', '', 'SADEQA ALI', '', '28/H/7, SI SYED AHMED OAD, KOL -14', '', '', '', '', '', '9088206447', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9088206447', '9088206447', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(572, 1, '', '', 'ZIKA ALI KHAN', '2008-08-27', '', 'FEMALE', '', '', '', '', '', '', '7', '1030', '1030', '', '', '', 'TANVI KHAN', '', 'TALAT BEGUM', '', '13E, TILJALA LANE, KOL-19', '', '', '', '', '', '9883392200', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883392200', '9883392200', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(573, 1, '', '', 'ZOHA JASIM', '2009-02-11', '', 'FEMALE', '', '', '', '', '', '', '7', '1017', '1017', '', '', '', 'MD. JASIM ', '', 'TABASSUM BEGUM', '', '11, TILJALA SHIBTALA LANE KOL - 39', '', '', '', '', '', '9339938024', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339938024', '9339938024', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(574, 1, '', '', 'HAIQA PAVEEN', '2008-12-22', '', 'FEMALE', '', '', '', '', '', '', '7', '1724', '1724', '', '', '', 'MD ASHIQUE', '', 'PAVEEN SULTANA', '', 'MANNAT APATMENT. BLOCK - E. 22, AICHAAN GHOSH LANE,TOPSIA, KOLKATA - 700039', '', '', '', '', '', '7595915231', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7595915231', '7595915231', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(575, 1, '', '', 'ABDULLA AALIF', '2008-09-03', '', 'MALE', '', '', '', '', '', '', '7', '1075', '1075', '', '', '', 'ANZA AHMED', '', 'NIKHAT AHMED', '', '45/1B, SHAMSUL HUDA OAD, KOL - 17', '', '', '', '', '', '9831770057', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831770057', '9831770057', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(576, 1, '', '', 'ABU BAKA ALI', '2008-02-07', '', 'MALE', '', '', '', '', '', '', '7', '1080', '1080', '', '', '', 'MD HUMAYUN ALI', '', 'KAHKASHA HUMAYUN', '', '3, JANNAGA 2ND LANE,  KOL - 14', '', '', '', '', '', '9831569493', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831569493', '9831569493', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(577, 1, '', '', 'AFFAN ALAM', '2008-06-14', '', 'MALE', '', '', '', '', '', '', '7', '1014', '1014', '', '', '', 'IFTEKHA ALAM ', '', 'SHABANA MEHJABEEN', '', '67, BIGHT STEET, KOL - 19', '', '', '', '', '', '9433931729', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9433931729', '9433931729', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(578, 1, '', '', 'AMEE TALLHA KHAN', '2008-08-29', '', 'MALE', '', '', '', '', '', '', '7', '1048', '1048', '', '', '', 'UMA FAOOQUE KHAN', '', 'SAMINA KHATOON', '', '36, PALM AVENUE KOL M- 19', '', '', '', '', '', '9007733263', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007733263', '9007733263', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(579, 1, '', '', 'AMMA ALI WASI', '2008-07-27', '', 'MALE', '', '', '', '', '', '', '7', '1003', '1003', '', '', '', 'SHAKE ALI', '', 'SHANAZ BEGUM', '', '1/1 CHAMU KHANSAMA LANE KOLKATA - 17', '', '', '', '', '', '9830743786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830743786', '9830743786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(580, 1, '', '', 'ANASH SHAKIB', '2008-04-23', '', 'MALE', '', '', '', '', '', '', '7', '1005', '1005', '', '', '', 'MD.SHOAIB ', '', 'NAZNEEN KHATOON', '', '41/H/6 D. SUDHI BASU OAD KOKATA - 23', '', '', '', '', '', '9331681883', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331681883', '9331681883', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(581, 1, '', '', 'AMAN AYUB', '2008-11-10', '', 'MALE', '', '', '', '', '', '', '7', '1033', '1033', '', '', '', 'MD. AYUB', '', 'SHABANA BEGUM', '', '48/B ISMAIL STEET KOLKATA - 14', '', '', '', '', '', '9830858215', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830858215', '9830858215', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(582, 1, '', '', 'ASAD SYED', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '7', '880', '880', '', '', '', 'MD. SAIYEED', '', 'KAHKASHA NAAZ', '', '16F/1 C.N.OY OAD KOL-39', '', '', '', '', '', '9831148179', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831148179', '9831148179', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(583, 1, '', '', 'AYAAN AHMED SIDDIQUE', '2008-11-25', '', 'MALE', '', '', '', '', '', '', '7', '1206', '1206', '', '', '', 'IMAN AHMED SIDDIQUE', '', 'ULFAT JAHAN', '', '11/2 H/14, MOULANA MOHMMAD ALI KOLKATA - 23', '', '', '', '', '', '7687060358', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7687060358', '7687060358', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(584, 1, '', '', 'AYAN AHMED', '2008-12-09', '', 'MALE', '', '', '', '', '', '', '7', '1107', '1107', '', '', '', 'SHAKIL AHMED', '', 'SHAKINA AHMED', '', '50/H/5, BIGHT STEET KOL-17', '', '', '', '', '', '8420958294', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420958294', '8420958294', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(585, 1, '', '', 'HUZAEFA AHAMAN', '2008-12-16', '', 'MALE', '', '', '', '', '', '', '7', '1004', '1004', '', '', '', 'MOFIZU AHAMAN', '', 'PAWEEN BIBI', '', '41H/1, D. SUDHI BOSE D, KOL - 23', '', '', '', '', '', '9836781520', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836781520', '9836781520', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(586, 1, '', '', 'KABIUDDIN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '7', '886', '886', '', '', '', 'SK.QAMUDDIN', '', 'SHAHEEN SULTANA', '', '29/A/H/9 PALM AVENUE KOLKATA-19', '', '', '', '', '', '9330056811', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330056811', '9330056811', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(587, 1, '', '', 'MAAZ HUSSAIN', '2008-11-07', '', 'MALE', '', '', '', '', '', '', '7', '1093', '1093', '', '', '', 'NASI HUSSAIN', '', 'TABASSUM QAMA', '', '15/H/4 BIBI BAGAN LANE KOL-15', '', '', '', '', '', '9836623428', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836623428', '9836623428', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(588, 1, '', '', 'MD  YOUSUF', '2009-01-26', '', 'MALE', '', '', '', '', '', '', '7', '1066', '1066', '', '', '', 'NAZI AHMED', '', 'TABASSUM NAZI', '', '8, COLLIN LANE, PAK STEET, KOL-16', '', '', '', '', '', '9331730769', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331730769', '9331730769', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(589, 1, '', '', 'MD AMIUL HASSAN', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '7', '1061', '1061', '', '', '', 'MD SHAKIL  ', '', 'OZY BEGUM', '', 'C/O, SALIMUDDIN BUILDING. 63, TILJALA OAD, KOLKATA - 46', '', '', '', '', '', '7003161608', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003161608', '7003161608', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(590, 1, '', '', 'MD ANAS SHAUKAT', '2008-09-08', '', 'MALE', '', '', '', '', '', '', '7', '1037', '1037', '', '', '', 'MD SHAUKAT ALI', '', 'ZEBA SHAUKAT', '', '31/Q, AI CHAAN GHOSH LANE, KOL - 39', '', '', '', '', '', '9748638511', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748638511', '9748638511', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(591, 1, '', '', 'MD ASIF ALI', '2008-09-19', '', 'MALE', '', '', '', '', '', '', '7', '1052', '1052', '', '', '', 'MD ALI', '', 'ESHMA KHAN', '', '43/B, TILJALA OAD , KOL - 46', '', '', '', '', '', '7890449907', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890449907', '7890449907', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(592, 1, '', '', 'MD HAMMAAD', '2008-04-16', '', 'MALE', '', '', '', '', '', '', '7', '1057', '1057', '', '', '', 'MD BELAL ANWA', '', 'SHAHINA PAVEEN', '', 'B/7/H/3 ,AHI PUKU 2ND LANE, KOL - 17', '', '', '', '', '', '9339393446', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339393446', '9339393446', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(593, 1, '', '', 'MD JUNAID IMTIAZ', '2008-08-21', '', 'MALE', '', '', '', '', '', '', '7', '1095', '1095', '', '', '', 'IMTIAZ AHMED', '', 'AMIA IMTIAZ', '', '38, D. SUESH SAKA OAD KOLKATA - 14', '', '', '', '', '', '9830488794', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830488794', '9830488794', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(594, 1, '', '', 'MD KONAIN', '2008-08-26', '', 'MALE', '', '', '', '', '', '', '7', '1009', '1009', '', '', '', 'MD.SAQUIB', '', 'HUSNA SAQUIB', '', '46/S, GOACHAND OAD, KOL-14', '', '', '', '', '', '9831191511', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831191511', '9831191511', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(595, 1, '', '', 'MD OBAIDULLAH', '2008-10-20', '', 'MALE', '', '', '', '', '', '', '7', '1216', '1216', '', '', '', 'MD.BADULLAH', '', 'UKHSANA BANO', '', '45,COLLIN STEET KOL-16', '', '', '', '', '', '8276916886', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8276916886', '8276916886', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(596, 1, '', '', 'MD OSAMA', '2008-09-28', '', 'MALE', '', '', '', '', '', '', '7', '1200', '1200', '', '', '', 'MD NAZIUDDIN', '', 'ZAINA KHATOON', '', '29, TOPSIA OAD(SOUTH), KOL - 46', '', '', '', '', '', '9007320529', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007320529', '9007320529', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(597, 1, '', '', 'MEJAN MOHAMMAD MEAJ', '2008-08-22', '', 'MALE', '', '', '', '', '', '', '7', '1020', '1020', '', '', '', 'MOHAMMAD MEAJ AHMED', '', 'SHAZADI BEGUM', '', '16, SHAMSUL HUDA OAD, KOL - 17', '', '', '', '', '', '9831904603', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831904603', '9831904603', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(598, 1, '', '', 'MISBAHUL ALI MULLICK', '2008-05-22', '', 'MALE', '', '', '', '', '', '', '7', '1202', '1202', '', '', '', 'MUZAFFA ALI MULLICK', '', 'NAFISA BANU MULLICK', '', '6, TALTALA BAZA STEET, KOL-14', '', '', '', '', '', '9830502855', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830502855', '9830502855', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(599, 1, '', '', 'AYYAN AABID', '2008-08-28', '', 'MALE', '', '', '', '', '', '', '7', '1025', '1025', '', '', '', 'ABID AKHTA', '', 'SOFIA ANJUM', '', '85H, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9831092474', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831092474', '9831092474', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(600, 1, '', '', 'SHAMUIL EJAZ', '2008-09-05', '', 'MALE', '', '', '', '', '', '', '7', '1053', '1053', '', '', '', 'MD EJAZ ALAM', '', 'FAHAT JABEEN', '', 'B/76/H/13, LINTON STEET, KOL; - 14', '', '', '', '', '', '8910033746', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8910033746', '8910033746', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(601, 1, '', '', 'SK. FAZAL ALI', '2008-09-24', '', 'MALE', '', '', '', '', '', '', '7', '1043', '1043', '', '', '', 'SK. AFZAL ALI', '', 'TAANNUM AFZAL', '', '22/H/5, BIGHT STEET, KOL-17', '', '', '', '', '', '9088995616', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9088995616', '9088995616', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(602, 1, '', '', 'ZAID BIN OME', '2008-03-28', '', 'MALE', '', '', '', '', '', '', '7', '1718', '1718', '', '', '', 'MD MUJAHID OME', '', 'SULEKHA OME', '', '8A, CHAMU KHANSAMA LANE, KOLKATA - 700017', '', '', '', '', '', '8444011646', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8444011646', '8444011646', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(603, 1, '', '', 'MD ASH AZA', '2008-01-08', '', 'MALE', '', '', '', '', '', '', '7', '1719', '1719', '', '', '', 'MD SHAMSAD ALAM', '', 'OOBY TABASSUM', '', 'GULSHAN COLONY. B/13, WEST CHOWBAGHA, KOLKATA - 700100', '', '', '', '', '', '9439783476', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9439783476', '9439783476', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(604, 1, '', '', 'MD HAMZA KHAN', '2008-07-29', '', 'MALE', '', '', '', '', '', '', '7', '926', '926', '', '', '', 'AMJAD KHAN', '', 'SHAHEEN KHAN', '', '2 ABDUL ALI OW 3d FLOO FLAT NO - 3G KOL - 16', '', '', '', '', '', '9903869183', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903869183', '9903869183', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(605, 1, '', '', 'AATIKA PAVEEN', '2008-05-16', '', 'FEMALE', '', '', '', '', '', '', '8', '1144', '1144', '', '', '', 'IMTIYAZ AHMED', '', 'FAIDA BEGUM', '', '45/1B, BIGHT STEET, KOL - 17', '', '', '', '', '', '9903291737', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903291737', '9903291737', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(606, 1, '', '', 'ADIBA ASIF', '2008-02-05', '', 'FEMALE', '', '', '', '', '', '', '8', '1103', '1103', '', '', '', 'ASIF ALI', '', 'SHAHEEN PAVEEN', '', ' 20F,TOPSIA OAD KOL - 39', '', '', '', '', '', '9331852154', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331852154', '9331852154', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(607, 1, '', '', 'AFIFAH IQBAL', '2008-12-21', '', 'FEMALE', '', '', '', '', '', '', '8', '1155', '1155', '', '', '', 'MD IQBAL', '', 'KAHKASHAN IQBAL', '', '39/1/H/4, SI SYED AHMED OAD,  KOL - 14', '', '', '', '', '', '9836562750', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836562750', '9836562750', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(608, 1, '', '', 'AISHA KHAN', '2008-03-07', '', 'FEMALE', '', '', '', '', '', '', '8', '1146', '1146', '', '', '', 'ABDUL MASUD KHAN', '', 'NIKHAT KHAN', '', '239, TILJALA OAD, KOL - 46', '', '', '', '', '', '9051394707', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9051394707', '9051394707', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(609, 1, '', '', 'BUSHA KHATOON', '2008-05-10', '', 'FEMALE', '', '', '', '', '', '', '8', '1181', '1181', '', '', '', 'TAHSEEN AHMAD', '', 'ZEENAT KHATOON', '', 'VILL ; GOGAWAN,POST ; NAAINI, DIST ; GUDDA, JH', '', '', '', '', '', '9038965725', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038965725', '9038965725', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(610, 1, '', '', 'HUMAIA OMA IBAHIM', '2008-06-12', '', 'FEMALE', '', '', '', '', '', '', '8', '1167', '1167', '', '', '', 'MD OMA IBAHIM', '', 'SADAF OMA', '', '3, JANNAGA 2ND LANE,  KOL - 14', '', '', '', '', '', '9836378987', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836378987', '9836378987', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(611, 1, '', '', 'HUMAIAH QAIS', '2008-10-14', '', 'FEMALE', '', '', '', '', '', '', '8', '1129', '1129', '', '', '', 'QAIS AHMED', '', 'AFEEN AKHTE', '', '2E/3, CANTOPHE LANE, KOL - 14', '', '', '', '', '', '9830602286', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830602286', '9830602286', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(612, 1, '', '', 'IFA HUSSAIN', '2008-07-27', '', 'FEMALE', '', '', '', '', '', '', '8', '1068', '1068', '', '', '', 'ISHAD HUSSAIN', '', 'NAHID HUSSAIN', '', '12/2 PALM AVENUE KOLKATA - 19', '', '', '', '', '', '9748697075', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748697075', '9748697075', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(613, 1, '', '', 'ILMA FATMA', '2009-08-15', '', 'FEMALE', '', '', '', '', '', '', '8', '1510', '1510', '', '', '', 'ABDUL WAHID', '', 'SHAGUFA AHMANI', '', '85/G, TOPSIA OAD, NEA BAKAT STALL, KOLKATA - 700039', '', '', '', '', '', '8820126295', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8820126295', '8820126295', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(614, 1, '', '', 'LAAIB HENA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '8', '1197', '1197', '', '', '', 'MD YAHYA KHAN', '', 'HENA KHANAM', '', '38, DENT MISSION OAD, KOLKATA - 700023', '', '', '', '', '', '9831159559', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831159559', '9831159559', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(615, 1, '', '', 'MAIMUNA FAZANA HAMEED', '2009-03-28', '', 'FEMALE', '', '', '', '', '', '', '8', '1156', '1156', '', '', '', 'SHAHUL HAMEED', '', 'FAHAT JAHAN AKHTA', '', 'B/3/H/13, JHOWTALA LANE, 2ND FLOO, KOLKATA - 700017', '', '', '', '', '', '9836622569', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836622569', '9836622569', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(616, 1, '', '', 'MANTASHA SEKH', '2008-08-19', '', 'FEMALE', '', '', '', '', '', '', '8', '1160', '1160', '', '', '', 'MD. IMTEYAZ', '', 'SHAHNAZ BEGUM', '', '42/108, BEDIA DANGA 2ND LANE, KOL - 39', '', '', '', '', '', '9831111413', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831111413', '9831111413', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(617, 1, '', '', 'NOO FATHMA', '2004-08-04', '', 'FEMALE', '', '', '', '', '', '', '8', '1511', '1511', '', '', '', 'MD ALAM', '', 'FAHMIDA BEGUM', '', '168/ Y KESHAB CHANDA SEN STEET KOLKATA 70009', '', '', '', '', '', '9331216113', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331216113', '9331216113', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(618, 1, '', '', 'IDA BINT EYAZ', '2009-05-31', '', 'FEMALE', '', '', '', '', '', '', '8', '1425', '1425', '', '', '', 'EYAZ AHMAD KHAN', '', 'SUFIA PEVEEN', '', '9 G.J.KHAN OAD KOL-39', '', '', '', '', '', '9062992926', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062992926', '9062992926', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(619, 1, '', '', 'SAFUA BANO', '2008-01-19', '', 'FEMALE', '', '', '', '', '', '', '8', '1139', '1139', '', '', '', 'MD WAKIL', '', 'ASMA BANO', '', '52, BECK BAGAN OW,  KOL - 17', '', '', '', '', '', '9007826716', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007826716', '9007826716', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(620, 1, '', '', 'SAIBA JAMIL', '2008-05-12', '', 'FEMALE', '', '', '', '', '', '', '8', '1045', '1045', '', '', '', 'JAMIL AHMED', '', 'IZWANA KHATOON', '', '11/1//1H/2, HASHI STEET, KOL - 9', '', '', '', '', '', '9681986495', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681986495', '9681986495', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(621, 1, '', '', 'SANA SHEIKH', '2008-10-12', '', 'FEMALE', '', '', '', '', '', '', '8', '1035', '1035', '', '', '', 'SHEIKH SAJID', '', 'SHAHEEN AFOZ', '', '2E,TILJALA LANE, 1ST FLOO, KOL-19', '', '', '', '', '', '9831077507', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831077507', '9831077507', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(622, 1, '', '', 'SIDA SABE', '2008-12-22', '', 'FEMALE', '', '', '', '', '', '', '8', '1117', '1117', '', '', '', 'MD SABE', '', 'SALMA SABE', '', '41/B, JANNAGA OAD, KOL - 17', '', '', '', '', '', '9903333348', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903333348', '9903333348', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(623, 1, '', '', 'SUFI NOO', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '8', '943', '943', '', '', '', 'MD KHUSHID ALAM', '', 'IZWANA KHATOON', '', '20 KUSTIA OAD KOL - 39', '', '', '', '', '', '9831315585', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831315585', '9831315585', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(624, 1, '', '', 'SUMAIYA PAVEEN', '2008-06-18', '', 'FEMALE', '', '', '', '', '', '', '8', '1238', '1238', '', '', '', 'MD FAIYAZ ALAM', '', 'SULTANA KHATOON', '', '2H, TILJALA LANE, KOLKATA -  700019', '', '', '', '', '', '7686857039', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7686857039', '7686857039', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(625, 1, '', '', 'UMAH AFAQUE', '2008-12-08', '', 'FEMALE', '', '', '', '', '', '', '8', '1130', '1130', '', '', '', 'AFAQUE AHMED', '', 'SHAHMINA IMAN', '', '2E/3, CANTOPHE LANE, KOL - 14', '', '', '', '', '', '8420228531', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420228531', '8420228531', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(626, 1, '', '', 'ZAINA SAHA KHAN', '2008-08-18', '', 'FEMALE', '', '', '', '', '', '', '8', '1131', '1131', '', '', '', 'MD.AUANGZEB KHAN', '', 'SAWAI KHAN', '', '1/1A/H/2 EKBALPOE OAD KOL-23', '', '', '', '', '', '8017366234', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8017366234', '8017366234', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(627, 1, '', '', 'ZOYA FIDOUS', '2007-12-14', '', 'FEMALE', '', '', '', '', '', '', '8', '1224', '1224', '', '', '', 'MD. SUHAIL', '', 'SHABANA KHATOON', '', '63, GADENE LANE, KOL-14 (Taltala)', '', '', '', '', '', '7890338481', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890338481', '7890338481', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(628, 1, '', '', 'SAA ALTAF', '2008-11-17', '', 'FEMALE', '', '', '', '', '', '', '8', '1528', '1528', '', '', '', 'MD ALTAF AHMED', '', 'FAZANA ALTAF', '', '39/H/3 SHAMSUL HUDA OAD KOL 17', '', '', '', '', '', '9748622140', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748622140', '9748622140', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(629, 1, '', '', 'SAMIYA', '2009-10-23', '', 'FEMALE', '', '', '', '', '', '', '8', '1702', '1702', '', '', '', 'SK SHAFIU AHMAN', '', 'MASMAD MAJEDA', '', 'VILL: BENUDIA. PO+PS. BHAGWANPU. DIST: PUBA MIDNAPU.', '', '', '', '', '', '7407203447', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7407203447', '7407203447', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(630, 1, '', '', 'AFNAN NASIM', '2008-11-20', '', 'MALE', '', '', '', '', '', '', '8', '1128', '1128', '', '', '', 'SHAHNAWAZ NASIM', '', 'SHAGUFTA NISHAT AYYUBI', '', '16, SI SYED AHMED OAD, KOL-14', '', '', '', '', '', '9883336489', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883336489', '9883336489', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(631, 1, '', '', 'AMAAD SAQUIB ANAS', '2008-12-14', '', 'MALE', '', '', '', '', '', '', '8', '1134', '1134', '', '', '', 'SAQUIB ANAS', '', 'SANA SAQUIB', '', '13, A PHEAS LANE AFZAL MANJIL KOL - 12', '', '', '', '', '', '9007787011', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007787011', '9007787011', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(632, 1, '', '', 'AMANULLAH BIN ASHAF', '2008-01-04', '', 'MALE', '', '', '', '', '', '', '8', '1116', '1116', '', '', '', 'ASHAF JAMAL', '', 'NUZHAT FATEMA', '', '78, BOAD STEET, KOL - 19', '', '', '', '', '', '9681331321', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681331321', '9681331321', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(633, 1, '', '', 'ANAS IFTEKHA', '2009-03-23', '', 'MALE', '', '', '', '', '', '', '8', '1190', '1190', '', '', '', 'IFTEKHA ALAM ', '', 'AUSHNI PAWEEN', '', '26.AI CHAAN GHOSH LANE KOL 39', '', '', '', '', '', '8340329321', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8340329321', '8340329321', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(634, 1, '', '', 'ASAD MUTAZA', '2008-08-12', '', 'MALE', '', '', '', '', '', '', '8', '1123', '1123', '', '', '', 'NAUSHAD ANWE', '', 'GULEZ HASAN', '', '55/C TOPSIA OAD KOL-46', '', '', '', '', '', '9903117947', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903117947', '9903117947', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(635, 1, '', '', 'ATHA IMAM', '2008-08-03', '', 'MALE', '', '', '', '', '', '', '8', '1118', '1118', '', '', '', 'AZHA IMAM', '', 'IZWANA IMAM', '', '4, TILJALA LANE, KOL - 39', '', '', '', '', '', '9331456409', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331456409', '9331456409', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(636, 1, '', '', 'EKHHLAS ALAM', '2008-10-20', '', 'MALE', '', '', '', '', '', '', '8', '1177', '1177', '', '', '', 'NAUSHAD ALAM', '', 'SHAISTA SHAHEEN', '', '12C,IBAHIM OAD KOL - 23', '', '', '', '', '', '9836311589', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836311589', '9836311589', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(637, 1, '', '', 'EMAD MALLICK', '2009-12-21', '', 'MALE', '', '', '', '', '', '', '8', '1147', '1147', '', '', '', 'PAVEZ ALAM', '', 'SABILA KHATOON', '', '6D/ 1B TILJALA SHIBTALA LANE KOL-39', '', '', '', '', '', '8777866005', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8777866005', '8777866005', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(638, 1, '', '', 'FAIZAN WASIM', '2007-07-21', '', 'MALE', '', '', '', '', '', '', '8', '1121', '1121', '', '', '', 'MD WASIM', '', 'NAHID FIDOUS', '', '110/H/8, ELLIOT OAD, KOL-16', '', '', '', '', '', '9831720871', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831720871', '9831720871', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(639, 1, '', '', 'FAAZ AHMED', '2007-06-08', '', 'MALE', '', '', '', '', '', '', '8', '688', '688', '', '', '', 'SAGHI AHMED', '', 'ESHMA KHATOON', '', '17, BECK BAGAN OW, KKOL - 17', '', '', '', '', '', '9831447768', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831447768', '9831447768', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(640, 1, '', '', 'HAMZAA  KHAN', '2008-09-27', '', 'MALE', '', '', '', '', '', '', '8', '1176', '1176', '', '', '', 'MD.JAWAID KHAN', '', 'SHAGUFTA BEGUM', '', '52/2 KALMAX SAAM KHIDDE PU KOL-23', '', '', '', '', '', '9339847213', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339847213', '9339847213', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(641, 1, '', '', 'MD  ZAYAAN SHAHID', '2008-05-26', '', 'MALE', '', '', '', '', '', '', '8', '1133', '1133', '', '', '', 'MD SHAHID KAMAL', '', 'SABA KHATOON', '', '11/ CHAMU KHANSAMA LANE, CICUS AVE. 700014', '', '', '', '', '', '9831009705', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831009705', '9831009705', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(642, 1, '', '', 'MD AAMI QUAISHI', '', '', 'MALE', '', '', '', '', '', '', '8', '1222', '1222', '', '', '', 'MD AFSA FATEHPUI', '', 'FAZANA BEGUM', '', '36/1E/1K, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '9903652307', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903652307', '9903652307', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(643, 1, '', '', 'MD ABBAS HUSSAIN', '2009-01-31', '', 'MALE', '', '', '', '', '', '', '8', '1165', '1165', '', '', '', 'MD MEAJUDDIN', '', 'SHAGUFTA MEAJ', '', '20, KABITITHA SAANI, KOL - 23', '', '', '', '', '', '9163672786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163672786', '9163672786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(644, 1, '', '', 'MD ABDULLAH YOUSUF', '2008-07-15', '', 'MALE', '', '', '', '', '', '', '8', '1261', '1261', '', '', '', 'MD YOUSUF ZIA', '', 'SEEMA YOUSUF', '', '6, COLOOTOLA LANE KOL-73', '', '', '', '', '', '9830516963', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830516963', '9830516963', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(645, 1, '', '', 'MD ABU TALHA', '2008-06-05', '', 'MALE', '', '', '', '', '', '', '8', '895', '895', '', '', '', 'MD SHAHNAWAZ', '', 'FAIDA BEGUM', '', '4/1B CONVENT LANE, KOL - 15', '', '', '', '', '', '7278606203', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7278606203', '7278606203', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(646, 1, '', '', 'MD AQUDUS ASHAD', '2009-03-30', '', 'MALE', '', '', '', '', '', '', '8', '1189', '1189', '', '', '', 'ASHAD KAMAL', '', 'AYESHA ASHAD', '', '1,G SABGACHI 1ST LANE KOL-39', '', '', '', '', '', '9830739692', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830739692', '9830739692', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(647, 1, '', '', 'MD BIALAL', '2008-10-22', '', 'MALE', '', '', '', '', '', '', '8', '1170', '1170', '', '', '', 'MD ADIL', '', 'DAAKHSAN FATMA', '', '105/4, KAAYA OAD, KOL-17', '', '', '', '', '', '7439038418', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7439038418', '7439038418', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(648, 1, '', '', 'MD HADI KHAN', '2008-05-10', '', 'MALE', '', '', '', '', '', '', '8', '1186', '1186', '', '', '', 'MD AFSA KHAN', '', 'UMANA KHATOON', '', '12/2A, PALM AVENUE, KO L - 19', '', '', '', '', '', '9830250300', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830250300', '9830250300', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(649, 1, '', '', 'MD HAMZA FAOOQUE', '2008-07-12', '', 'MALE', '', '', '', '', '', '', '8', '1184', '1184', '', '', '', 'MD FAOOQUE', '', 'SHABANA PAVEEN', '', '12,H / 3 AGA MEHDI STEET KOLKATA - 16', '', '', '', '', '', '9748205956', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748205956', '9748205956', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(650, 1, '', '', 'MD HAMZA KAMAL', '2008-06-13', '', 'MALE', '', '', '', '', '', '', '8', '1132', '1132', '', '', '', 'MD KAMAL AZAD', '', 'NAHIDA PAVEEN', '', '36/1/H/2 BIGHT STEET KOL-17', '', '', '', '', '', '9748215981', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748215981', '9748215981', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(651, 1, '', '', 'MD HASNAIN', '2008-01-14', '', 'MALE', '', '', '', '', '', '', '8', '1119', '1119', '', '', '', 'MD AYUB', '', 'KHUSNUMA BANO', '', '8M. TOPSIA OAD, KOL - 39 ', '', '', '', '', '', '8100335453', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100335453', '8100335453', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(652, 1, '', '', 'MD MAAUF ISHAD', '2008-05-19', '', 'MALE', '', '', '', '', '', '', '8', '1039', '1039', '', '', '', 'MD ISHAD ALAM', '', 'SHABNAM PAVEEN', '', '41/A, TILJALA LANE, KOL - 39', '', '', '', '', '', '9038594824', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038594824', '9038594824', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(653, 1, '', '', 'MD MUZTABA', '2008-04-27', '', 'MALE', '', '', '', '', '', '', '8', '1179', '1179', '', '', '', 'MD FAKHUDDIN', '', 'SHAISTA PAVEEN', '', '4, SUHWADY AVENUE, KOL - 17', '', '', '', '', '', '9831587753', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831587753', '9831587753', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(654, 1, '', '', 'MD SHADAAN AKHTE', '2009-01-15', '', 'MALE', '', '', '', '', '', '', '8', '1199', '1199', '', '', '', 'MD.SHAHID AKHTE', '', 'GHEZALA PAVEEN', '', '85/P TOPSIA OAD KOL-39', '', '', '', '', '', '9681628906', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681628906', '9681628906', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(655, 1, '', '', 'MOHAMMED YAKUB AZA', '2008-09-08', '', 'MALE', '', '', '', '', '', '', '8', '1120', '1120', '', '', '', 'AHMED AZA', '', 'ALIYA BANO', '', '70B, TILJALA OAD KOL - 46', '', '', '', '', '', '9903688349', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903688349', '9903688349', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(656, 1, '', '', 'EHAN ASHAD', '2008-08-22', '', 'MALE', '', '', '', '', '', '', '8', '1145', '1145', '', '', '', 'ASHAD ALTAF', '', 'NISHAT AHMED', '', '31/A MIAJAN OSTAGA LANE KOLKATA - ', '', '', '', '', '', '9007648559', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007648559', '9007648559', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(657, 1, '', '', 'SHIEKH ANAS', '2007-12-22', '', 'MALE', '', '', '', '', '', '', '8', '695', '695', '', '', '', 'SK SHAFUDDIN', '', 'HALIMA KHATOON', '', '10B, TILJALA OAD,  KOL - 46', '', '', '', '', '', '9331071674', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331071674', '9331071674', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(658, 1, '', '', 'SK. TAHI NAWAZ', '2008-08-13', '', 'MALE', '', '', '', '', '', '', '8', '1192', '1192', '', '', '', 'SK. SAFAAZ NAWAZ', '', 'TABASSUM BEGUM', '', '7/H/2, AHIPUKU 2ND LANE, KOL-19', '', '', '', '', '', '8335863588', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8335863588', '8335863588', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(659, 1, '', '', 'TAHA SHAMS', '2008-09-09', '', 'MALE', '', '', '', '', '', '', '8', '1152', '1152', '', '', '', 'MD SHAMSUDDIN', '', 'AZIA BEGUM', '', '37/5A, WATGUNGE STEET, KOL - 23', '', '', '', '', '', '9903482692', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903482692', '9903482692', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(660, 1, '', '', 'HAMZA AHMED', '2008-10-29', '', 'MALE', '', '', '', '', '', '', '8', '1705', '1705', '', '', '', 'MEAJUDDIN AHMED', '', 'BILQUIS AA', '', '9H/1, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '9073448553', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9073448553', '9073448553', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(661, 1, '', '', 'AEMAN PAWEZ', '2007-07-26', '', 'FEMALE', '', '', '', '', '', '', '9', '610', '610', '', '', '', 'MD. PEWEZ ALAM', '', 'NAHID PEWEZ', '', '17A/2 TOPSIA 2ND LANE - KOL- 39', '', '', '', '', '', '9831003411', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831003411', '9831003411', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(662, 1, '', '', 'ALIEFYA HAFIZ', '2007-12-25', '', 'FEMALE', '', '', '', '', '', '', '9', '698', '698', '', '', '', 'SK HAFIZUDDIN', '', 'AFAT HAFIZ', '', '25, C.N.OY OAD, KOL - 39', '', '', '', '', '', '9831283091', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831283091', '9831283091', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(663, 1, '', '', 'ANABIA IMTIAZ', '2007-10-21', '', 'FEMALE', '', '', '', '', '', '', '9', '1143', '1143', '', '', '', 'IMTIAZ ALAM', '', 'NAZIA PAVEEN', '', 'BL-L/38, WEST CHOWBAGA, KOLKATA - 700100', '', '', '', '', '', '7506560747', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7506560747', '7506560747', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(664, 1, '', '', 'ASHI KHANAM', '2007-12-08', '', 'FEMALE', '', '', '', '', '', '', '9', '569', '569', '', '', '', 'SAJET KHAN', '', 'IZWANA BEGUM', '', '110/A, KAAYA OAD, KOL - 17', '', '', '', '', '', '9903505954', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903505954', '9903505954', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(665, 1, '', '', 'AZKA AZA', '2007-11-10', '', 'FEMALE', '', '', '', '', '', '', '9', '585', '585', '', '', '', 'SYED ALI AZA', '', 'KHALIDAH', '', '16H/4, BECK BAGAN OW, KOL-17', '', '', '', '', '', '8961236617', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8961236617', '8961236617', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(666, 1, '', '', 'FALAH HAQUE', '2007-10-06', '', 'FEMALE', '', '', '', '', '', '', '9', '620', '620', '', '', '', 'MD ANISUL HAQUE', '', 'SIYA HAQUE', '', '10/1B, GOA CHAND LANE, KOL - 14', '', '', '', '', '', '9831464407', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831464407', '9831464407', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(667, 1, '', '', 'FATHIMA SHAKIL', '2007-10-27', '', 'FEMALE', '', '', '', '', '', '', '9', '617', '617', '', '', '', 'SHAKIL AHMED', '', 'ZEENAT PAVEEN', '', '7/1D, ABHINASH CHOWDHUY LANE, KOL - 46', '', '', '', '', '', '7044574047', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7044574047', '7044574047', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(668, 1, '', '', 'FATHMA SAANI', '2007-02-22', '', 'FEMALE', '', '', '', '', '', '', '9', '1187', '1187', '', '', '', 'SK SHAMIM ALAM', '', 'SAJJU ANI', '', '62D, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '9903605547', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903605547', '9903605547', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(669, 1, '', '', 'HABIBA KHATOON', '2007-05-19', '', 'FEMALE', '', '', '', '', '', '', '9', '793', '793', '', '', '', 'BELAL HUSSAIN', '', 'ZUBAIDA KHATOON', '', '4, CEMATOIUM STEET, KOL - 14', '', '', '', '', '', '9830726242', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830726242', '9830726242', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(670, 1, '', '', 'KASAB SHAKI', '2007-11-21', '', 'FEMALE', '', '', '', '', '', '', '9', '751', '751', '', '', '', 'MD SHAKI', '', 'UBI NAZ', '', '18A, MIA JAN OSTAGA LANE,  KOL - 17', '', '', '', '', '', '8583846266', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8583846266', '8583846266', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(671, 1, '', '', 'KHOLUD QAMA', '2006-11-30', '', 'FEMALE', '', '', '', '', '', '', '9', '703', '703', '', '', '', 'MOHD QAMAUDDIN', '', 'MASIHA KHATOON', '', 'G.J KHAN OAD KOLKATA-39', '', '', '', '', '', '9073914926', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9073914926', '9073914926', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(672, 1, '', '', 'KHUSHNUMA KHATOON', '2007-11-25', '', 'FEMALE', '', '', '', '', '', '', '9', '910', '910', '', '', '', 'MD.SALAM', '', 'MUMTAZ BEGUM', '', '6/3 A -G.J.KHAN  OAD KOL.-39', '', '', '', '', '', '9748577182', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748577182', '9748577182', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(673, 1, '', '', 'KHUSNUMA AZMI', '2007-04-20', '', 'FEMALE', '', '', '', '', '', '', '9', '545', '545', '', '', '', 'MD FAKHUDDIN', '', 'SAISTA PAVEEN', '', '4,SAWADY AVENUE KOLKATA-17', '', '', '', '', '', '9831587753', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831587753', '9831587753', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(674, 1, '', '', 'LAAAIB MAHPAA', '2007-01-20', '', 'FEMALE', '', '', '', '', '', '', '9', '1230', '1230', '', '', '', 'ADNAN SHAHID', '', 'SAIQUA ADNAN SHAHID', '', '80 A/12 TOPSIA OAD KOLKATA 700039', '', '', '', '', '', '9331322674', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331322674', '9331322674', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(675, 1, '', '', 'MAHEU TAIYABA', '2007-12-22', '', 'FEMALE', '', '', '', '', '', '', '9', '624', '624', '', '', '', 'SAFAAZ AHMED', '', 'SHABANA AHMED', '', '14/2 si syed ahmed oad kol.14', '', '', '', '', '', '9339777340', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339777340', '9339777340', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(676, 1, '', '', 'MAIAH AFAQUE', '2007-10-05', '', 'FEMALE', '', '', '', '', '', '', '9', '605', '605', '', '', '', 'AFAQUE SHAMIM', '', 'SADAF FIDOUS SHAKIL', '', '2, ADHA GOBINDA SAHA LANE, KOL - 17', '', '', '', '', '', '9831640500', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831640500', '9831640500', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(677, 1, '', '', 'MASIA NESHA', '2006-08-13', '', 'FEMALE', '', '', '', '', '', '', '9', '59', '59', '', '', '', 'MD. SHAKI ', '', ' SHABANA BEGUM ', '', '5.N SAPGACHI IST LANE KOL 39', '', '', '', '', '', '8276987574', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8276987574', '8276987574', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(678, 1, '', '', 'NAUEEN ALIM', '2007-10-04', '', 'FEMALE', '', '', '', '', '', '', '9', '591', '591', '', '', '', 'ASIF ALIM', '', 'NAJIBA ALIM', '', '15, LOWE ANGE,KOL-17', '', '', '', '', '', '9163664455', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163664455', '9163664455', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(679, 1, '', '', 'NIDA ELAHI', '2008-07-29', '', 'FEMALE', '', '', '', '', '', '', '9', '826', '826', '', '', '', 'MD IFANULLAH', '', 'NAZIA PAVEEN', '', '20 B GUHA  STEET KOL-17', '', '', '', '', '', '9748626314', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748626314', '9748626314', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(680, 1, '', '', 'NOOAIN FATMA', '2007-11-16', '', 'FEMALE', '', '', '', '', '', '', '9', '622', '622', '', '', '', 'MD JAWED', '', 'NISHAT FATMA', '', '50/A, MOFIDUL ISLAM LANE, KOL - 14', '', '', '', '', '', '7890060086', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890060086', '7890060086', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(681, 1, '', '', 'SADIYA KHATOON', '2006-07-24', '', 'FEMALE', '', '', '', '', '', '', '9', '1563', '1563', '', '', '', 'SHAHNAWAZ KHAN', '', 'NOO ZEENAT KHATOON', '', 'B/2/1/H/4, CANAL EAST OAD, KOLKATA - 700011', '', '', '', '', '', '9006715049', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9006715049', '9006715049', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(682, 1, '', '', 'SANIA KHATOON', '2006-09-16', '', 'FEMALE', '', '', '', '', '', '', '9', '580', '580', '', '', '', 'MD SHABBI', '', 'SHAJAHAN BIBI', '', '88/2, JHOWTALLA OAD, KOL - 17', '', '', '', '', '', '9830188786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830188786', '9830188786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(683, 1, '', '', 'SHAIMA ASHAF KHAN', '2007-09-27', '', 'FEMALE', '', '', '', '', '', '', '9', '989', '989', '', '', '', 'ASHAF KHAN', '', 'LATE TABASSUM AHMAN', '', '42 H/10, JANNAGA OAD, KOLKATA - 700017', '', '', '', '', '', '9331426761', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331426761', '9331426761', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(684, 1, '', '', 'SHAIKA PAVEEN', '2008-03-03', '', 'FEMALE', '', '', '', '', '', '', '9', '1551', '1551', '', '', '', 'MD SHAHANNAWAZ', '', 'AZIA KHATOON', '', '2C/H/4, CHATU BABU LANE, KOLKATA - 700014', '', '', '', '', '', '9830781403', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830781403', '9830781403', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(685, 1, '', '', 'SHAZIA ALIM', '2007-10-04', '', 'FEMALE', '', '', '', '', '', '', '9', '592', '592', '', '', '', 'ASIF ALIM', '', 'NAJIBA ALIM', '', '15, LOWE ANGE,KOL-17', '', '', '', '', '', '9163664455', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163664455', '9163664455', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(686, 1, '', '', 'SIDA ISTEKHA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '9', '877', '877', '', '', '', 'ISTEKHAUL HAQUE', '', 'SHAMA PAVEEN', '', 'MOAY MAHAL, LINKING OAD, BANDA (W), MUMBAI - 400050', '', '', '', '', '', '8282813998', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8282813998', '8282813998', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(687, 1, '', '', 'SUMAIYA FATHMA', '2007-05-29', '', 'FEMALE', '', '', '', '', '', '', '9', '713', '713', '', '', '', 'MD ASLAM', '', 'AYESHA KHATOON', '', '41/C JANNAGA OAD KOL-17', '', '', '', '', '', '6290004684', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '6290004684', '6290004684', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(688, 1, '', '', 'TAAIBAH MAYAM', '2007-04-09', '', 'FEMALE', '', '', '', '', '', '', '9', '581', '581', '', '', '', 'MD KHALID MISBAH', '', 'NASEEN JAHAN', '', '19/D, SI SYED AHMED OAD, KOL - 14', '', '', '', '', '', '9681127815', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681127815', '9681127815', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(689, 1, '', '', 'TAIYABUN MISBAH', '2019-02-06', '', 'FEMALE', '', '', '', '', '', '', '9', '860', '860', '', '', '', 'JAWED AHMED', '', 'IZWANA JAWED', '', '36/1, TOPSIA OAD (EAST), KOL - 39', '', '', '', '', '', '9831895452', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831895452', '9831895452', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(690, 1, '', '', 'ZAINAB ALI', '2008-02-05', '', 'FEMALE', '', '', '', '', '', '', '9', '818', '818', '', '', '', 'SK MOJAHID ALI', '', 'BABA MAJID', '', '17/H/6, BECKBAGAN OW, KOL - 17', '', '', '', '', '', '9007976702', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007976702', '9007976702', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(691, 1, '', '', 'ZAINAB SHAMSI', '2008-02-04', '', 'FEMALE', '', '', '', '', '', '', '9', '1115', '1115', '', '', '', 'MD.NASIM SHAMSI  ', '', 'SAMEEA NASIM SHAMSI', '', '11,GOPAL CHANDA LANE KOL-73', '', '', '', '', '', '9831270149', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831270149', '9831270149', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(692, 1, '', '', 'ZAA ASHI', '2007-09-10', '', 'FEMALE', '', '', '', '', '', '', '9', '795', '795', '', '', '', 'MD SHAKIL AHMAD', '', 'MAJDA KHATOON', '', '8/1D, Ist LANE SANPGACHI, TOPSIA, P.S. TILJALA, KOL - 39', '', '', '', '', '', '9339052252', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339052252', '9339052252', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(693, 1, '', '', 'ZAA PAVEEN', '2007-10-22', '', 'FEMALE', '', '', '', '', '', '', '9', '586', '586', '', '', '', 'SYED PAWEZ AHMED', '', 'ALIA TABASSUM', '', '1, JANNAGA OAD, KOL - 17', '', '', '', '', '', '9681898964', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681898964', '9681898964', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(694, 1, '', '', 'ZOYA AHMED - 1', '2007-10-09', '', 'FEMALE', '', '', '', '', '', '', '9', '661', '661', '', '', '', 'AFOZE AHMED', '', 'TASNEEM KAUSA', '', '3/H/2, AJA DINENDA STEET, KOL - 9', '', '', '', '', '', '7980034283', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980034283', '7980034283', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(695, 1, '', '', 'MAHAWISH FIDOS', '2007-07-27', '', 'FEMALE', '', '', '', '', '', '', '9', '712', '712', '', '', '', 'MD AZHA EHSAN', '', 'HINA FIDOUS', '', '17/2/H/6,SMITH LANE KOL - 13', '', '', '', '', '', '9831484952', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831484952', '9831484952', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(696, 1, '', '', 'ZIKA AZAM', '2008-08-08', '', 'FEMALE', '', '', '', '', '', '', '9', '1714', '1714', '', '', '', 'FAOOQUE AZAM', '', 'ASHI AMI', '', 'KABI MOHALLAH, AUANGABAD, BIHA-824101\n89/H/10, NAKELDANGA NOTH OAD, KOLKATA-700011', '', '', '', '', '', '9431408651', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9431408651', '9431408651', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(697, 1, '', '', 'ABUZA EHTESHAM', '2007-10-12', '', 'MALE', '', '', '', '', '', '', '9', '968', '968', '', '', '', 'MD ABU NASA', '', 'WAHEDA PAWEEN', '', '14B, TOPSIA 2ND LANE, KOL - 39', '', '', '', '', '', '9163363791', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163363791', '9163363791', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(698, 1, '', '', 'AFNAN IBAHIM', '2007-04-14', '', 'MALE', '', '', '', '', '', '', '9', '797', '797', '', '', '', 'SK IBAHIM', '', 'IZWANA IBAHIM', '', '7/B - 12, TILJALA LANE, KOL - 19', '', '', '', '', '', '9831234904', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831234904', '9831234904', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(699, 1, '', '', 'AFNAN ZUBAI ISMAIL', '2007-09-12', '', 'MALE', '', '', '', '', '', '', '9', '709', '709', '', '', '', 'H.MD. A. SUHAIL ISMAIL', '', 'MEENA ASUL SUHAIL ISMAIL', '', '100H/6, DILKUSHA STEET, KOL - 17', '', '', '', '', '', '9831249706', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831249706', '9831249706', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(700, 1, '', '', 'AIZ AHMED', '2008-02-25', '', 'MALE', '', '', '', '', '', '', '9', '1164', '1164', '', '', '', 'Ajaz Ahmed ', '', 'Shabana Afoze', '', '1/2 H/18 Jiban Kishna Ghosh d. Kol-37', '', '', '', '', '', '9830677811', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830677811', '9830677811', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(701, 1, '', '', 'AZHAN MASOO', '2007-11-25', '', 'MALE', '', '', '', '', '', '', '9', '570', '570', '', '', '', 'MASOO AHMED', '', 'AAMA TABASSUM', '', '12,KUSHTIA MASJID BAI LANE,KOL - 39', '', '', '', '', '', '9831942909', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831942909', '9831942909', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(702, 1, '', '', 'BILAL MAHFOOZ', '2006-09-28', '', 'MALE', '', '', '', '', '', '', '9', '1032', '1032', '', '', '', 'MAHFOOZ ALAM  ', '', 'HENA PAVEEN', '', '27A, METCALF STEET KOLKATA-700013', '', '', '', '', '', '8981830210', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8981830210', '8981830210', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(703, 1, '', '', 'FAZAL HUSSAIN DAIYA', '2006-08-21', '', 'MALE', '', '', '', '', '', '', '9', '1191', '1191', '', '', '', 'MD.KHALIL DAIYA  ', '', 'NAJMA KHATOON', '', '3A,SAGA DUTTA LANE KOL-73', '', '', '', '', '', '9330066304', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330066304', '9330066304', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(704, 1, '', '', 'FUQAN MASHA ISMAIL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '9', '950', '950', '', '', '', 'ABDUL BASIT ISMAIL', '', 'FAZANA BASIT', '', '4 JANNAGA 2nd LANE, KOL - 14', '', '', '', '', '', '9831550593', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831550593', '9831550593', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(705, 1, '', '', 'HUZAIFA AKHTA', '2007-04-07', '', 'MALE', '', '', '', '', '', '', '9', '567', '567', '', '', '', 'IMTIAZ AKHTA', '', 'ASHIYA AKHTA', '', '36E, AGA MEHDI STEET,  KOL - 16', '', '', '', '', '', '8961611236', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8961611236', '8961611236', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(706, 1, '', '', 'MD ABU HAMZA', '2008-02-17', '', 'MALE', '', '', '', '', '', '', '9', '606', '606', '', '', '', 'MD. ABULLAIS', '', 'NAZIA KHATOON', '', '2/H/16 HATI BAGAN D. KOL- 14', '', '', '', '', '', '9831519911', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831519911', '9831519911', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(707, 1, '', '', 'MD ADNAN AKAM      ', '2007-11-22', '', 'MALE', '', '', '', '', '', '', '9', '1031', '1031', '', '', '', 'GHULAM AKAM', '', 'SALMA KHATOON', '', ' 83J /H/1  BELGACHIA OAD, KOL-37', '', '', '', '', '', '9231155773', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9231155773', '9231155773', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(708, 1, '', '', 'MD AMAAN KHAN', '2007-01-28', '', 'MALE', '', '', '', '', '', '', '9', '602', '602', '', '', '', 'IZHA KHAN', '', 'FAZANA KHANAM', '', '17/A, TILJALA SHIBTALA LANE, KOL - 39', '', '', '', '', '', '9831994160', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831994160', '9831994160', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(709, 1, '', '', 'MD ATIF ISLAM', '2008-03-26', '', 'MALE', '', '', '', '', '', '', '9', '658', '658', '', '', '', 'MD WAIS ISLAM', '', 'SHABNAM PAVEEN', '', '15/H/3, SMITH LANE, KOL - 13', '', '', '', '', '', '9831301780', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831301780', '9831301780', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(710, 1, '', '', 'MD HAAIS ALI ZAMADA', '2007-11-17', '', 'MALE', '', '', '', '', '', '', '9', '750', '750', '', '', '', 'MD FAID ALI ZAMADA', '', 'ZEENAT ALI', '', '37/1/1A, BIGHT STEET, KOL - 17', '', '', '', '', '', '9732780777', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9732780777', '9732780777', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(711, 1, '', '', 'MD HAMMAS ANWA', '2007-09-12', '', 'MALE', '', '', '', '', '', '', '9', '806', '806', '', '', '', 'MD ANWA', '', 'JUHI PAVEEN', '', 'T-155-J, KESHAB CHANDA SEN STEET, KOL - 9', '', '', '', '', '', '8691226854', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8691226854', '8691226854', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(712, 1, '', '', 'MD HAMZA ALAM', '2006-12-02', '', 'MALE', '', '', '', '', '', '', '9', '483', '483', '', '', '', 'MD. SHAHNWAZ ', '', ' FAIDA BEGUM ', '', '4/1B,CONVENT LANE 1ST FLOO, KOL-15 ', '', '', '', '', '', '9748424791', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748424791', '9748424791', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(713, 1, '', '', 'MD IBAHIM ISLAM', '2007-07-15', '', 'MALE', '', '', '', '', '', '', '9', '587', '587', '', '', '', 'NAZUL ISLAM', '', 'TAMANNA PAVIN', '', '30/1/H/1, D SUESH SAKA OAD KOL - 14', '', '', '', '', '', '9748433471', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748433471', '9748433471', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(714, 1, '', '', 'MD KABI', '2007-04-22', '', 'MALE', '', '', '', '', '', '', '9', '601', '601', '', '', '', 'MD SHAHID', '', 'NUZHAT SHAHID', '', '12/H/21, BEDFOD LANE, KOL - 16', '', '', '', '', '', '8820022019', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8820022019', '8820022019', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(715, 1, '', '', 'MD MAOOF', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '9', '851', '851', '', '', '', 'MD IBAHIM', '', 'TABASSUM JAHAN', '', '81, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9831638503', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831638503', '9831638503', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(716, 1, '', '', 'MD MOBASHI IQBAL', '2007-04-13', '', 'MALE', '', '', '', '', '', '', '9', '1067', '1067', '', '', '', 'MD.MOZAMMIL IQBAL  ', '', 'SAMINA KHATOON', '', '13/B, PHEAS LANE KOL-12', '', '', '', '', '', '9143431693', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9143431693', '9143431693', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(717, 1, '', '', 'MD EHAN AHMED', '2007-12-09', '', 'MALE', '', '', '', '', '', '', '9', '670', '670', '', '', '', 'MINHAJ AHMED', '', 'KANIZ FATMA', '', '15/1C, SI SYED AHMED OAD, KOL - 14', '', '', '', '', '', '8910550764', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8910550764', '8910550764', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(718, 1, '', '', 'MD SADIQUE', '2006-11-01', '', 'MALE', '', '', '', '', '', '', '9', '983', '983', '', '', '', 'MD SABI ALI', '', 'MUSTAI KHATOON', '', '82D, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '8100903210', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100903210', '8100903210', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(719, 1, '', '', 'MD ZAID MUMTAZ', '2006-11-01', '', 'MALE', '', '', '', '', '', '', '9', '827', '827', '', '', '', 'MD MUMTAZ', '', 'BANO BEGUM', '', '296/1/H/4, A P C OAD, KO - 9', '', '', '', '', '', '9830175158', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830175158', '9830175158', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(720, 1, '', '', 'MOHAMMAD KAMAN', '2007-06-30', '', 'MALE', '', '', '', '', '', '', '9', '538', '538', '', '', '', 'MD OMA', '', 'Mumtaz Begum', '', '48,TOPSIA OAD SOUTH KOLKATA-46', '', '', '', '', '', '8621019228', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8621019228', '8621019228', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(721, 1, '', '', 'MOHAMMED ALI', '2007-08-31', '', 'MALE', '', '', '', '', '', '', '9', '833', '833', '', '', '', 'KAUSE ALI', '', 'UKSANA BEGUM', '', '24/1 PALM AVENUE KOLKATA - 19', '', '', '', '', '', '9674999032', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674999032', '9674999032', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(722, 1, '', '', 'MOHD. UMA ZAID', '2007-06-15', '', 'MALE', '', '', '', '', '', '', '9', '711', '711', '', '', '', 'NAUSHAD AKHTA', '', 'NAZIA ZAFA', '', '15/3 TOPSIA 2ND LANE, KOL -39', '', '', '', '', '', '8100980459', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100980459', '8100980459', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(723, 1, '', '', 'MOHHAMED AFFAN', '2006-12-05', '', 'MALE', '', '', '', '', '', '', '9', '1049', '1049', '', '', '', 'MOHAMMED ISHAD ', '', ' AFSANA', '', '26,NIL MADHAB SEN LANE KOL-73', '', '', '', '', '', '9831647258', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831647258', '9831647258', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(724, 1, '', '', 'NAADI HUSSAIN', '2007-02-24', '', 'MALE', '', '', '', '', '', '', '9', '563', '563', '', '', '', 'LIAKAT HOSSAIN', '', 'JAHAN AA KHATOON', '', '13/H/44, BAUN FELD OW (EQBALPU) KOL - 27', '', '', '', '', '', '9748822227', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748822227', '9748822227', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(725, 1, '', '', 'SHADAKAT ALI EKBAL', '2007-10-21', '', 'MALE', '', '', '', '', '', '', '9', '576', '576', '', '', '', 'ZAWED EKBAL', '', 'UKSHA BEGUM', '', '60/H/10, D, SUDHI BOSE OAD, KOL -23', '', '', '', '', '', '9433554924', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9433554924', '9433554924', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(726, 1, '', '', 'SK ATTIKAB ALI', '2007-10-05', '', 'MALE', '', '', '', '', '', '', '9', '1235', '1235', '', '', '', 'SK SHAGID ALI', '', 'NOOJAHAN BEGUM', '', '25 TILJALA OAD KOLKATA -46', '', '', '', '', '', '8013166665', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8013166665', '8013166665', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(727, 1, '', '', 'SK. AYAZ', '2008-04-10', '', 'MALE', '', '', '', '', '', '', '9', '564', '564', '', '', '', 'SK.MAJAFU ', '', 'TANUJA KHATOON', '', '37/1, TALTALA LANE, PO.PAK STEET, KOL-16', '', '', '', '', '', '8335937199', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8335937199', '8335937199', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(728, 1, '', '', 'SYED FAEIQUE IQBAL', '2008-03-16', '', 'MALE', '', '', '', '', '', '', '9', '625', '625', '', '', '', 'SYED SHAMIM IQBAL', '', 'FOUZIA NAHID', '', '10/A, JAN NAGA OAD, KOL - 17', '', '', '', '', '', '9903674098', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903674098', '9903674098', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(729, 1, '', '', 'SYED ZAID HOSSAIN', '2006-03-02', '', 'MALE', '', '', '', '', '', '', '9', '828', '828', '', '', '', 'SYED ENAM HOSSAIN', '', 'TAMANNA HOSSAIN', '', '1/H/8, AM MOHAN BEA LANE, KOL - 14', '', '', '', '', '', '9163735418', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163735418', '9163735418', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(730, 1, '', '', 'UBAI AHAMED', '2019-02-06', '', 'MALE', '', '', '', '', '', '', '9', '857', '857', '', '', '', 'SHAMIM AHAMED', '', 'NASIFA BEGUM', '', 'BHASHALA MOE. M N K OAD, PO-AMPU HAT, BIBHUM - 731224', '', '', '', '', '', '9153061751', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9153061751', '9153061751', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(731, 1, '', '', 'UMA ALI', '2007-12-08', '', 'MALE', '', '', '', '', '', '', '9', '764', '764', '', '', '', 'NAUSHAD ALI', '', 'NAZNEEN PAVEEN', '', '41/C/H/7 JANNAGA OAD KOLKATA - 17', '', '', '', '', '', '9831984225', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831984225', '9831984225', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(732, 1, '', '', 'ZAYED SEAJ', '2007-02-17', '', 'MALE', '', '', '', '', '', '', '9', '798', '798', '', '', '', 'SEAJUL HAQUE', '', 'AFSANA NASEEN', '', '15F, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9748971336', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748971336', '9748971336', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(733, 1, '', '', 'ZEESHAN KHAN', '2007-02-25', '', 'MALE', '', '', '', '', '', '', '9', '802', '802', '', '', '', 'TANWEE KHAN', '', 'SHABANA KHAN', '', '36/1/14, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9903882405', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903882405', '9903882405', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(734, 1, '', '', 'SK JUNAID ALAM', '2008-03-15', '', 'MALE', '', '', '', '', '', '', '9', '1522', '1522', '', '', '', 'SK MEHBOOB ALAM', '', 'FAIDA BEGUM', '', '31 F TOPSIA 2ND LANE - KOLKATA - 700039', '', '', '', '', '', '9775033196', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9775033196', '9775033196', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(735, 1, '', '', 'TAIQUE MUSHTAQUE KHAN', '2007-11-09', '', 'MALE', '', '', '', '', '', '', '9', '822', '822', '', '', '', 'MUSHTAQUE KHAN ', '', 'NOO SABA KHATOON', '', '7B, NEW KASIA BAGAN LANE, KOLKATA - 700017', '', '', '', '', '', '9007321328', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007321328', '9007321328', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(736, 1, '', '', 'AALIA AHMAN', '2007-01-20', '', 'FEMALE', '', '', '', '', '', '', '10', '821', '821', '', '', '', 'NAVID AHMAN', '', 'AFSHAN NAVID', '', '10/A, BOLAI DUTTA STEET, KOL - 73', '', '', '', '', '', '9831513546', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831513546', '9831513546', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(737, 1, '', '', 'AALIAH SABA', '2007-04-27', '', 'FEMALE', '', '', '', '', '', '', '10', '676', '676', '', '', '', 'TAIQUE SHAKEEL', '', 'FAAH AHMED', '', '3/7A, TILJALA LANE, KOL - 19 (GEEN PAK)', '', '', '', '', '', '9831644431', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831644431', '9831644431', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(738, 1, '', '', 'AAMNA YASEEN', '2007-01-14', '', 'FEMALE', '', '', '', '', '', '', '10', '719', '719', '', '', '', 'MD YASEEN', '', 'AFSAI KHATOON', '', '14/H/19, BIBI BAGAN LANE, KOL - 15', '', '', '', '', '', '8479000313', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8479000313', '8479000313', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(739, 1, '', '', 'ADIBA MUDDASSI', '2007-08-10', '', 'FEMALE', '', '', '', '', '', '', '10', '685', '685', '', '', '', 'MD. MUDDASSI KHATIB', '', 'NEMAT MUDDASSI KHATIB', '', '49, FAZALUL HAQUE SAANI, KOL - 19', '', '', '', '', '', '9831162375', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831162375', '9831162375', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(740, 1, '', '', 'ADIBA OBAIS', '2007-07-22', '', 'FEMALE', '', '', '', '', '', '', '10', '627', '627', '', '', '', 'OBAIS ALAM', '', 'NASEEN KHUISHIDA', '', '4A, AHI PUKU 2ND LANE, KOL - 19', '', '', '', '', '', '8981191306', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8981191306', '8981191306', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(741, 1, '', '', 'ALFISHA ZAFI', '2007-07-15', '', 'FEMALE', '', '', '', '', '', '', '10', '814', '814', '', '', '', 'MD ZAFI', '', 'ZEENAD ZAFI', '', '29/1, BENIAPUKU LANE,  KOL - 14', '', '', '', '', '', '9062607879', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062607879', '9062607879', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(742, 1, '', '', 'ALIZA PAVEEN', '2007-08-07', '', 'FEMALE', '', '', '', '', '', '', '10', '635', '635', '', '', '', 'BADUL HOSSAIN', '', 'SHANILA PAVEEN', '', '86/C, FAZLUL HAQUE SAANI, KOL -17', '', '', '', '', '', '9836403889', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836403889', '9836403889', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(743, 1, '', '', 'ALTASHIA IMAM', '2007-05-15', '', 'FEMALE', '', '', '', '', '', '', '10', '644', '644', '', '', '', 'MD IMAMUDDIN ANSAI', '', 'ASHIA IMAM', '', '11/2/H/4,HASHI STEET,  KOL - 9', '', '', '', '', '', '7003810594', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003810594', '7003810594', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(744, 1, '', '', 'ABI HOSSAIN', '2006-12-03', '', 'FEMALE', '', '', '', '', '', '', '10', '329', '329', '', '', '', 'ASGA HOSSAIN ', '', ' WAHIDA BEGUM', '', '38A, TOPSIA OAD KOL-39', '', '', '', '', '', '9830779411', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830779411', '9830779411', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(745, 1, '', '', 'AIBA ALAM', '2008-01-06', '', 'FEMALE', '', '', '', '', '', '', '10', '629', '629', '', '', '', 'MD IMTIAZ ALAM (FAHIM)', '', 'ASHIKA ALAM ', '', '11A/11, CHISTOPHE OAD, KOL - 14', '', '', '', '', '', '9831480171', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831480171', '9831480171', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(746, 1, '', '', 'AZALFA ALAM', '2007-09-24', '', 'FEMALE', '', '', '', '', '', '', '10', '647', '647', '', '', '', 'ASHFAQUE ALAM', '', 'SAWAT AFOZ', '', '71/1A, TILJILA OAD , KOL -46', '', '', '', '', '', '9830768275', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830768275', '9830768275', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(747, 1, '', '', 'BUSHA KHATOON', '2007-10-22', '', 'FEMALE', '', '', '', '', '', '', '10', '785', '785', '', '', '', ' ASHAD HUSSAIN', '', 'IZWANA KHATOON', '', '35/2 CANAL EAST OAD KOLKATA.11', '', '', '', '', '', '9330647256', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330647256', '9330647256', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(748, 1, '', '', 'DAAKSHA KHATOON', '2007-10-06', '', 'FEMALE', '', '', '', '', '', '', '10', '790', '790', '', '', '', 'MD. SABBI HOSSAIN', '', 'ZAINAB ', '', '5/ SAPGACHHI 1ST LANE- 39', '', '', '', '', '', '9123628439', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9123628439', '9123628439', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(749, 1, '', '', 'FAIZAH AKAM', '2007-04-26', '', 'FEMALE', '', '', '', '', '', '', '10', '887', '887', '', '', '', 'AKAM HUSSAIN', '', 'FAHANA KHATOON', '', 'T- 242/C BAABAGAN KOL-18', '', '', '', '', '', '9339127016', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339127016', '9339127016', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(750, 1, '', '', 'FATMA JAWED', '2007-10-14', '', 'FEMALE', '', '', '', '', '', '', '10', '677', '677', '', '', '', 'MD JAWED', '', 'SAJDA PAVEEN', '', '30, LINTON STEET, KOL - 14', '', '', '', '', '', '9883814474', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883814474', '9883814474', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(751, 1, '', '', 'IFA IMTIAZ', '2007-06-23', '', 'FEMALE', '', '', '', '', '', '', '10', '686', '686', '', '', '', 'MD IMTIAZ ', '', 'KUSUM AA KAMAL', '', '6B,TILJALA SHIBTALA LANE KOL - 39', '', '', '', '', '', '8240591034', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240591034', '8240591034', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(752, 1, '', '', 'INAAYA JAMAL', '2007-09-20', '', 'FEMALE', '', '', '', '', '', '', '10', '702', '702', '', '', '', 'JAMALUDDIN MOHAMMED', '', 'BUSHA JAMAL', '', '12/2, TOPSIA 2ND LANE, KOL-39', '', '', '', '', '', '9883333279', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883333279', '9883333279', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(753, 1, '', '', 'IQA TAISEEN', '2007-07-02', '', 'FEMALE', '', '', '', '', '', '', '10', '701', '701', '', '', '', 'MD.ZAHID HOSSAIN', '', 'IZWANA FIDOSH', '', '44D/1, SAMSUL HUDA OAD, KOLKATA - 700017', '', '', '', '', '', '9830305382', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830305382', '9830305382', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(754, 1, '', '', 'KAIKASHA KHATOON', '2008-04-10', '', 'FEMALE', '', '', '', '', '', '', '10', '694', '694', '', '', '', 'NAUSHAD ALI', '', 'SABA JABEEN', '', '30/7, JHOWTALA OAD, KOL - 17', '', '', '', '', '', '9088070067', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9088070067', '9088070067', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(755, 1, '', '', 'MADIHA AHMAN', '2008-02-25', '', 'FEMALE', '', '', '', '', '', '', '10', '959', '959', '', '', '', 'ABDU AHMAN', '', 'SHAHNAZ BEGUM', '', '3/2, SHAIKH PAA LANE, KONA EXPESS, HOWAH - 700004', '', '', '', '', '', '9674577058', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674577058', '9674577058', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(756, 1, '', '', 'MAUKH QUAISHI', '2005-07-24', '', 'FEMALE', '', '', '', '', '', '', '10', '1223', '1223', '', '', '', 'MD AFSA FATEHPUI', '', 'FAZANA BEGUM', '', '36/1E/1K, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '9903652307', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903652307', '9903652307', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(757, 1, '', '', 'MEHVISH MUKHLESIN', '2007-08-14', '', 'FEMALE', '', '', '', '', '', '', '10', '674', '674', '', '', '', 'MD MUKHLESIN', '', 'NESA FATMA', '', '15, SHAMSUL HUDA OAD, KOL-17', '', '', '', '', '', '9831058909', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831058909', '9831058909', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(758, 1, '', '', 'MUSAAT IMAM', '2007-08-13', '', 'FEMALE', '', '', '', '', '', '', '10', '608', '608', '', '', '', 'MAZHA IMAM', '', 'SABINA KHATOON', '', '4, TOPSIA OAD KOL - 39', '', '', '', '', '', '9331290602', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331290602', '9331290602', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(759, 1, '', '', 'SABA ALI', '2008-02-09', '', 'FEMALE', '', '', '', '', '', '', '10', '588', '588', '', '', '', 'SABI ALI', '', 'NASIMA ALI', '', '29/A/H/37, PALM AVENUE, KOL-19', '', '', '', '', '', '9748776386', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748776386', '9748776386', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(760, 1, '', '', 'SHEKHA SIDDIQUE', '2006-09-04', '', 'FEMALE', '', '', '', '', '', '', '10', '723', '723', '', '', '', 'SK.ISHAD ALI', '', 'NAZNEEN PAVEEN', '', '2/B/H/6 NAWAB ABDUL LATIF STEET KOLKATA - 16', '', '', '', '', '', '9748973786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748973786', '9748973786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(761, 1, '', '', 'SUKAINAH KHATOON', '2008-02-05', '', 'FEMALE', '', '', '', '', '', '', '10', '657', '657', '', '', '', 'HASMAT ALI KHAN', '', 'AFSAI KHANAM', '', '9/H, TOPSIA 2ND LANE, KOL-39', '', '', '', '', '', '8420471701', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420471701', '8420471701', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(762, 1, '', '', 'TAIBA KHATOON', '2007-09-10', '', 'FEMALE', '', '', '', '', '', '', '10', '680', '680', '', '', '', 'ABDUL HASIB', '', 'SABANA BEGUM', '', 'B8/3, AHIIPUKU 1ST LANE, KOL - 19', '', '', '', '', '', '9038224593', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038224593', '9038224593', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(763, 1, '', '', 'TASHHUD HUSSAIN', '2007-10-29', '', 'FEMALE', '', '', '', '', '', '', '10', '1209', '1209', '', '', '', 'MD.SAJID HUSSAIN  ', '', 'NOOJAHAN HUSSAIN', '', '148/A,CHITTEANJAN AVENUE KOL-7', '', '', '', '', '', '9339730982', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339730982', '9339730982', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(764, 1, '', '', 'TASMIA YASFEEN', '2006-12-14', '', 'FEMALE', '', '', '', '', '', '', '10', '630', '630', '', '', '', 'LATE MD. EHTESHA MUDDIN', '', 'GOZALA SHOUKAT', '', 'ASHIDA PALACE. IST FLOO 70E, TILJALA OAD, KOL-46', '', '', '', '', '', '8478905680', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8478905680', '8478905680', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(765, 1, '', '', 'ZAINAB PAVEEN', '2007-07-24', '', 'FEMALE', '', '', '', '', '', '', '10', '735', '735', '', '', '', 'AHMAT ALAM', '', 'WAJDA TABASUM', '', '64/H/10, BOAD STEET KOL-19', '', '', '', '', '', '8584929252', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8584929252', '8584929252', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(766, 1, '', '', 'ZOYA AHMED - 2', '2007-04-25', '', 'FEMALE', '', '', '', '', '', '', '10', '1050', '1050', '', '', '', 'ASHID AHMED  ', '', 'UKHSANA MUSTAFA', '', '3/1A,NIL MADHAB SEN LANE KOL-73', '', '', '', '', '', '9804225514', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9804225514', '9804225514', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(767, 1, '', '', 'ZOYA SHAH', '2007-07-14', '', 'FEMALE', '', '', '', '', '', '', '10', '656', '656', '', '', '', 'SHAH AUANZEB', '', 'AFAT BAI', '', '20/1/H/1, BIGHT STEET, KOL-17', '', '', '', '', '', '9339113236', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339113236', '9339113236', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(768, 1, '', '', 'SUFIYA', '2008-07-18', '', 'FEMALE', '', '', '', '', '', '', '10', '1703', '1703', '', '', '', 'SK SHAFIU AHMAN', '', 'MASMAD MAJEDA', '', 'VILL: BENUDIA. PO+PS. BHAGWANPU. DIST: PUBA MIDNAPU.', '', '', '', '', '', '7407203447', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7407203447', '7407203447', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(769, 1, '', '', 'N.M.MOHAMMED SHAIK FATHIMA', '2006-12-14', '', 'FEMALE', '', '', '', '', '', '', '10', '1706', '1706', '', '', '', 'MST NOO MOHAMMAD', '', 'S.I.AYSHA', '', '2, BIPLABI ANKUL CHANDA STEET, KOLKATA - 700072', '', '', '', '', '', '9830304078', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830304078', '9830304078', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(770, 1, '', '', 'AISHA KHATOON', '2007-03-10', '', 'FEMALE', '', '', '', '', '', '', '10', '1710', '1710', '', '', '', 'SK AFSA', '', 'AZIA BEGUM', '', '42E, TILJALA OAD, KOLKATA - 700046', '', '', '', '', '', '9903529200', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903529200', '9903529200', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(771, 1, '', '', 'THAMEENA ALI', '2007-08-28', '', 'FEMALE', '', '', '', '', '', '', '10', '1081', '1081', '', '', '', 'MD.MOHIUDDIN  ', '', 'SHAHINA M.UDDIN', '', '29/7A,GII BABU LANE K0L-12', '', '', '', '', '', '8584918144', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8584918144', '8584918144', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(772, 1, '', '', 'AAQUIB ABA', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '10', '855', '855', '', '', '', 'MD ABA ALAM', '', 'ISHAT ABA', '', '9, G J KHAN OAD, KOL - 39', '', '', '', '', '', '9163986744', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163986744', '9163986744', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(773, 1, '', '', 'AATIF FAIYAZ', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '10', '903', '903', '', '', '', 'FAIYAZ ALAM', '', 'NOOUS SABA', '', '5 MADA TALLA LANE, PILKHANA, HOWAH - 711101', '', '', '', '', '', '8017608101', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8017608101', '8017608101', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(774, 1, '', '', 'ABDUL BAI JILANI', '2007-05-27', '', 'MALE', '', '', '', '', '', '', '10', '882', '882', '', '', '', 'ABDU UB JILANI', '', 'BABBY TABASSUM', '', '83/E,1B,H/31 BELGACHIAA OAD KOL-37', '', '', '', '', '', '9831181935', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831181935', '9831181935', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(775, 1, '', '', 'ALHAMD NIAZI', '2007-05-18', '', 'MALE', '', '', '', '', '', '', '10', '664', '664', '', '', '', 'MD NADIM NIAZI', '', 'NASIMA NIAZI', '', '29H/18, LINTON STEET, KOL - 14', '', '', '', '', '', '9883012917', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883012917', '9883012917', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(776, 1, '', '', 'ANIS KHAN', '2007-03-08', '', 'MALE', '', '', '', '', '', '', '10', '614', '614', '', '', '', 'FEOZ KHAN', '', 'NAZMA KHAN', '', '22/2F, BIGHT STEET, KOL - 17', '', '', '', '', '', '8777518056', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8777518056', '8777518056', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(777, 1, '', '', 'AQIB ANWA', '2008-01-06', '', 'MALE', '', '', '', '', '', '', '10', '559', '559', '', '', '', 'ANWA KHAN', '', 'Feozi KHAN', '', '37,TOPSIA OAD SANSA APATMENT  KOL-39', '', '', '', '', '', '9831334721', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831334721', '9831334721', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(778, 1, '', '', 'ASHAN AHMED', '2007-10-02', '', 'MALE', '', '', '', '', '', '', '10', '1069', '1069', '', '', '', 'OWAID AHMED  ', '', 'BILQEES FATHMA', '', '70,ABINDA SAANI KOL-73', '', '', '', '', '', '8582939910', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8582939910', '8582939910', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(779, 1, '', '', 'ASHIM JAMAL', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '10', '872', '872', '', '', '', 'JAMAL AKHTA', '', 'NOO FATIMA', '', '62,D MISBAHUL COMPLEX BLOCK A TOPSIA OAD KOLKATA - 39', '', '', '', '', '', '8420847023', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420847023', '8420847023', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(780, 1, '', '', 'AZHAN HUSSAIN', '2007-02-23', '', 'MALE', '', '', '', '', '', '', '10', '704', '704', '', '', '', 'ALTAF HUSSAIN', '', 'SHUBI', '', '30/C, TILJALA MASJID BAI LANE KOL - 39', '', '', '', '', '', '9875567165', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9875567165', '9875567165', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(781, 1, '', '', 'FAHAD IQBAL', '2007-07-23', '', 'MALE', '', '', '', '', '', '', '10', '668', '668', '', '', '', 'SYED MD IQBAL', '', 'NAHID IQBAL', '', '15/F, TOPSIA OAD, KOL - 39', '', '', '', '', '', '8420941660', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420941660', '8420941660', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(782, 1, '', '', 'FAISAL IFAN ', '2007-11-02', '', 'MALE', '', '', '', '', '', '', '10', '734', '734', '', '', '', 'MD IFAN ALAM', '', 'WAJDAH TABASUM', '', '22/H/5, BIGHT STEET, KOL-17', '', '', '', '', '', '9831537310', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831537310', '9831537310', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(783, 1, '', '', 'IQBAL JAVED', '2007-02-12', '', 'MALE', '', '', '', '', '', '', '10', '809', '809', '', '', '', 'JAVED NEHAL', '', 'AABEDA KHATOON', '', '15, PEMANTLE STEET, KOL - 16', '', '', '', '', '', '9836651346', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836651346', '9836651346', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(784, 1, '', '', 'MAHAD EIJAZ', '2007-07-21', '', 'MALE', '', '', '', '', '', '', '10', '693', '693', '', '', '', 'EIJAZ MOIN', '', 'BUSHA EIJAZ', '', '2E, DILKUSHA STEET, KOL - 17', '', '', '', '', '', '9903986551', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903986551', '9903986551', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(785, 1, '', '', 'MD ABU BAKA SIDDIQUE', '2008-03-17', '', 'MALE', '', '', '', '', '', '', '10', '597', '597', '', '', '', 'ABDUL KADE', '', 'TABASSUM KADE', '', '30/3B MIAJAN OSTAGA LANE - KOL- 17', '', '', '', '', '', '8582907341', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8582907341', '8582907341', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(786, 1, '', '', 'MD JUNAID', '2007-12-11', '', 'MALE', '', '', '', '', '', '', '10', '612', '612', '', '', '', 'MD AKAM', '', 'SHAGUFTA ZIA', '', '14, KIMBE STEET, KOL - 17', '', '', '', '', '', '9883261052', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883261052', '9883261052', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(787, 1, '', '', 'MD MEHFOOZ ANJUM', '2006-09-11', '', 'MALE', '', '', '', '', '', '', '10', '682', '682', '', '', '', 'MANSOO ANJUM', '', 'FAISA MANSOO', '', '98, ELLIOT OAD, KOL - 16', '', '', '', '', '', '9874544865', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874544865', '9874544865', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(788, 1, '', '', 'MD MUSA KHAN', '2006-09-20', '', 'MALE', '', '', '', '', '', '', '10', '572', '572', '', '', '', 'MD AFSA KHAN', '', 'UMANA KHATOON', '', '12/2A, PALM AVENUE,  KOL - 19', '', '', '', '', '', '9830250300', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830250300', '9830250300', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(789, 1, '', '', 'MD MUSTAFA', '2007-04-01', '', 'MALE', '', '', '', '', '', '', '10', '1153', '1153', '', '', '', 'MD.SHAMSHAD  ', '', 'GUIA BEGUM', '', '33,HAIN BAI LANE KOL-73', '', '', '', '', '', '9831788152', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831788152', '9831788152', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(790, 1, '', '', 'MD AEES              ', '2007-05-29', '', 'MALE', '', '', '', '', '', '', '10', '1112', '1112', '', '', '', 'MD DILSHAD', '', 'FAJANA BEGAM', '', '12,HAIN BAI LANE KOL-73', '', '', '', '', '', '9830408858', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830408858', '9830408858', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(791, 1, '', '', 'MD AYYAN', '2007-08-16', '', 'MALE', '', '', '', '', '', '', '10', '759', '759', '', '', '', 'MD MANAWA ', '', 'DAAKSHAN SHAMAEL', '', '41C/H/12, JANNAGA OAD, KOL - 17', '', '', '', '', '', '9748159026', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748159026', '9748159026', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(792, 1, '', '', 'MD SHABAN UDDIN', '2007-08-13', '', 'MALE', '', '', '', '', '', '', '10', '691', '691', '', '', '', 'MD IAZUDDIN', '', 'NAGMA BEGAM', '', '20, TILJALA LANE, KOL - 19', '', '', '', '', '', '9883510576', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883510576', '9883510576', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(793, 1, '', '', 'MD SHADAB ALAM ', '2007-05-18', '', 'MALE', '', '', '', '', '', '', '10', '19', '19', '', '', '', 'MD. SOHAB ALAM ', '', ' NASEEN BANO ', '', 'BILAL COMPLEX. 26, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9883219255', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883219255', '9883219255', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(794, 1, '', '', 'MD SHAQEEB', '2006-08-29', '', 'MALE', '', '', '', '', '', '', '10', '1159', '1159', '', '', '', 'MD SAYEED', '', 'ANISA SAYEED', '', '70,ABINDA SAANI KOL-73', '', '', '', '', '', '9330107532', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330107532', '9330107532', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(795, 1, '', '', 'MD SHAYAN', '2007-09-05', '', 'MALE', '', '', '', '', '', '', '10', '649', '649', '', '', '', 'AFOZ AHMED', '', 'TAHMINA KHATOON', '', '35/ 1K TOPSIA OAD KOLKATA - 700039', '', '', '', '', '', '9836262547', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836262547', '9836262547', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(796, 1, '', '', 'MD UDAIN', '2007-09-24', '', 'MALE', '', '', '', '', '', '', '10', '722', '722', '', '', '', 'MD NADEEM', '', 'ZAINA KHATOON', '', '15, LOWE ANGE,KOL-17', '', '', '', '', '', '8420010093', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420010093', '8420010093', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(797, 1, '', '', 'MD ZAID', '2007-12-09', '', 'MALE', '', '', '', '', '', '', '10', '648', '648', '', '', '', 'SHAMIM AKHTA QUAISHI', '', 'SABA SHABNAM', '', '38A, KABITITHA SAANI , KOL - 23', '', '', '', '', '', '9831605207', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831605207', '9831605207', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(798, 1, '', '', 'MOHD ISMAIL', '2008-02-25', '', 'MALE', '', '', '', '', '', '', '10', '705', '705', '', '', '', 'NIYAZ AHMED', '', 'SABIA ISHAT', '', '118, ELLIOT OAD,  KOL - 16', '', '', '', '', '', '9903186344', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903186344', '9903186344', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(799, 1, '', '', 'MOHSIN KHAMIL', '2006-11-20', '', 'MALE', '', '', '', '', '', '', '10', '717', '717', '', '', '', 'NOOGU SULAIMAN ', '', 'ALIA SULAIMAN', '', '1,MANDI STEET KOL-73', '', '', '', '', '', '9836708616', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836708616', '9836708616', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(800, 1, '', '', 'MOZAMMIL HOSSAIN', '2007-09-18', '', 'MALE', '', '', '', '', '', '', '10', '609', '609', '', '', '', 'SHAFKAT HOSSAIN', '', 'ZAIN AHMAN', '', '2E, TILJALA LANE, KOL - 19 (GEEN PAK)', '', '', '', '', '', '8100581313', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100581313', '8100581313', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(801, 1, '', '', 'IZWANULLAH', '2006-12-29', '', 'MALE', '', '', '', '', '', '', '10', '718', '718', '', '', '', 'MD SAMI ALAM', '', 'ZAEEN KHATOON', '', '46H/9, SHAMSUL HUDA OAD, KOL - 17', '', '', '', '', '', '9007491835', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007491835', '9007491835', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(802, 1, '', '', 'SHABBI AHMED', '2007-05-26', '', 'MALE', '', '', '', '', '', '', '10', '697', '697', '', '', '', 'ZAHI AHMED', '', 'KHUSHBU BEGUM', '', '10, SAPGANCHI 1ST LANE, KOL - 39', '', '', '', '', '', '8420471621', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420471621', '8420471621', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(803, 1, '', '', 'SHAJA HAYAT', '2007-09-14', '', 'MALE', '', '', '', '', '', '', '10', '841', '841', '', '', '', 'MOZAMMIL HAYAT', '', 'ANI SHAHEEN', '', '36/1E/1K, TOPSIA OAD, UTTA PANCHANAGAM, KOL - 39', '', '', '', '', '', '8910886393', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8910886393', '8910886393', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(804, 1, '', '', 'SHAIM OMAN', '2007-08-30', '', 'MALE', '', '', '', '', '', '', '10', '578', '578', '', '', '', 'MAHFOOZ ALAM', '', 'MOSAUWA IZWANA', '', '36/1E/1K/1 TOPSIA OAD KOLKATA - 39', '', '', '', '', '', '9831360418', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831360418', '9831360418', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(805, 1, '', '', 'SIDDIKUL AMIN', '2007-02-03', '', 'MALE', '', '', '', '', '', '', '10', '634', '634', '', '', '', 'SK. SHALHIN', '', 'EHANA BEGUM', '', '47/A, SHAMSUL HUDA OAD, KOL - 17', '', '', '', '', '', '9163187124', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163187124', '9163187124', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(806, 1, '', '', 'SK. EHAN EZA', '2004-12-05', '', 'MALE', '', '', '', '', '', '', '10', '660', '660', '', '', '', 'SK SALIM', '', 'SEEMA ASGHA', '', '3/H/14, JHOWTALA LANE, KOLKATA - 17', '', '', '', '', '', '9883369130', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883369130', '9883369130', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(807, 1, '', '', 'SYED ABID JAMIL', '2007-07-08', '', 'MALE', '', '', '', '', '', '', '10', '616', '616', '', '', '', 'ISHTEYAQUE ALAM', '', 'SAMEEA WALI', '', '4 B OYD LANE KOLKATA-16', '', '', '', '', '', '8100013177', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100013177', '8100013177', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(808, 1, '', '', 'SYED MOHAMMAD ADEEL QUADI', '2008-06-19', '', 'MALE', '', '', '', '', '', '', '10', '815', '815', '', '', '', 'SYED MOHAMMAD  QUADI', '', 'SYEDA SHAZMA QUADI', '', '3, TILJALA LANE, GEEN PAK, KOL - 19', '', '', '', '', '', '9830613404', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830613404', '9830613404', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(809, 1, '', '', 'MD JUNAID NASI', '2007-09-03', '', 'MALE', '', '', '', '', '', '', '10', '1652', '1652', '', '', '', 'MD NASI', '', 'TAHIA PAVEEN', '', '33/H/5, DENT MISSION OAD, KOLKATA - 700023', '', '', '', '', '', '9831784477', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831784477', '9831784477', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(810, 1, '', '', 'ZAID AHMED', '2007-08-04', '', 'MALE', '', '', '', '', '', '', '10', '643', '643', '', '', '', 'JAWED AKHTE', '', 'HUMA KAUSE', '', '11/1B, BECHU LAL OAD,  KOL - 14', '', '', '', '', '', '8013568251', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8013568251', '8013568251', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(811, 1, '', '', 'MD ZAKI QUAISHI', '2007-06-01', '', 'MALE', '', '', '', '', '', '', '10', '1220', '1220', '', '', '', 'MD.SEAJUDDIN QUAISHI  ', '', 'AFOZ SEAJ', '', '33,PHEAS LANE KOL-73', '', '', '', '', '', '9830779996', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830779996', '9830779996', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(812, 1, '', '', 'MD SHAYAN UDDIN', '2007-09-17', '', 'MALE', '', '', '', '', '', '', '10', '1556', '1556', '', '', '', 'MD SHAHABUDDIN', '', 'ZEENAT SHAUKAT ANSAI', '', '2B/H/41, D, M.N. CHATTEJEE SAANI - KOL - 700009', '', '', '', '', '', '8582816489', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8582816489', '8582816489', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(813, 1, '', '', 'AENA  AKHTA', '2006-02-07', '', 'FEMALE', '', '', '', '', '', '', '11', '139', '139', '', '', '', 'JAMIL AKHTE ', '', 'SHIEEN JAMIL', '', 'B29/H/1A,PALM AVENUE KOL-19', '', '', '', '', '', '9831750331', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831750331', '9831750331', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(814, 1, '', '', 'AFIFAH KHAN', '2006-12-13', '', 'FEMALE', '', '', '', '', '', '', '11', '754', '754', '', '', '', 'MOHIUDDIN AHMED KHAN', '', 'AYESHA AHMAN KHAN', '', '12/D,SHAMSUL HUDA OAD KOL - 17', '', '', '', '', '', '9230021137', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9230021137', '9230021137', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(815, 1, '', '', 'AFEEN JAHAN', '2006-06-27', '', 'FEMALE', '', '', '', '', '', '', '11', '558', '558', '', '', '', 'MD FAIYAZ', '', 'AUNAQUE BEGUM', '', '6/B TILJALA SHIBTALA LANE KOLKATA-39', '', '', '', '', '', '8981595174', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8981595174', '8981595174', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(816, 1, '', '', 'AFSANA PAVEEN ', '2007-03-14', '', 'FEMALE', '', '', '', '', '', '', '11', '439', '439', '', '', '', 'MD. NASI ', '', ' MUSAAT PAVEEN ', '', '3/3D/1 MOULANA ABUL KALAM AZAD SAANI ', '', '', '', '', '', '9062524710', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062524710', '9062524710', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(817, 1, '', '', 'AL-AFIA PAWEEN', '2006-11-28', '', 'FEMALE', '', '', '', '', '', '', '11', '801', '801', '', '', '', 'MD ZAFULLAH', '', 'NOO JAHAN', '', '6A, G J KHAN OAD, KOL - 39', '', '', '', '', '', '7044640996', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7044640996', '7044640996', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(818, 1, '', '', 'ALAIKA ESHAD', '2005-06-13', '', 'FEMALE', '', '', '', '', '', '', '11', '810', '810', '', '', '', 'MD ISHAD ALAM', '', 'SIAT ALAM', '', '41/H/1, G J KHAN OAD, KOL - 39', '', '', '', '', '', '9007549631', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007549631', '9007549631', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(819, 1, '', '', 'ALIA IMTIAZ', '2006-12-15', '', 'FEMALE', '', '', '', '', '', '', '11', '407', '407', '', '', '', 'IMTIAZ AHMED ', '', ' SADAF AHMED', '', '15. SI SYED AHMED OAD KOL 14', '', '', '', '', '', '9007930567', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007930567', '9007930567', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(820, 1, '', '', 'AIBA FIDAUS', '2006-09-24', '', 'FEMALE', '', '', '', '', '', '', '11', '150', '150', '', '', '', 'FIDAUS AGHIB ', '', ' FATMA SHAMIN', '', '26B D.SUESH SAKA OAD KOLKATA-14', '', '', '', '', '', '9674047425', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674047425', '9674047425', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(821, 1, '', '', 'ASFIA SHAHNAWAZ', '2007-01-10', '', 'FEMALE', '', '', '', '', '', '', '11', '571', '571', '', '', '', 'MD SHAHNAWAZ', '', 'ZEENAT BEGUM', '', '51/A, SHAMSUL HUDA OAD KOL - 17', '', '', '', '', '', '9748725948', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748725948', '9748725948', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(822, 1, '', '', 'BUSHA SHAMS ', '2006-08-23', '', 'FEMALE', '', '', '', '', '', '', '11', '36', '36', '', '', '', 'MD. SHAMSUDDIN ', '', ' AZIA BEGUM ', '', '37/8/E WATGUNGE STEET KOL 23', '', '', '', '', '', '9903482692', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903482692', '9903482692', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(823, 1, '', '', 'DAAKSHA HUMAYUN', '2005-12-19', '', 'FEMALE', '', '', '', '', '', '', '11', '1234', '1234', '', '', '', 'MD HUMAYUN', '', 'SAYEEDA PAVEEN', '', '16/H/4 BECKBAGAN OW KOL-17', '', '', '', '', '', '8981474386', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8981474386', '8981474386', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(824, 1, '', '', 'FALAK SABA ALAM', '2006-10-12', '', 'FEMALE', '', '', '', '', '', '', '11', '724', '724', '', '', '', 'MD SADE ALAM', '', 'SABANA KHATOON', '', '121 , ABINDA SAANI KOLKATA , 700073', '', '', '', '', '', '9748099786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748099786', '9748099786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(825, 1, '', '', 'FATIMA ALI FIDAUS', '2006-09-16', '', 'FEMALE', '', '', '', '', '', '', '11', '175', '175', '', '', '', 'TAHE ALI ', '', ' ZINAT BEGUM', '', '3,MIAJAN OSTAGA LANE KOL-17', '', '', '', '', '', '9339995156', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339995156', '9339995156', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(826, 1, '', '', 'FATIMA BINT SHAHNAWAZ', '2007-01-28', '', 'FEMALE', '', '', '', '', '', '', '11', '221', '221', '', '', '', 'SHAHNAWAZ ALI AHMED AI ', '', ' ADA SHAYESTA SUBBOH', '', '30/B CANTOPHE LANE KOL 14', '', '', '', '', '', '8961102599', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8961102599', '8961102599', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(827, 1, '', '', 'HIBA BANO', '2006-01-09', '', 'FEMALE', '', '', '', '', '', '', '11', '1248', '1248', '', '', '', 'MUKTASHID HASHIM', '', 'AKIYA BANO', '', '2B, D BIESH GUHA STEET KOL-17', '', '', '', '', '', '9903321170', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903321170', '9903321170', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(828, 1, '', '', 'HUIA HABIBA', '2006-06-08', '', 'FEMALE', '', '', '', '', '', '', '11', '568', '568', '', '', '', 'MD ALAM', '', 'AHMEDI BEGUM', '', '41/A/H/6, JANNAGA OAD, KOL - 17', '', '', '', '', '', '9831712073', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831712073', '9831712073', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(829, 1, '', '', 'JANNATUL FIDAUSI', '2005-10-07', '', 'FEMALE', '', '', '', '', '', '', '11', '741', '741', '', '', '', 'JIAAT HOSSEN MOLLA', '', 'SAIYADA PHATEMA BIBI', '', '11/C MCLEOD STEET KOLKATA - 17', '', '', '', '', '', '9831330244', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831330244', '9831330244', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(830, 1, '', '', 'KONAIN FATMA', '2007-02-01', '', 'FEMALE', '', '', '', '', '', '', '11', '675', '675', '', '', '', 'KHAIUL SHAMS', '', 'SAJDA SHAMS', '', '2/C/H/8, CHATU BABU LANE, KOL - 14', '', '', '', '', '', '9681880303', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681880303', '9681880303', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(831, 1, '', '', 'LAAIB DAULAT WASI', '2006-09-06', '', 'FEMALE', '', '', '', '', '', '', '11', '824', '824', '', '', '', 'DAULAT AZA ', '', 'TAANNUM JAHAN', '', '13/2H/1, PATWA BAGAN LANE, KOL - 9', '', '', '', '', '', '9038503865', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038503865', '9038503865', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(832, 1, '', '', 'MALIKA KHAN ', '2004-10-21', '', 'FEMALE', '', '', '', '', '', '', '11', '523', '523', '', '', '', 'AMJAN KHAN ', '', ' AIFA KHAN ', '', '45/1C OLD BALLYGUNGE 1ST LANE KOL. 19', '', '', '', '', '', '9830044862', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830044862', '9830044862', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(833, 1, '', '', 'MODINA KHAN ', '2006-08-15', '', 'FEMALE', '', '', '', '', '', '', '11', '522', '522', '', '', '', 'AMJAN KHAN ', '', ' AIFA KHAN ', '', '45/1C OLD BALLYGUNGE 1ST LANE KOL. 19', '', '', '', '', '', '9830044862', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830044862', '9830044862', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(834, 1, '', '', 'MUNAZA IMAN', '2006-11-10', '', 'FEMALE', '', '', '', '', '', '', '11', '637', '637', '', '', '', 'MD IMAN', '', 'AFIN NISSA', '', '3/H/6, JHOWTALA LANE, KOL-17', '', '', '', '', '', '8017784301', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8017784301', '8017784301', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(835, 1, '', '', 'NIKHAT SHAFIQUE', '2006-09-14', '', 'FEMALE', '', '', '', '', '', '', '11', '435', '435', '', '', '', 'SHAFIQULLAH ', '', ' FAHAT JABEEN', '', '70 C/H/2  TILJALA OAD KOL 46', '', '', '', '', '', '9681061971', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681061971', '9681061971', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(836, 1, '', '', 'NOO FATMA AZAM', '2006-11-25', '', 'FEMALE', '', '', '', '', '', '', '11', '105', '105', '', '', '', 'SHAMIM AZAM ', '', ' MUSAAT AZAM', '', '2/A,ADHA GOBINDA SAHA LANE KOL-17', '', '', '', '', '', '9748125166', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748125166', '9748125166', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(837, 1, '', '', 'ABIA BISE', '2006-03-04', '', 'FEMALE', '', '', '', '', '', '', '11', '174', '174', '', '', '', 'MD SAOJ ALAM ', '', ' SAHA SAOJ', '', '64/H/8, BOAD STEET KOL-19', '', '', '', '', '', '9331042515', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331042515', '9331042515', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(838, 1, '', '', 'AFIA KHATOON', '2006-01-06', '', 'FEMALE', '', '', '', '', '', '', '11', '83', '83', '', '', '', 'MAHMOOD ALAM ', '', ' ASGHAI BEGUM', '', '7,BIBI BAGAN LANE KOL 15', '', '', '', '', '', '9831160097', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831160097', '9831160097', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(839, 1, '', '', 'AUNAK ALAM ', '2006-10-28', '', 'FEMALE', '', '', '', '', '', '', '11', '520', '520', '', '', '', 'MD. MAQSUD ALAM ', '', ' AUSHAN AA ', '', '13D, KOMEDAN BAGAN LANE KOL 16', '', '', '', '', '', '9339470242', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339470242', '9339470242', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(840, 1, '', '', 'SAAA ZAKI', '2007-01-20', '', 'FEMALE', '', '', '', '', '', '', '11', '817', '817', '', '', '', 'ZAKI HOSSAIN', '', 'SEEMA ZAFA', '', '70/H/1, D. SUDHI BOSE OAD, KOL-23', '', '', '', '', '', '9831334604', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831334604', '9831334604', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(841, 1, '', '', 'SANIA SHAFIQUE', '2005-07-23', '', 'FEMALE', '', '', '', '', '', '', '11', '145', '145', '', '', '', 'MD SHAFIQUE ', '', ' PAVEEN AHMAN', '', '46H/10,SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '704466600', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '704466600', '704466600', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(842, 1, '', '', 'SYEDA FATIMA NAWAB', '2006-10-15', '', 'FEMALE', '', '', '', '', '', '', '11', '361', '361', '', '', '', 'SYED NAWABUDDIN ', '', ' SHAGUFTA HASSAN', '', '7F,NAWAB ABDUL LATIF LANE KOL-16', '', '', '', '', '', '9831678819', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831678819', '9831678819', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(843, 1, '', '', 'TAUBAH SHEEEN', '1970-01-01', '', 'FEMALE', '', '', '', '', '', '', '11', '540', '540', '', '', '', 'ABDUL BASIT', '', 'NUSAT JAHAN', '', '29/3/a/1 gholam hussain sada lane howah - 02', '', '', '', '', '', '9681782005', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681782005', '9681782005', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(844, 1, '', '', 'ZOHA NAJIA ISMAIL', '2006-09-14', '', 'FEMALE', '', '', '', '', '', '', '11', '461', '461', '', '', '', 'MD.ANWAUS SAYEED ISMAIL', '', ' SADIA MAIAM', '', '4,JANNAGA OAD KOL-14', '', '', '', '', '', '9831387525', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831387525', '9831387525', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(845, 1, '', '', 'MAYAM HUSSAIN', '2006-11-02', '', 'FEMALE', '', '', '', '', '', '', '11', '692', '692', '', '', '', 'MD SAHID HUSSAIN', '', 'NASAT PAVEEN', '', '75/1C, TOPSIA OAD, KOL - 39( 65A, COLOTOLA STEET,  KOL-73', '', '', '', '', '', '7890626284', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7890626284', '7890626284', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(846, 1, '', '', 'AFFAN ALI', '2007-10-08', '', 'MALE', '', '', '', '', '', '', '11', '847', '847', '', '', '', 'ASHAD ALI', '', 'SHAMA BEGUM', '', '83D/H/1, BELGACHIA OAD, KOL - 37', '', '', '', '', '', '9007477266', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007477266', '9007477266', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(847, 1, '', '', 'ALI- AL - HOSSAIN', '2007-04-27', '', 'MALE', '', '', '', '', '', '', '11', '262', '262', '', '', '', 'ASHAF HOSSAIN ', '', ' NASEEM ASHAF', '', '6/10 KUSTIA OAD KOL 39', '', '', '', '', '', '9007992871', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007992871', '9007992871', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(848, 1, '', '', 'ALTAMASH HUSSAIN ', '2007-02-16', '', 'MALE', '', '', '', '', '', '', '11', '26', '26', '', '', '', 'AKHTA HUSSAIN ', '', 'SHAMIMA BEGUM', '', '14/H/19 BIBI BAGAN LANE KOL 15', '', '', '', '', '', '9339849911', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339849911', '9339849911', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(849, 1, '', '', 'AMI HUMZA', '2005-12-20', '', 'MALE', '', '', '', '', '', '', '11', '189', '189', '', '', '', 'MD. ASHAD ', '', ' MUZAMIL JAN ', '', '69, AINDA SAANI 3D FLOO KOL- 73', '', '', '', '', '', '9231947442', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9231947442', '9231947442', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(850, 1, '', '', 'FAZEEL AHMED', '2006-12-30', '', 'MALE', '', '', '', '', '', '', '11', '271', '271', '', '', '', 'FAIZ AHMED ', '', ' ZAKIA AHMED', '', '34 TALTALA LANE KOLKATA - 16', '', '', '', '', '', '9874037790', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874037790', '9874037790', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(851, 1, '', '', 'ATIF JAMEEL', '2007-03-04', '', 'MALE', '', '', '', '', '', '', '11', '302', '302', '', '', '', 'JAMEEL AHMED ', '', ' SHAGUFTA PEVEEN', '', '84/9 IPPON STEET KOL 16 / 71/ 2 TOPSIA OAD KOLKATA - 39', '', '', '', '', '', '9748531840', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748531840', '9748531840', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(852, 1, '', '', 'MD ALI HASNAIN ', '2006-09-26', '', 'MALE', '', '', '', '', '', '', '11', '274', '274', '', '', '', 'MD.SONU HASNAIN ', '', ' MUSAAT HASNAIN', '', '6/14/H/8,NILMONI HALDE LANE KOL-13', '', '', '', '', '', '9830156036', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830156036', '9830156036', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(853, 1, '', '', 'MD AMI', '-0001-11-30', '', 'MALE', '', '', '', '', '', '', '11', '883', '883', '', '', '', 'MOHAMMAD KHALIL', '', 'NOO JAHAN KHATOON', '', '62 TOPSIA OAD KOLKATA .39', '', '', '', '', '', '9007279445', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007279445', '9007279445', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(854, 1, '', '', 'MD AEESH', '2006-07-26', '', 'MALE', '', '', '', '', '', '', '11', '166', '166', '', '', '', 'MD. SHAHNAWAZ', '', 'SHABNAM PAVEEN', '', '10 WALIULLAH LANE KOL 16', '', '', '', '', '', '8420863056', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420863056', '8420863056', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(855, 1, '', '', 'MD AYAZ ALI', '2006-01-03', '', 'MALE', '', '', '', '', '', '', '11', '590', '590', '', '', '', 'MD ASHAD ALI', '', 'SITAA KHATOON', '', '3/H/6, JHOWTALA LANE, KOL-17', '', '', '', '', '', '9831059468', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831059468', '9831059468', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(856, 1, '', '', 'MD HAMMAD ASHAD', '2007-07-18', '', 'MALE', '', '', '', '', '', '', '11', '1183', '1183', '', '', '', 'MD ASHAD  ', '', 'NASIN NAAZ', '', '29/H/32, LINTON STEET, KOLKATA - 14', '', '', '', '', '', '9831139230', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831139230', '9831139230', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(857, 1, '', '', 'MD HAIS', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '11', '885', '885', '', '', '', 'MD.JAWED', '', 'FAHAT KHATOON', '', '18,D KUSTIA MASJID BAI LANE KOLKATA-39', '', '', '', '', '', '8981196443', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8981196443', '8981196443', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(858, 1, '', '', 'MD HOSSAIN KHAN', '2006-01-22', '', 'MALE', '', '', '', '', '', '', '11', '1553', '1553', '', '', '', 'MD SALIM KHAN', '', 'HALIMA KHATOON', '', '6/1 SEANG LANE - KOLKATA - 700014', '', '', '', '', '', '9836443766', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836443766', '9836443766', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(859, 1, '', '', 'MD KASHIF QAMA', '2006-05-30', '', 'MALE', '', '', '', '', '', '', '11', '696', '696', '', '', '', 'MD QAMA', '', 'MEHNAAZ BEGUM', '', '66/1B, BIGHT STEET,KOL-19', '', '', '', '', '', '9339757701', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339757701', '9339757701', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(860, 1, '', '', 'MD NAFISH ALI', '2007-03-13', '', 'MALE', '', '', '', '', '', '', '11', '237', '237', '', '', '', 'MD.NAZIM ', '', ' ISHAT BEGUM', '', '61,TOPSIA OAD KOLKATA 700039/ 11/D TOPSIA 2ND LANE', '', '', '', '', '', '9088205667', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9088205667', '9088205667', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(861, 1, '', '', 'MD SAHIL', '2006-02-02', '', 'MALE', '', '', '', '', '', '', '11', '196', '196', '', '', '', 'NAUSHAD AHMED ', '', 'NASHIMA KHATOON', '', '18/A KUSTIA MASJID BADI LANE KOL 39/ 10/C TILJALA SIBTLA LANE KOL-39', '', '', '', '', '', '9831755286', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831755286', '9831755286', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(862, 1, '', '', 'MD SHAVEEZ JAHANGI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '11', '957', '957', '', '', '', 'MD. SAFAAZ JAHANGI', '', 'AFEEN JAHANGI', '', 'I - 181, PAHAPU OAD, 3d FLOO, KOLKATA - 700024', '', '', '', '', '', '8420870801', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420870801', '8420870801', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(863, 1, '', '', 'MD YASIN KHAN', '2006-06-06', '', 'MALE', '', '', '', '', '', '', '11', '87', '87', '', '', '', 'MD NAYEEM ', '', ' WAHIDA KHATOON', '', '22, KABITITA SAANI KOL.-23 ', '', '', '', '', '', '8240481044', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240481044', '8240481044', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(864, 1, '', '', 'MD ZOHAIB', '2006-02-08', '', 'MALE', '', '', '', '', '', '', '11', '266', '266', '', '', '', 'MD ASIF ', '', 'UBINA BANO ', '', '112C TOPSIA OAD KOL 39 ', '', '', '', '', '', '9883716343', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883716343', '9883716343', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(865, 1, '', '', 'MD. ALI', '2005-09-25', '', 'MALE', '', '', '', '', '', '', '11', '1243', '1243', '', '', '', 'MD. KASIF', '', 'WAHIDEN NISHA', '', '100/H/7, DILKUSHA STEET, PAK CICUS, KOLKATA - 700017', '', '', '', '', '', '8017326551', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8017326551', '8017326551', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(866, 1, '', '', 'MOHAMMAD ABAN SHABANDI', '2005-11-04', '', 'MALE', '', '', '', '', '', '', '11', '111', '111', '', '', '', 'ASIM ABU BAKE ', '', ' SHAZIA ASIM ', '', '100A, ABINDA SAANI KOL-73', '', '', '', '', '', '8584893980', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8584893980', '8584893980', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(867, 1, '', '', 'MOHAMMAD SUFYAAN', '2006-05-09', '', 'MALE', '', '', '', '', '', '', '11', '765', '765', '', '', '', 'HAJI MD MOKIM', '', 'IZWANA BEGUM', '', '16,A BIGHT ST. KOLKATA - 17', '', '', '', '', '', '9831196592', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831196592', '9831196592', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(868, 1, '', '', 'MOHAMMAD YOUSUF SHOAIB', '2006-06-04', '', 'MALE', '', '', '', '', '', '', '11', '1', '1', '', '', '', 'SHOAIB ALAM ', '', ' SADIA AQUIL ', '', '24G, KUSTIA OAD KOL 39', '', '', '', '', '', '9007040023', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007040023', '9007040023', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(869, 1, '', '', 'MOHD ASAD IQBAL', '2006-10-09', '', 'MALE', '', '', '', '', '', '', '11', '16', '16', '', '', '', 'MD. IQBAL ', '', ' YASMIN IQBAL ', '', '40B IMDAD ALI LANE KOL 16', '', '', '', '', '', '9748807263', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748807263', '9748807263', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(870, 1, '', '', 'MUZAMMIL ALAM', '2004-09-01', '', 'MALE', '', '', '', '', '', '', '11', '82', '82', '', '', '', 'SK .MAHMOOD ALAM ', '', ' ASGAI ALAM', '', '7,BIBI BAGAN LANE KOL-15', '', '', '', '', '', '9831160097', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831160097', '9831160097', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(871, 1, '', '', 'NAJEEBULLAH KHAN', '2006-01-15', '', 'MALE', '', '', '', '', '', '', '11', '988', '988', '', '', '', 'NEK MOHAMED KHAN', '', 'MUMTAZ KHAN', '', '15D, KUSTIA MASJID BAI LANE, KOL - 39', '', '', '', '', '', '9830425226', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830425226', '9830425226', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(872, 1, '', '', 'SHADAB KHAN', '2005-08-25', '', 'MALE', '', '', '', '', '', '', '11', '811', '811', '', '', '', 'SANAULLAH KHAN', '', 'MEHNAZ BEGUM', '', '36/1E/1D, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9339993497', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339993497', '9339993497', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(873, 1, '', '', 'TAHA  QUAISHY', '2005-12-15', '', 'MALE', '', '', '', '', '', '', '11', '681', '681', '', '', '', 'ZAINUL ABEDIN', '', 'NAZIA ABEDIN', '', '1,D  BIESH GUHA STEET, KOL - 17', '', '', '', '', '', '8420469557', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420469557', '8420469557', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(874, 1, '', '', 'TAMZEED KAIM BAKSH', '2006-07-26', '', 'MALE', '', '', '', '', '', '', '11', '531', '531', '', '', '', 'MD. KAIM ', '', ' TAANNUM KAIM ', '', '7/2 K, ABINASH CHOWDHUY LANE KOL- 46', '', '', '', '', '', '8335960631', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8335960631', '8335960631', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(875, 1, '', '', 'TAUSIF KHAN', '1970-01-01', '', 'MALE', '', '', '', '', '', '', '11', '782', '782', '', '', '', 'YUNUS KHAN', '', 'SANNO BEGUM', '', '29/A, 34/H PALM AVENUE KOL.24', '', '', '', '', '', '8910972015', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8910972015', '8910972015', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(876, 1, '', '', 'ZEEYAAN SHAKIL', '2007-04-15', '', 'MALE', '', '', '', '', '', '', '11', '444', '444', '', '', '', 'SHAKEEL AHMED ', '', ' NUZHAT PAVEEN', '', '84/9,IPOON STEET KOL-16', '', '', '', '', '', '9339110997', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339110997', '9339110997', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(877, 1, '', '', 'MOHAMMED NAWAZ NAVIWALA', '2007-01-09', '', 'MALE', '', '', '', '', '', '', '11', '79', '79', '', '', '', 'FAISAL NAVIWALA ', '', ' MEENAIL NAVIWALA', '', '93B,IPON STEET KOL-16', '', '', '', '', '', '9339379705', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339379705', '9339379705', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(878, 1, '', '', 'ADEEBA JUNAID', '2006-10-09', '', 'FEMALE', '', '', '', '', '', '', '12', '613', '613', '', '', '', 'JUNAID ALAM', '', 'KAINAT JUNAID', '', '166/H/68,KESHAB CHANDA SEN STEET KOL-9', '', '', '', '', '', '9331824772', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331824772', '9331824772', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(879, 1, '', '', 'ADIBA HAQUE', '2005-10-03', '', 'FEMALE', '', '', '', '', '', '', '12', '837', '837', '', '', '', 'SAMSUL HAQUE', '', 'ESHMA KHATOON', '', '37/1/1 BIGHT STEET KOLKATA -17', '', '', '', '', '', '9831259903', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831259903', '9831259903', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(880, 1, '', '', 'ADIBA SHAKIL', '2006-05-24', '', 'FEMALE', '', '', '', '', '', '', '12', '254', '254', '', '', '', 'SHAKIL AHMED ', '', ' SABIHA AHMED', '', '24/19/A,STATION OAD TITAGAH KOL-119', '', '', '', '', '', '9093088849', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9093088849', '9093088849', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(881, 1, '', '', 'ALAFIA NAJAM', '2006-04-07', '', 'FEMALE', '', '', '', '', '', '', '12', '57', '57', '', '', '', 'KHUSHID EHAN ', '', ' EHANA SULTANA', '', '14B,J.K.LANE,KOLKATA-700019', '', '', '', '', '', '9007053979', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007053979', '9007053979', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(882, 1, '', '', 'AIFA BELAL', '2006-06-23', '', 'FEMALE', '', '', '', '', '', '', '12', '844', '844', '', '', '', 'BELAL ISHAT', '', 'SHAMA BANO', '', '3, ST GEOGES GATE OAD, GOVT QT NO:. A/16, HASTING, KOL - 22', '', '', '', '', '', '7278063160', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7278063160', '7278063160', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(883, 1, '', '', 'AYESHA IMAN', '2006-05-25', '', 'FEMALE', '', '', '', '', '', '', '12', '60', '60', '', '', '', 'MD IMAN ', '', 'A AZA BEGUM', '', '44C,SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '9836927701', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836927701', '9836927701', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(884, 1, '', '', 'FATIMA ZAHOO ', '2006-08-01', '', 'FEMALE', '', '', '', '', '', '', '12', '241', '241', '', '', '', 'ZAHOO AKHTE ', '', ' NUSAT  PAWEEN', '', '25C G J KHAN OAD KOL 39 ', '', '', '', '', '', '9331645910', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331645910', '9331645910', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(885, 1, '', '', 'HAADIYA AAFEEN', '2006-05-25', '', 'FEMALE', '', '', '', '', '', '', '12', '662', '662', '', '', '', 'ABDUL TAWAB', '', 'ZEENAT JAHAN', '', '46/H/9/1, SHAMSUL HUDA OAD, KOL - 17', '', '', '', '', '', '9883431919', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883431919', '9883431919', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(886, 1, '', '', 'HUAIA SEHI ANWA', '2007-02-21', '', 'FEMALE', '', '', '', '', '', '', '12', '188', '188', '', '', '', 'TAIQUE ANWA ', '', ' AMEEN ANWA', '', '3/H/11 ANJUMAN OAD KOL 14', '', '', '', '', '', '9831237819', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831237819', '9831237819', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(887, 1, '', '', 'IFAH AHMED', '2006-10-08', '', 'FEMALE', '', '', '', '', '', '', '12', '100', '100', '', '', '', 'ATIQUE AHMED ', '', ' QUDSIA ATIQUE', '', '94/2 COLLIN STEET KOL 16', '', '', '', '', '', '9831376731', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831376731', '9831376731', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(888, 1, '', '', 'INSHA HUSSAIN', '2006-06-29', '', 'FEMALE', '', '', '', '', '', '', '12', '267', '267', '', '', '', 'AKAM HUSSAIN ', '', ' SHAIQUA HUSSAIN', '', '5/3, GEEN PAK TILJALA LANE KOL-19 ', '', '', '', '', '', '7603099334', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7603099334', '7603099334', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(889, 1, '', '', 'IQA AQUIB', '2005-08-17', '', 'FEMALE', '', '', '', '', '', '', '12', '990', '990', '', '', '', 'MD AQUIB ALAM', '', 'AZU PEVEEN', '', '22A, C.N.OY OAD, TOPSIA, KOL-39', '', '', '', '', '', '8482038101', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8482038101', '8482038101', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(890, 1, '', '', 'JUWAIYA AAFEEN', '2006-05-25', '', 'FEMALE', '', '', '', '', '', '', '12', '663', '663', '', '', '', 'ABDUL TAWAB', '', 'ZEENAT JAHAN', '', '46/H/9/1, SHAMSUL HUDA OAD, KOL - 17', '', '', '', '', '', '9883431919', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883431919', '9883431919', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(891, 1, '', '', 'KANIZ FATMA', '2006-03-11', '', 'FEMALE', '', '', '', '', '', '', '12', '229', '229', '', '', '', 'SAMI AHMED ', '', ' DAKSHAN SULTANA', '', '26/12A,G.J.KHAN OAD KOL-39', '', '', '', '', '', '9903465142', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903465142', '9903465142', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(892, 1, '', '', 'LAIBA MEHABAN', '2006-10-26', '', 'FEMALE', '', '', '', '', '', '', '12', '830', '830', '', '', '', 'SK MD MEHABAN', '', 'NILOFU MEHABAN', '', '36/D, TOPSIA OAD (EAST), KOL - 39', '', '', '', '', '', '9883612602', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883612602', '9883612602', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(893, 1, '', '', 'MAHUKH SOHAB', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '12', '879', '879', '', '', '', 'SOHAB AHMED', '', 'OUNAQUE SOHAB', '', '32/12 ANI CHAAN GHOSH LANE KOL- 39', '', '', '', '', '', '9748072320', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748072320', '9748072320', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(894, 1, '', '', 'MANTASHA SOLANKI', '2007-02-02', '', 'FEMALE', '', '', '', '', '', '', '12', '786', '786', '', '', '', 'PAWAZE ALAM', '', 'TABASSUM SOLANKI', '', '7,Syed Sally lane kolkata -07', '', '', '', '', '', '9831149335', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831149335', '9831149335', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(895, 1, '', '', 'MAIYAM BANOO', '2006-10-14', '', 'FEMALE', '', '', '', '', '', '', '12', '107', '107', '', '', '', 'MD HOSSAIN ', '', ' KHATIZA BANOO ', '', '24/H/5 KABITITHA SAANI KOL 23', '', '', '', '', '', '9007392284', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007392284', '9007392284', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(896, 1, '', '', 'MEHE PAVEEN ', '2006-12-15', '', 'FEMALE', '', '', '', '', '', '', '12', '56', '56', '', '', '', 'ABDUL AHIM ', '', ' AZIA BEGUM ', '', '4, MOIA STEET KOL 17', '', '', '', '', '', '9831329239', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831329239', '9831329239', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(897, 1, '', '', 'MUSLIMA FATMA', '2007-02-21', '', 'FEMALE', '', '', '', '', '', '', '12', '386', '386', '', '', '', 'MD.AKAM ', '', ' SHAGUFTA ZIA', '', '24/4 KAAYA OAD KOL 17', '', '', '', '', '', '9883261052', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883261052', '9883261052', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(898, 1, '', '', 'NIDA ALI', '2005-11-27', '', 'FEMALE', '', '', '', '', '', '', '12', '346', '346', '', '', '', 'ASHAD ALI ', '', ' TABASSUM ALI ', '', '58/B, ALIMUDDIN STEET KOL 16', '', '', '', '', '', '9903084894', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903084894', '9903084894', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(899, 1, '', '', 'AHMATOON NISHA', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '12', '927', '927', '', '', '', 'AHMAT HOSSAIN', '', 'NOO JAHAN BEGUM', '', '42 B TILJALA OAD KOL-46', '', '', '', '', '', '9903426823', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903426823', '9903426823', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(900, 1, '', '', 'SABA NAAZ', '2006-09-06', '', 'FEMALE', '', '', '', '', '', '', '12', '195', '195', '', '', '', 'MD KHUSHID ALAM', '', 'IZWANA KHATOON', '', '20 KUSTIA OAD KOL 39', '', '', '', '', '', '9831315585', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831315585', '9831315585', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(901, 1, '', '', 'SAIKA KHATOON', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '12', '865', '865', '', '', '', 'MD. SHAID', '', 'NASEEN BEGUM', '', '85/Z/1B, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9831050963', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831050963', '9831050963', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(902, 1, '', '', 'SAIYA IMAN', '2006-08-18', '', 'FEMALE', '', '', '', '', '', '', '12', '245', '245', '', '', '', 'NOO ALAM ', '', 'QUMA NASIM', '', '45/2,BIGHT STEET KOL-17', '', '', '', '', '', '9831296271', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831296271', '9831296271', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(903, 1, '', '', 'SIBGHA-TUL-MONAZZA KHAN', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '12', '942', '942', '', '', '', 'FAIYAZ KHAN', '', 'AJUMAND SHAHEEN', '', '3A/1 KUSTIA MASJID BAI LANE3D FLOO KOL-39', '', '', '', '', '', '9875581395', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9875581395', '9875581395', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(904, 1, '', '', 'TAHIM IFAM', '2006-06-08', '', 'FEMALE', '', '', '', '', '', '', '12', '753', '753', '', '', '', 'MD IFAN ALAM', '', 'WAJDAH TABBASSUM', '', '22/H/5, BIGHT STEET, KOL-17', '', '', '', '', '', '9831537310', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831537310', '9831537310', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(905, 1, '', '', 'ZAHIA WAHAB', '2006-11-15', '', 'FEMALE', '', '', '', '', '', '', '12', '392', '392', '', '', '', 'MD WAHAB UDDIN ', '', ' CHANDA WAHAB ', '', '15/H/4 C.S LANE NAKELDANGA KOL 11/ 3B/H/7 GAS STEET KOL- 7', '', '', '', '', '', '9903846448', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903846448', '9903846448', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(906, 1, '', '', 'ZAINAB ASHFAQUE', '2006-12-24', '', 'FEMALE', '', '', '', '', '', '', '12', '762', '762', '', '', '', 'MD ASHFAQUE ', '', 'ANJUM NAAZ', '', '16,H/B BECK BAGAN OW KOLKATA - 17', '', '', '', '', '', '8420320443', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420320443', '8420320443', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(907, 1, '', '', 'ZAINAB FATMA', '2006-01-29', '', 'FEMALE', '', '', '', '', '', '', '12', '552', '552', '', '', '', 'MD.MAHFOOZ ALAM', '', 'HENA FATMA', '', '42/2A, TOPSIA OAD KOL-39', '', '', '', '', '', '9883694114', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883694114', '9883694114', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(908, 1, '', '', 'ZEENAT PAVEEN', '2006-06-06', '', 'FEMALE', '', '', '', '', '', '', '12', '736', '736', '', '', '', 'AHMAT ALAM', '', 'WAJDA TABASUM', '', '64/H/10, BOAD STEET KOL-19', '', '', '', '', '', '8584929252', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8584929252', '8584929252', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(909, 1, '', '', 'ZOYA PAVEEN ', '2006-09-16', '', 'FEMALE', '', '', '', '', '', '', '12', '45', '45', '', '', '', 'SK. SHAZADA ', '', ' FAHAT PAVEEN ', '', '5, KASAI PAA LANE KOL 17', '', '', '', '', '', '9748057976', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748057976', '9748057976', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(910, 1, '', '', 'ZUBYA NADIM', '2006-09-08', '', 'FEMALE', '', '', '', '', '', '', '12', '227', '227', '', '', '', 'MD.NADIM ', '', ' UKHSANA PAVEEN', '', '57,MOFIDUL ISLAM LANE KOL-14', '', '', '', '', '', '9748579662', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748579662', '9748579662', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(911, 1, '', '', 'ZUEEN SHAMS ', '2006-11-17', '', 'FEMALE', '', '', '', '', '', '', '12', '28', '28', '', '', '', 'ZEYAD SHAMS ', '', ' SHIEEN PAVEEN ', '', '7 SHASTITOLLA LANE KOL-11', '', '', '', '', '', '6290225149', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '6290225149', '6290225149', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(912, 1, '', '', 'AAMI AHMED KHAN', '2005-10-28', '', 'MALE', '', '', '', '', '', '', '12', '424', '424', '', '', '', 'AIF AHMED ', '', ' UBANA AIF', '', '3,BEDFOD LANE KOL-16', '', '', '', '', '', '9831547203', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831547203', '9831547203', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(913, 1, '', '', 'AKAM HOSSAIN', '2006-05-05', '', 'MALE', '', '', '', '', '', '', '12', '805', '805', '', '', '', 'ALTAF HOSSAIN', '', 'SLIMA KHATOON', '', '15A/1, G J KHAN OAD, KOL - 39', '', '', '', '', '', '9163549347', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163549347', '9163549347', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(914, 1, '', '', 'AL-FAAS ADIL SIDDIQUE', '2006-11-19', '', 'MALE', '', '', '', '', '', '', '12', '541', '541', '', '', '', 'ANJUM PEVEZ', '', 'SHABNAM PAVEEN', '', 'H,127 SHYAM LAL LANE GADEN EACH OAD KOL-24', '', '', '', '', '', '9831877705', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831877705', '9831877705', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(915, 1, '', '', 'ANAS BIN SADIQUE', '2007-05-12', '', 'MALE', '', '', '', '', '', '', '12', '760', '760', '', '', '', 'MD SADIQUE', '', 'ANDLIP TAANNUM', '', '29A/4A GHULAM JILANI KHAN D. KOL- 39', '', '', '', '', '', '9831984433', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831984433', '9831984433', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(916, 1, '', '', 'ASIF HAMID', '2006-02-25', '', 'MALE', '', '', '', '', '', '', '12', '813', '813', '', '', '', 'ABDUL HAMID', '', 'SALMA KHATOON', '', '7/2, GAS STEET, KOL - 9', '', '', '', '', '', '9903137342', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903137342', '9903137342', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(917, 1, '', '', 'MD ALI AKBA', '2006-12-30', '', 'MALE', '', '', '', '', '', '', '12', '984', '984', '', '', '', 'MD AKBA', '', 'TAJASSUM BEGUM', '', '85M, TOPSIA OAD, KOLKATA - 700039', '', '', '', '', '', '8697172315', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8697172315', '8697172315', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(918, 1, '', '', 'ATIF JEELANI', '2007-01-16', '', 'MALE', '', '', '', '', '', '', '12', '738', '738', '', '', '', 'GHULAM JEELANI', '', 'TABASSUM AA', '', '62/D MISBAHUL COMPLEX BLOCK ,B TOPSIA OAD KOL - 39', '', '', '', '', '', '9088387067', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9088387067', '9088387067', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(919, 1, '', '', 'EBAAD ALI', '2006-07-22', '', 'MALE', '', '', '', '', '', '', '12', '707', '707', '', '', '', 'NIAMAT ALI', '', 'ZEBA TASNEEM', '', '15/1B, SHAMSUL HUDA OAD, KOL - 17', '', '', '', '', '', '9681225013', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681225013', '9681225013', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(920, 1, '', '', 'HASSAN ALI', '2006-08-15', '', 'MALE', '', '', '', '', '', '', '12', '804', '804', '', '', '', 'MD ALI', '', 'TAHAIN ALI', '', '100, MADAN MOHAN BUMAN STEET, KOL - 7', '', '', '', '', '', '9831447045', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831447045', '9831447045', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(921, 1, '', '', 'IFTEKHA ALAM', '2006-12-11', '', 'MALE', '', '', '', '', '', '', '12', '710', '710', '', '', '', 'AFOZ ALAM ', '', 'IAM AFOZ', '', '17,DAMZEN LANE KOL-73', '', '', '', '', '', '9831321078', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831321078', '9831321078', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(922, 1, '', '', 'JUNAID KHAN', '2006-12-02', '', 'MALE', '', '', '', '', '', '', '12', '260', '260', '', '', '', 'JAVED KHAN ', '', ' DANISH SHAHEEN KHAN', '', '4/1G,CONVENT LANE ENTALLY KOL-15', '', '', '', '', '', '9831067155', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831067155', '9831067155', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(923, 1, '', '', 'KAIF AHMED', '2007-12-02', '', 'MALE', '', '', '', '', '', '', '12', '604', '604', '', '', '', 'IMAN AHMED', '', 'ALIA AHMED', '', '36,COLOOTOLA STEET KOL-73', '', '', '', '', '', '9831422800', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831422800', '9831422800', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(924, 1, '', '', 'KASHIF HUSSAIN', '2006-06-06', '', 'MALE', '', '', '', '', '', '', '12', '239', '239', '', '', '', 'TAHA HUSSAIN ', '', ' SHAMIMA BANO', '', '147 NAKEL DANGA MAIN OAD KOL - 11', '', '', '', '', '', '9231880325', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9231880325', '9231880325', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(925, 1, '', '', 'KASHIF MUSHTAQUE KHAN', '2006-08-28', '', 'MALE', '', '', '', '', '', '', '12', '673', '673', '', '', '', 'MUSHTAQUE KHAN ', '', 'NOO SABA KHATOON', '', '7B, NEW KASIA BAGAN LANE, KOLKATA - 700017', '', '', '', '', '', '9007321328', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007321328', '9007321328', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(926, 1, '', '', 'MD ASAD ALI', '2007-01-09', '', 'MALE', '', '', '', '', '', '', '12', '501', '501', '', '', '', 'MD SHAKIL AHMED ', '', ' ESHMA FAHAT', '', '71/C MOFIDUL ISLAM LANE KOL 14', '', '', '', '', '', '9038560860', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038560860', '9038560860', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(927, 1, '', '', 'MD DAANYAAL JAMIL', '2006-08-28', '', 'MALE', '', '', '', '', '', '', '12', '408', '408', '', '', '', 'MD JAMIL AHMED ', '', ' TALAT JAMIL', '', '84/1B TOPSIA OAD KOL 39', '', '', '', '', '', '9831338821', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831338821', '9831338821', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(928, 1, '', '', 'MD FAAIYZ', '2007-02-04', '', 'MALE', '', '', '', '', '', '', '12', '216', '216', '', '', '', 'MOHAMMAD YOUNUS ', '', ' ZEBA YOUNUS', '', '70,COLOOTOLA STEET.KOL-73', '', '', '', '', '', '9830456087', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830456087', '9830456087', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(929, 1, '', '', 'MD FAAZ AHMED', '2005-11-30', '', 'MALE', '', '', '', '', '', '', '12', '716', '716', '', '', '', 'EYAZ AHMED', '', 'SHUMAYAL KAUSE', '', '5F, PALM AVENUE KOL - 19', '', '', '', '', '', '8420602153', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420602153', '8420602153', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(930, 1, '', '', 'MD IMDAD ALAM', '2006-10-25', '', 'MALE', '', '', '', '', '', '', '12', '218', '218', '', '', '', 'MD. SHAHID ALI ', '', ' KHUSMUDA BEGUM ', '', '9H/3 KASAI BASTI 2ND LANE NAKEL DANGA KOL-11', '', '', '', '', '', '9038590252', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038590252', '9038590252', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(931, 1, '', '', 'MOHAMMAD ZAID', '2007-02-09', '', 'MALE', '', '', '', '', '', '', '12', '185', '185', '', '', '', 'MD SOHAIL ', '', ' DILSHAD BEGUM', '', '83 ELLIOT LANE KOL 16', '', '', '', '', '', '7003190427', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7003190427', '7003190427', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(932, 1, '', '', 'MD UMMAN', '2007-01-22', '', 'MALE', '', '', '', '', '', '', '12', '215', '215', '', '', '', 'MD.AIYAN ', '', ' ESHMA AIYAN', '', '21,NOO ALI LANE KOL-14', '', '', '', '', '', '9883982788', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883982788', '9883982788', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(933, 1, '', '', 'Md SULEIMAN ALI AHMED', '2006-08-13', '', 'MALE', '', '', '', '', '', '', '12', '217', '217', '', '', '', 'MUZAFFA ALI AHMED AI ', '', ' KOHINOO IBAHIM', '', '30B,CANTOPHE LANE KOL-14', '', '', '', '', '', '9007100522', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007100522', '9007100522', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(934, 1, '', '', 'MD YUSUF KHAN', '2006-02-25', '', 'MALE', '', '', '', '', '', '', '12', '812', '812', '', '', '', 'HASMATALLA KHAN', '', 'PAWEEN JAHAN', '', '36/1E/1D, TOPSIA OAD, KOL - 39', '', '', '', '', '', '7044129197', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7044129197', '7044129197', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(935, 1, '', '', 'MOHAMMAD ATIF HUSSAIN', '2006-04-11', '', 'MALE', '', '', '', '', '', '', '12', '113', '113', '', '', '', 'MOHAMMAD FAOOQUE ', '', ' FAINA NAZ', '', 'B/24/2/H/12,BIGHT STEET KOL-17', '', '', '', '', '', '9748650610', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748650610', '9748650610', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(936, 1, '', '', 'MUHAMMAD YASSIN SHEIF', '2006-08-26', '', 'MALE', '', '', '', '', '', '', '12', '1111', '1111', '', '', '', 'A S MD SHAMSUL HUTHA', '', 'S S AHIMA ZAINAB', '', 'EKTA FLOAL. 27, CHISTOPHE OAD, KOLKATA - 700046', '', '', '', '', '', '9883124454', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883124454', '9883124454', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(937, 1, '', '', 'MUHASIF ALAM', '2006-09-27', '', 'MALE', '', '', '', '', '', '', '12', '85', '85', '', '', '', 'MAHMOOD ALAM ', '', ' NUSAT ISAFIL', '', '40/1 MUFIDUL ISLAM LANE KOL 14', '', '', '', '', '', '9836029026', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836029026', '9836029026', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(938, 1, '', '', 'SALMAN UMA SABAH ISMAIL', '2006-07-09', '', 'MALE', '', '', '', '', '', '', '12', '511', '511', '', '', '', 'NOOUS SABAH ', '', ' AZMAT AA NOO ', '', '4,JAN NAGA 2ND LANE,KOLKATA-14', '', '', '', '', '', '9831058963', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831058963', '9831058963', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(939, 1, '', '', 'SAUSH JAFFA', '2006-08-16', '', 'MALE', '', '', '', '', '', '', '12', '679', '679', '', '', '', 'KHALID HASAN JAFY &', '', 'SABA ANJUM', '', '87B,GANT STEET KOL-13', '', '', '', '', '', '9062864330', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062864330', '9062864330', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(940, 1, '', '', 'MOHAMMAD IBAHIM', '2005-09-29', '', 'MALE', '', '', '', '', '', '', '12', '343', '343', '', '', '', 'ATIF FEOZ ', '', ' MEHNAAZ FIOZ', '', '53A,SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '9143410704', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9143410704', '9143410704', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(941, 1, '', '', 'J M MOHYDEEN ABU BACKE LABBAI SAHIB', '2007-05-30', '', 'MALE', '', '', '', '', '', '', '12', '1721', '1721', '', '', '', 'L.S. JAMAL MOHAMED', '', 'S.I.KATHEEJA ELEVANA', '', '103, PINCEP STEET, CHANDNEY CHOWK, KOLKATA - 700072', '', '', '', '', '', '7980079811', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980079811', '7980079811', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(942, 1, '', '', 'AIBA ASLAM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '13', '890', '890', '', '', '', 'MD ASLAM', '', 'FAZANA KHALIQUE', '', '24, MOFIDUL ISLAM LANE KOLKATA -14', '', '', '', '', '', '7449477110', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7449477110', '7449477110', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(943, 1, '', '', 'ALFIA HAQUE', '2006-10-16', '', 'FEMALE', '', '', '', '', '', '', '13', '410', '410', '', '', '', 'MD NOOUL HAQUE ', '', ' NASAT HAQUE', '', '100/H/4/1,DILKHUSA STEET KOL-17', '', '', '', '', '', '8420660966', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420660966', '8420660966', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(944, 1, '', '', 'ALISHA SHAMS ', '2004-09-08', '', 'FEMALE', '', '', '', '', '', '', '13', '37', '37', '', '', '', 'MD. SHAMSUDDIN ', '', ' AZIA BEGUM ', '', '37/8/E WATGUNGE STEET KOL 23', '', '', '', '', '', '9163573171', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163573171', '9163573171', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(945, 1, '', '', 'AMIMA OHIN KAMAL', '2006-06-13', '', 'FEMALE', '', '', '', '', '', '', '13', '294', '294', '', '', '', 'AFI KAMAL ', '', ' TAANNUM KAMAL ', '', '18A, KUSTIA MASJID BAI LANE KOL- 39', '', '', '', '', '', '8240668711', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240668711', '8240668711', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(946, 1, '', '', 'ASIYA PAWEEN', '2005-08-24', '', 'FEMALE', '', '', '', '', '', '', '13', '575', '575', '', '', '', 'MD BADE ALAM', '', 'afat jahan', '', '1/1 TOPSIA 2ND LANE V 1ST FLOO', '', '', '', '', '', '8240348381', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240348381', '8240348381', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(947, 1, '', '', 'AYESHA ABID', '2005-09-09', '', 'FEMALE', '', '', '', '', '', '', '13', '94', '94', '', '', '', 'MD.ABID ', '', ' NASIMA ABID', '', '20,CHAMU KHAN SAMA LANE KOL-17', '', '', '', '', '', '6290159383', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '6290159383', '6290159383', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(948, 1, '', '', 'AYESHA AZMI ', '2005-09-22', '', 'FEMALE', '', '', '', '', '', '', '13', '8', '8', '', '', '', 'MD. FAKHUDDIN ', '', ' SHAISTA PAVEEN ', '', '4, SUHAWADY AVENUE KOL 17', '', '', '', '', '', '9831587753', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831587753', '9831587753', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(949, 1, '', '', 'HAIQUA JAMSHED', '2005-12-10', '', 'FEMALE', '', '', '', '', '', '', '13', '516', '516', '', '', '', 'MD.JAMSHED ANWE ', '', ' SHAGUFTA ANA', '', '71/D,MUFIDUL ISLAM LANE KOL-14', '', '', '', '', '', '9748169810', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748169810', '9748169810', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(950, 1, '', '', 'HIBA ASLAM', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '13', '891', '891', '', '', '', 'MD ASLAM', '', 'FAZANA KHALIQUE', '', '24, MOFIDUL ISLAM LANE KOLKATA -14', '', '', '', '', '', '7449477110', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7449477110', '7449477110', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(951, 1, '', '', 'IQA NAUSHEEN QUAISHI', '2005-09-28', '', 'FEMALE', '', '', '', '', '', '', '13', '66', '66', '', '', '', 'SK SHAJID', '', 'NOOUS SEHA', '', '5, KASAI PAA LANE KOL 17', '', '', '', '', '', '8697813374', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8697813374', '8697813374', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(952, 1, '', '', 'MABUKAH ELAHI ', '2006-10-03', '', 'FEMALE', '', '', '', '', '', '', '13', '172', '172', '', '', '', 'MOOSA ELAHI ', '', ' AMAA ELAHI', '', '25A CICUS AVENUE KOL 17', '', '', '', '', '', '9748362929', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748362929', '9748362929', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(953, 1, '', '', 'MALAIKA HOSSAIN', '2005-12-22', '', 'FEMALE', '', '', '', '', '', '', '13', '214', '214', '', '', '', 'HAMID HOSSAIN ', '', ' NAHID FEOZ', '', '2/H/2,HOSSAIN SHAH OAD MOMINPU KOL-23', '', '', '', '', '', '9073989789', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9073989789', '9073989789', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(954, 1, '', '', 'MANTASHA NIZAM', '2019-02-06', '', 'FEMALE', '', '', '', '', '', '', '13', '870', '870', '', '', '', 'MD. NIZAM', '', 'SALEHA TABASSUM', '', '7/3, G ABHINASH CHOWDHUY LANE, KOL - 46', '', '', '', '', '', '8450055065', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8450055065', '8450055065', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(955, 1, '', '', 'MOSAUWA KAIYNAT', '2005-12-27', '', 'FEMALE', '', '', '', '', '', '', '13', '645', '645', '', '', '', 'MAHFOOZ ALAM', '', 'MOSAUWA IZWANA', '', '36/1E/1K/1 TOPSIA OAD KOLKATA - 39', '', '', '', '', '', '9831544514', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831544514', '9831544514', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(956, 1, '', '', 'MUNTAHA BEGUM', '2004-12-25', '', 'FEMALE', '', '', '', '', '', '', '13', '441', '441', '', '', '', 'IFTEKHA ALAM ', '', ' SABANA MEHJABEEN ', '', '10B BIGHT STEET KOL 19', '', '', '', '', '', '9433129261', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9433129261', '9433129261', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(957, 1, '', '', 'NIDA ZAMADA', '2005-09-15', '', 'FEMALE', '', '', '', '', '', '', '13', '242', '242', '', '', '', 'FAIYAZ ALI ZAMADA ', '', ' NOOJAHAN ZAMADA', '', '1,SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '8017202762', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8017202762', '8017202762', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(958, 1, '', '', 'NIGA HASSAN', '2005-11-27', '', 'FEMALE', '', '', '', '', '', '', '13', '123', '123', '', '', '', 'NISHA HASAN ', '', ' SHABANA BEGUM', '', '6/14/H/9,NILMONI HALDE LANE KOL-13', '', '', '', '', '', '9007787006', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007787006', '9007787006', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(959, 1, '', '', 'SABILA KHANAM', '2006-07-07', '', 'FEMALE', '', '', '', '', '', '', '13', '70', '70', '', '', '', 'IQBAL KHAN ', '', ' NAJMA KHANAM ', '', '25/1/1 DAGHA OAD 3D FLO KOL 17', '', '', '', '', '', '9830860786', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830860786', '9830860786', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(960, 1, '', '', 'SABA SIDDIQUA', '2006-03-14', '', 'FEMALE', '', '', '', '', '', '', '13', '127', '127', '', '', '', 'SHAKIL AHMED ', '', ' SAIQUA ISAFIL', '', '2,BENIA PUKU LANE KOL-14', '', '', '', '', '', '9831305182', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831305182', '9831305182', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(961, 1, '', '', 'SADAF ALI', '2004-11-23', '', 'FEMALE', '', '', '', '', '', '', '13', '418', '418', '', '', '', 'SAJJAD ALI ', '', ' MEHAUN NISHA', '', '22/1D SHAMSUL HUDA OAD KOL 17', '', '', '', '', '', '9748760854', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748760854', '9748760854', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(962, 1, '', '', 'SAJIYA NIKHAT', '2005-08-22', '', 'FEMALE', '', '', '', '', '', '', '13', '285', '285', '', '', '', 'FIOZ ALAM ', '', ' NIKHAT PAVEEN', '', '36/1E/1E, TOPSIA OAD KOL-39', '', '', '', '', '', '9143019301', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9143019301', '9143019301', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(963, 1, '', '', 'SANA NASI', '2005-04-27', '', 'FEMALE', '', '', '', '', '', '', '13', '800', '800', '', '', '', 'NASI ANWA', '', 'HEENA PAWEEN', '', '55/C, TOPSIA OAD (SOUTH), KOL - 46', '', '', '', '', '', '9681152308', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681152308', '9681152308', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(964, 1, '', '', 'SANIA IQBAL', '1970-01-01', '', 'FEMALE', '', '', '', '', '', '', '13', '779', '779', '', '', '', 'JAVED IQBAL', '', 'TALAT IQBAL', '', '15A/1 GHULAM JILANI KHAN OAD KOL.39', '', '', '', '', '', '9331046030', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331046030', '9331046030', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(965, 1, '', '', 'SHADMA YUNUS', '2006-06-23', '', 'FEMALE', '', '', '', '', '', '', '13', '99', '99', '', '', '', 'MD.YUNUS ', '', ' AYESHA PAVEEN', '', 'Q540/A,PAKAIA TALAB AKA OAD KOL-24', '', '', '', '', '', '9330413378', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330413378', '9330413378', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(966, 1, '', '', 'SHAIKH AQSAANAM', '2006-02-14', '', 'FEMALE', '', '', '', '', '', '', '13', '204', '204', '', '', '', 'LATE SK. FAIYAZ ', '', ' SHAIKH OMM-E-OMAAN', '', '297/E,ACHAYA PAFULLA CHANDA OAD KOL-9', '', '', '', '', '', '9339888044', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9339888044', '9339888044', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(967, 1, '', '', 'SHAZIA KALIM ', '2006-02-13', '', 'FEMALE', '', '', '', '', '', '', '13', '517', '517', '', '', '', 'MD. KALIMUDDIN ', '', ' KAUSA TABASSUM ', '', '2. TOPSIA OAD KOL-39', '', '', '', '', '', '9874289091', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874289091', '9874289091', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(968, 1, '', '', 'SHIFA AKHTE', '2005-08-12', '', 'FEMALE', '', '', '', '', '', '', '13', '518', '518', '', '', '', 'JASIM AKHTA ', '', ' SAWAI KHATOON ', '', '5, MAQUIS LANE KOL-16', '', '', '', '', '', '7044145658', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7044145658', '7044145658', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(969, 1, '', '', 'SIDA KAIM', '2005-07-22', '', 'FEMALE', '', '', '', '', '', '', '13', '391', '391', '', '', '', 'MD KHALIL ', '', ' MEHJABEEN BANO', '', '52,BECK BAGAN KOL-17', '', '', '', '', '', '9830930079', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830930079', '9830930079', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(970, 1, '', '', 'SUGA KHATOON', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '13', '868', '868', '', '', '', 'MD. QAIYUM ALAM', '', 'SAHANI KHATOON', '', '15/H/30 BIBI BAGAN LANE KOLKATA -15', '', '', '', '', '', '9331412391', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331412391', '9331412391', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(971, 1, '', '', 'SUAYYA SHAHID', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '13', '862', '862', '', '', '', 'MD SHAHID ALI', '', 'SULTANA PAVEEN', '', '4/1, KASAI BUSTEE 2ND LANE, KOL - 11', '', '', '', '', '', '8820826386', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8820826386', '8820826386', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(972, 1, '', '', 'SYEDA ABIA KHALIL', '2006-02-05', '', 'FEMALE', '', '', '', '', '', '', '13', '20', '20', '', '', '', 'ISHTEYAQUE ALAM ', '', ' SAMEEA WALI ', '', '4 B OYD LANE KOL 700016', '', '', '', '', '', '8100013177', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100013177', '8100013177', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(973, 1, '', '', 'TANIA PEVIN', '2004-08-10', '', 'FEMALE', '', '', '', '', '', '', '13', '249', '249', '', '', '', 'SK.MD.HAUN ', '', ' AFIA BEGAM', '', '6. JHOWTALA LANE KOL 17', '', '', '', '', '', '9836422908', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836422908', '9836422908', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(974, 1, '', '', 'ZAINAB LASKA', '2005-09-01', '', 'FEMALE', '', '', '', '', '', '', '13', '258', '258', '', '', '', 'NOO ISLAM LASKA/AASIA BIBI', '', 'ASHIDA LASKA', '', '45C, TOPSIA OAD KOLKATA-39', '', '', '', '', '', '7449369003', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7449369003', '7449369003', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(975, 1, '', '', 'ZAA KHADIJA', '2005-12-21', '', 'FEMALE', '', '', '', '', '', '', '13', '430', '430', '', '', '', 'JAVED GAYAS QUESHI ', '', ' NIKHAT FAUZIA QUESHI', '', '6A,KUSTIA OAD KOL-39', '', '', '', '', '', '9432498753', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9432498753', '9432498753', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(976, 1, '', '', 'ZAMEEN MUSHID', '2006-03-31', '', 'FEMALE', '', '', '', '', '', '', '13', '261', '261', '', '', '', 'MD.MUSHID ANWE ', '', ' SHABISTAN JAHAN', '', '16/3,HATI BAGAN OAD KOL-14', '', '', '', '', '', '9163439779', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163439779', '9163439779', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(977, 1, '', '', 'SUFIYA PAVEEN', '2004-09-25', '', 'FEMALE', '', '', '', '', '', '', '13', '1547', '1547', '', '', '', 'MD SHAHANNAWAZ', '', 'AZIA KHATOON', '', '2C/H/4, CHATU BABU LANE, KOLKATA - 700014', '', '', '', '', '', '9830781403', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830781403', '9830781403', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(978, 1, '', '', 'AIBA FATIMA', '2005-03-09', '', 'FEMALE', '', '', '', '', '', '', '13', '1701', '1701', '', '', '', 'MD SANJA ALI FAIDI', '', 'SAJDA FAIDI', '', '6/9, KUSTIA OAD, KOLKATA - 700039', '', '', '', '', '', '9330755108', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330755108', '9330755108', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(979, 1, '', '', 'AFEEFA BAHZAD', '2005-06-16', '', 'FEMALE', '', '', '', '', '', '', '13', '1709', '1709', '', '', '', 'BAHZAD SHAMS', '', 'SHAZIA SHAMS', '', 'IDEAL LAKEVIEW. 16/1E/1, SYEDNA MD BUHANUDDIN OAD, EAST TOPSIA, KOLKATA- 700046', '', '', '', '', '', '8583829042', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8583829042', '8583829042', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(980, 1, '', '', 'AKBA ALI', '2005-11-14', '', 'MALE', '', '', '', '', '', '', '13', '409', '409', '', '', '', 'SAJJAD ALAM ', '', ' NASEEN BANO', '', 'fom missing', '', '', '', '', '', '9331045856', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331045856', '9331045856', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(981, 1, '', '', 'ASAD ZAKI KHAN', '2005-09-02', '', 'MALE', '', '', '', '', '', '', '13', '184', '184', '', '', '', 'SHAKIL AHMED KHAN', '', 'KHUSHIDA ZAIN', '', '4/5B,MOLVI LANE KOL-16', '', '', '', '', '', '9883058781', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883058781', '9883058781', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(982, 1, '', '', 'AYAN ALI', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '13', '867', '867', '', '', '', 'MD. NAUSHAD', '', ' MASOOMA KHATOON ', '', '87/1 IPON STEET FIST FLOO B-BLOCK KOL 16', '', '', '', '', '', '9836032870', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836032870', '9836032870', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(983, 1, '', '', 'HAMJA IMAM', '2005-02-01', '', 'MALE', '', '', '', '', '', '', '13', '450', '450', '', '', '', 'ALI IMAM ', '', 'SABIHA KHATOON', '', '1/H/2 KASAI BASTI 1ST LANE NAKELDANGA - KOL -11', '', '', '', '', '', '8210425623', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8210425623', '8210425623', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(984, 1, '', '', 'HAMZA MUJTABA KHAN', '2006-03-04', '', 'MALE', '', '', '', '', '', '', '13', '183', '183', '', '', '', 'MD MUJTABA KHAN ', '', ' TAZEEN PAVEEN', '', '17/29,TOPSIA OAD KOL-39', '', '', '', '', '', '8240798831', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8240798831', '8240798831', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(985, 1, '', '', 'HUZAIFA BABA', '2003-09-22', '', 'MALE', '', '', '', '', '', '', '13', '479', '479', '', '', '', 'MD BABA ', '', ' AMIMA MUJTABA KHANAM', '', '16A,CHANDA NATH OY OAD KOL-39', '', '', '', '', '', '9831809402', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831809402', '9831809402', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(986, 1, '', '', 'ISHAAQ AHAMED', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '13', '858', '858', '', '', '', 'SHAMIM AHAMED', '', 'PAVEEN BABA', '', '168/Z KESHAB CHANDA SEN ST KOL09', '', '', '', '', '', '9330739419', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330739419', '9330739419', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(987, 1, '', '', 'MD ANAS ', '2005-03-12', '', 'MALE', '', '', '', '', '', '', '13', '506', '506', '', '', '', 'MD SHAMIM ', '', 'NASIFA BEGUM', '', 'BHASHALA MOE. M N K OAD, PO-AMPU HAT, BIBHUM - 731224', '', '', '', '', '', '8001348449', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8001348449', '8001348449', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(988, 1, '', '', 'MD AYAAN', '2005-01-19', '', 'MALE', '', '', '', '', '', '', '13', '732', '732', '', '', '', 'MD NADIM', '', ' SHAGUFTA SHAMIM ', '', '168/E KESHAB CHANA SEN STEET KOL 09', '', '', '', '', '', '9874551603', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874551603', '9874551603', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(989, 1, '', '', 'MD AYAAN MALLICK', '2005-04-18', '', 'MALE', '', '', '', '', '', '', '13', '292', '292', '', '', '', 'MD.SAJID MALLICK ', '', 'OSHAN AA ', '', 'G - 176/B SHYAM LAL LANE GADEN EACH KOLKATA - 24', '', '', '', '', '', '9331222862', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331222862', '9331222862', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(990, 1, '', '', 'MD EHTESHAM PAVEJ', '2006-03-02', '', 'MALE', '', '', '', '', '', '', '13', '835', '835', '', '', '', 'MD PAVEJ', '', ' SHAHEEN KHATOON ', '', '6/14/H/3,NILMONI HALDE LANE KOL-13', '', '', '', '', '', '9830132976', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830132976', '9830132976', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(991, 1, '', '', 'MD FAHIM SOLANKI', '2005-04-11', '', 'MALE', '', '', '', '', '', '', '13', '381', '381', '', '', '', 'MD WASIM ', '', 'TASKIN FATMA', '', '4,A G.J KHAN OAD TOPSIA KOLKATA - 39', '', '', '', '', '', '9903137001', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903137001', '9903137001', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(992, 1, '', '', 'MD KHALID ALI', '2005-12-08', '', 'MALE', '', '', '', '', '', '', '13', '861', '861', '', '', '', 'MD. QAIYUM ALAM', '', ' SAMIM SOLANKI', '', '4,AMATALLA LANE KOL-01', '', '', '', '', '', '9830283211', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830283211', '9830283211', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(993, 1, '', '', 'MD JUNAID AHMED', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '13', '960', '960', '', '', '', 'MD JAVED', '', 'SAHANI KHATOON', '', '15/H/30 BIBI BAGAN LANE KOLKATA -15', '', '', '', '', '', '9331412391', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331412391', '9331412391', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(994, 1, '', '', 'MD MUTAZA ', '2005-10-03', '', 'MALE', '', '', '', '', '', '', '13', '652', '652', '', '', '', 'MD MUSTAFA', '', 'SHABANA BEGUM', '', '25/F TOPSIA OAD KOL-39', '', '', '', '', '', '9831013483', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831013483', '9831013483', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(995, 1, '', '', 'MD WAIZ HUSSAIN', '2005-10-17', '', 'MALE', '', '', '', '', '', '', '13', '451', '451', '', '', '', 'MDZAHID HOSSAIN ', '', 'ANI BEGUM', '', '4/1B CONVENT LANE KOLKATA - 15', '', '', '', '', '', '8420952215', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420952215', '8420952215', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(996, 1, '', '', 'MD SHOAIB AFSA', '2005-08-06', '', 'MALE', '', '', '', '', '', '', '13', '825', '825', '', '', '', 'AFSA HUSSAIN', '', ' IZWANA FIDOSH', '', '17/29,TOPSIA OAD KOL-39', '', '', '', '', '', '9830305382', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830305382', '9830305382', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(997, 1, '', '', 'MD TAIQUE SAWA', '2004-10-09', '', 'MALE', '', '', '', '', '', '', '13', '154', '154', '', '', '', 'MD.SAWA ', '', 'YASMIN AFSA', '', '88/A, TOPSIA OAD, KOLKATA - 39', '', '', '', '', '', '9143006580', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9143006580', '9143006580', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(998, 1, '', '', 'MOHD SAAD IQBAL', '2005-07-27', '', 'MALE', '', '', '', '', '', '', '13', '171', '171', '', '', '', 'MD. IQBAL ', '', ' TABASUM', '', '24/6B,KUSTIA OAD KOL-39', '', '', '', '', '', '9830406770', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830406770', '9830406770', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(999, 1, '', '', 'NUMAAN MOIN ANSAI', '2005-03-06', '', 'MALE', '', '', '', '', '', '', '13', '626', '626', '', '', '', 'SIAJ UDDIN', '', ' YASMIN IQBAL', '', '40B,IMDAD ALI LANE KOL-16', '', '', '', '', '', '9748807263', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748807263', '9748807263', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1000, 1, '', '', 'NUMAN MUNZI ISMAIL', '2006-08-12', '', 'MALE', '', '', '', '', '', '', '13', '512', '512', '', '', '', 'ABDUL BASIT ISMAIL ', '', 'SHAGUFTA MOIN ', '', '155/H/4 KESHAB CHANDA SEN STEET KOL- 09', '', '', '', '', '', '9330949156', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9330949156', '9330949156', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1001, 1, '', '', 'AGHIB ABA', '2019-02-05', '', 'MALE', '', '', '', '', '', '', '13', '863', '863', '', '', '', 'MD ABA ALAM', '', ' FAZANA BASIT', '', '4,JANNAGA OAD KOL-14', '', '', '', '', '', '9831152868', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831152868', '9831152868', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1002, 1, '', '', 'OJIDUL ISLAM', '2005-07-11', '', 'MALE', '', '', '', '', '', '', '13', '1519', '1519', '', '', '', 'SK. MONIUL ISLAM', '', 'ISHAT ABA', '', '9, G J KHAN OAD, KOL - 39', '', '', '', '', '', '9163986744', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163986744', '9163986744', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1003, 1, '', '', 'SAMEE HOSSAIN', '2004-01-09', '', 'MALE', '', '', '', '', '', '', '13', '836', '836', '', '', '', 'FAIZUL HOSSAIN', '', 'OJINA BEGUM', '', '22 B, USTAD ENAYAT KHAN AVE. KOLKATA - 700017', '', '', '', '', '', '9831450676', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831450676', '9831450676', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1004, 1, '', '', 'SHADAB MAQESUD', '2005-10-23', '', 'MALE', '', '', '', '', '', '', '13', '288', '288', '', '', '', 'MAQESUD ALAM ', '', 'TABASSUM KHATOON', '', '33, AI CHAAN GHOSE LANE TOPSIA KOLKATA - 39', '', '', '', '', '', '9836158402', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836158402', '9836158402', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1005, 1, '', '', 'SHAIK MUHAMMAD SAAD ', '2006-12-11', '', 'MALE', '', '', '', '', '', '', '13', '420', '420', '', '', '', 'ABDULLAH MUNI ', '', ' NIKHAT PAVEEN', '', '36/1E/1E, TOPSIA OAD KOL-39', '', '', '', '', '', '9331053252', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331053252', '9331053252', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1006, 1, '', '', 'SHAYAAN SIDDQUE', '2006-02-19', '', 'MALE', '', '', '', '', '', '', '13', '203', '203', '', '', '', 'SHAHABUDDIN SIDDIQUE ', '', ' FATIMA MUNI', '', '105/4.kaaya oad kol-17', '', '', '', '', '', '9883887799', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883887799', '9883887799', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1007, 1, '', '', 'SK. ASZAD', '2006-03-22', '', 'MALE', '', '', '', '', '', '', '13', '47', '47', '', '', '', 'SK. DULAA', '', ' SHABNAM SIDDIQUE', '', '86/C JHOWTALA OAD KOL 17/ 47/B IPPON ST KOLKATA- 16', '', '', '', '', '', '9062076881', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062076881', '9062076881', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1008, 1, '', '', 'SYED ADIL AKHTE', '2006-07-21', '', 'MALE', '', '', '', '', '', '', '13', '752', '752', '', '', '', 'MOHAMMED AKHTE', '', ' SABANA BEGUM ', '', '24/2H/11 BIGHT STEET KOL 17', '', '', '', '', '', '9748087104', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748087104', '9748087104', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1009, 1, '', '', 'YASEEN AHMED', '2006-06-17', '', 'MALE', '', '', '', '', '', '', '13', '488', '488', '', '', '', 'SHAMSHAD AHMED ', '', 'NAGMA SIDDIQUI', '', '3/H/9,JHOWTALA LANE KOL - 17', '', '', '', '', '', '9007121030', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007121030', '9007121030', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1010, 1, '', '', 'YUSUF JAMEEL', '2005-09-05', '', 'MALE', '', '', '', '', '', '', '13', '301', '301', '', '', '', 'JAMEEL AHMED ', '', ' SHAHNAZ AHMED', '', '45A,SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '9062168062', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9062168062', '9062168062', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1011, 1, '', '', 'AHAM AHMAD', '2006-02-11', '', 'MALE', '', '', '', '', '', '', '13', '1237', '1237', '', '', '', 'IMTIYAZ AHMAD', '', ' SHAGUFTA PEVEEN', '', '84/9,IPON STEET KOL-16', '', '', '', '', '', '7980150128', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980150128', '7980150128', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1012, 1, '', '', 'MD NAFISH', '2002-02-17', '', 'MALE', '', '', '', '', '', '', '13', '739', '739', '', '', '', 'SK NAYEEM', '', 'SHAHNAZ PAWEEN', '', '41/A BIGHT STEET KOL-17', '', '', '', '', '', '9831780196', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831780196', '9831780196', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1013, 1, '', '', 'QAMA AHMED', '2005-04-10', '', 'MALE', '', '', '', '', '', '', '13', '155', '155', '', '', '', 'NIYAZ AHMED', '', 'FAIDA BEGUM', '', '28, AII PUKU OAD KOLKATA - 700019', '', '', '', '', '', '9831516923', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831516923', '9831516923', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1014, 1, '', '', 'ABDUL HAMEED', '2003-11-28', '', 'MALE', '', '', '', '', '', '', '13', '10', '10', '', '', '', 'NOOGU SULAIMAN ', '', ' NIKHAT PAVEEN', '', '24/6B,KUSTIA OAD KOL-39', '', '', '', '', '', '9830406770', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830406770', '9830406770', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1015, 1, '', '', 'SALSAAL SHAHID', '2004-03-24', '', 'MALE', '', '', '', '', '', '', '13', '1715', '1715', '', '', '', 'MD SHAHID ABBAS', '', ' HABIBATHUL AALIYA ', '', '1, MANDI STEET KOL 73', '', '', '', '', '', '9836708616', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9836708616', '9836708616', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1016, 1, '', '', 'AFIFA NOO HAOON', '2005-11-18', '', 'FEMALE', '', '', '', '', '', '', '14', '299', '299', '', '', '', 'HAOON ASHID', '', ' TABASSUM HAOON', '', '42/1B, SHAMSUL HUDA OAD KOL- 17', '', '', '', '', '', '9830452673', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830452673', '9830452673', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1017, 1, '', '', 'AKSHA KHAN', '2005-07-10', '', 'FEMALE', '', '', '', '', '', '', '14', '363', '363', '', '', '', 'MD.BABA KHAN ', '', 'MAHETALAT SIDDIQUE', '', '13,SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '8910933653', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8910933653', '8910933653', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1018, 1, '', '', 'ALIZA PAVEZ YOUSUF', '2006-04-02', '', 'FEMALE', '', '', '', '', '', '', '14', '247', '247', '', '', '', 'PAVEZ YOUSUF ', '', 'SHABAB PAVEZ', '', '6.AHII PUKU LANE KOL-17', '', '', '', '', '', '9874322357', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9874322357', '9874322357', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1019, 1, '', '', 'AYESHA ALAM', '2005-11-03', '', 'FEMALE', '', '', '', '', '', '', '14', '417', '417', '', '', '', 'AUANGZEB ALAM ', '', 'NIKHAT ALAM', '', '41/H/B/2,JANNAGA OAD KOL-17', '', '', '', '', '', '9674166201', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9674166201', '9674166201', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1020, 1, '', '', 'BUSHA TANWEE', '2004-04-15', '', 'FEMALE', '', '', '', '', '', '', '14', '803', '803', '', '', '', 'TANWEE KHAN', '', 'SHABANA KHAN', '', '36/1/14, TOPSIA OAD, KOL - 39', '', '', '', '', '', '9903882405', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903882405', '9903882405', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1021, 1, '', '', 'FATIMA IQA', '2004-11-15', '', 'FEMALE', '', '', '', '', '', '', '14', '1204', '1204', '', '', '', 'LATE MD SHAFQUAT ANA', '', 'AYESHA MAYAM', '', 'P-69, MUDIALY OAD, KOLKATA - 700024 (SAYEED ISMAIL)', '', '', '', '', '', '8820560175', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8820560175', '8820560175', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1022, 1, '', '', 'HAIQUA FATEMA', '2004-08-04', '', 'FEMALE', '', '', '', '', '', '', '14', '980', '980', '', '', '', 'ANJUM PEVEZ', '', 'SHABNAM PEVEEN', '', 'H-49, GHULAM ABBAS LANE, KOL - 24', '', '', '', '', '', '9831800486', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831800486', '9831800486', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1023, 1, '', '', 'IQA ZAKI', '2004-11-26', '', 'FEMALE', '', '', '', '', '', '', '14', '446', '446', '', '', '', 'ZAKI AHMED', '', 'NISHAT BANO ', '', '35, ABINDA SAANI KOL73', '', '', '', '', '', '9038450471', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038450471', '9038450471', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1024, 1, '', '', 'KHADIJA ASFA', '2004-09-08', '', 'FEMALE', '', '', '', '', '', '', '14', '1242', '1242', '', '', '', 'ASFA JAVED', '', '', '', 'BAAUNI, BEGUSAAI, BIHA-851126 / FLAT NO.3A. K. T. APATMENT. 232/1, TILJALA OAD, KOL - 39', '', '', '', '', '', '9934862880', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9934862880', '9934862880', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1025, 1, '', '', 'KULSOOM HAYAT', '2005-06-13', '', 'FEMALE', '', '', '', '', '', '', '14', '97', '97', '', '', '', 'LATE MAOOF PAVEZ', '', 'FATMA PAVEZ', '', '13,SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '8100266661', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8100266661', '8100266661', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1026, 1, '', '', 'LAYBA NISHA ', '2005-03-01', '', 'FEMALE', '', '', '', '', '', '', '14', '38', '38', '', '', '', 'MD NAUSHAD ', '', 'ZEBA AHMED ', '', '7/H/12, KASAI PAA LANE KOL 17', '', '', '', '', '', '9903109010', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903109010', '9903109010', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1027, 1, '', '', 'NAHIDA TABSUM', '2005-11-03', '', 'FEMALE', '', '', '', '', '', '', '14', '873', '873', '', '', '', 'JAMAL AKHTA', '', 'NOO FATIMA', '', '62,D MISBAHUL COMPLEX BLOCK A TOPSIA OAD KOLKATA - 39', '', '', '', '', '', '8420847045', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420847045', '8420847045', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);
INSERT INTO `school_admission` (`admi_id`, `sid`, `sWebsite`, `app_no`, `stu_name`, `aBirth`, `age`, `gender`, `app_relation`, `app_rel_dis`, `app_rel_name`, `app_curr_school_name`, `current_class`, `income_year`, `join_class_section`, `admission_no`, `roll_no`, `app_status`, `app_offer_specific`, `app_remark`, `name_of_parent`, `occupation`, `name_of_mother`, `mother_occupation`, `street_address`, `city`, `pincode`, `state`, `country`, `home_phone`, `mobile_phone`, `business_phone`, `email`, `medical_problem`, `medical_need`, `medical_allergies`, `food_allergies`, `blood_group`, `medical_other_info`, `class_teacher_name`, `other_subject_name`, `other_teacher_name`, `is_staff_child`, `student_category_id`, `school_bus`, `house_name`, `chome_phone`, `ccell_phone`, `cbusiness_phone`, `csms`, `cemail`, `communication_prefernce`, `ickup_child`, `emergency_contact`, `feesdate`, `feesyear`, `feename`, `totfeesamt`, `feespaidamt`, `feesbalanceamt`, `challan`, `studentphoto`, `student_type`, `suser`, `spass`, `date`, `dob_words`, `nat_state`, `religion`, `caste`, `subcaste`, `ter_convert`, `annual_income`, `name_of_guardian`, `gurd_occup`, `gurd_address_phone`, `gurd_annual_income`, `bro_sis_studying`, `tc_elmentry_leaving`, `mother_tongue`, `lang_proposed`, `previous_schl_hsrty`, `identi_marks`, `authored`, `miss_no`, `allocation`, `mis_set`, `from_date`, `to_date`, `allowed`, `allowed_usage`, `status`) VALUES
(1028, 1, '', '', 'NAUSHEEN HUSSAIN', '2004-05-03', '', 'FEMALE', '', '', '', '', '', '', '14', '78', '78', '', '', '', 'DELDA HUSSAIN ', '', 'NAZNIN HUSSAIN', '', '14, BECK BAGAN KOL-17', '', '', '', '', '', '8420611552', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420611552', '8420611552', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1029, 1, '', '', 'NAVISHTAH ELAHI', '2005-09-30', '', 'FEMALE', '', '', '', '', '', '', '14', '399', '399', '', '', '', 'MD.IFANULLAH ', '', 'NAZIA PEVEEN', '', '20/B D. BIESH GUHA STEET KOL 17/ 31A MIAJAN USTAGA LANE KOL- 17', '', '', '', '', '', '9007105499', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007105499', '9007105499', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1030, 1, '', '', 'SABA NASI', '2004-12-25', '', 'FEMALE', '', '', '', '', '', '', '14', '799', '799', '', '', '', 'NASI ANWA', '', 'HEENA PAWEEN', '', '55/C, TOPSIA OAD (SOUTH), KOL - 46', '', '', '', '', '', '9681152308', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681152308', '9681152308', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1031, 1, '', '', 'SANIA FAIYAZ', '2004-01-17', '', 'FEMALE', '', '', '', '', '', '', '14', '207', '207', '', '', '', 'FAIYAZ ALAM', '', 'SULTANA KHATOON ', '', '2H TILJALA LANE KOL 19', '', '', '', '', '', '7686857039', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7686857039', '7686857039', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1032, 1, '', '', 'SANIA HASSAN', '2019-02-06', '', 'FEMALE', '', '', '', '', '', '', '14', '859', '859', '', '', '', 'ZAAHID HASAN', '', 'HENA YASMIN', '', '11/ vtopsia 2nd lane kol-39', '', '', '', '', '', '9748659136', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748659136', '9748659136', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1033, 1, '', '', 'SAAH SOLANKI', '2004-12-24', '', 'FEMALE', '', '', '', '', '', '', '14', '380', '380', '', '', '', 'GULAM HUSSAIN ', '', 'JAINA KHATOON', '', '67/1 PICNIC GADEN KOL 39 / 4 AMATALLA LANE KOLKATA -1', '', '', '', '', '', '9830233037', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830233037', '9830233037', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1034, 1, '', '', 'SHAFAQUE FAIZI', '2004-03-26', '', 'FEMALE', '', '', '', '', '', '', '14', '557', '557', '', '', '', 'SHAH ALAM', '', 'FAZANA ALAM', '', '59, CANNING ST. KOLKATA-01', '', '', '', '', '', '9163012116', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163012116', '9163012116', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1035, 1, '', '', 'SHAFAQUE SABA ALAM', '2004-10-21', '', 'FEMALE', '', '', '', '', '', '', '14', '725', '725', '', '', '', 'MD SADE ALAM', '', 'SABANA KHATUN', '', '121 , ABINDA SAANI KOLKATA , 700073', '', '', '', '', '', '9883130769', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883130769', '9883130769', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1036, 1, '', '', 'SHAMIA SAJID', '2019-02-05', '', 'FEMALE', '', '', '', '', '', '', '14', '945', '945', '', '', '', 'MD SAJID', '', 'ANJUM SHAMS', '', '46C, GOA CHAND OAD PS.BENIA PUKU KOL-14', '', '', '', '', '', '8420048531', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420048531', '8420048531', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1037, 1, '', '', 'SHYEMA BUSHA', '2005-01-15', '', 'FEMALE', '', '', '', '', '', '', '14', '547', '547', '', '', '', 'MD KADI KHAN', '', 'shaheen bano', '', '29,TOPSIA AD SOUTH KOLKATA-46', '', '', '', '', '', '9831792231', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831792231', '9831792231', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1038, 1, '', '', 'SOFIA ANAM', '2005-01-26', '', 'FEMALE', '', '', '', '', '', '', '14', '86', '86', '', '', '', 'ANAMUL HAQUE', '', ' SHAHEEN PAVEEN', '', 'PMIE ESIDECY 61-B BLOCK-E 2ND FLOO JILANI KHAN OAD KOL 39', '', '', '', '', '', '9163348182', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163348182', '9163348182', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1039, 1, '', '', 'SYEDA BIBI BISMILLAH HASSAN', '2004-08-22', '', 'FEMALE', '', '', '', '', '', '', '14', '651', '651', '', '', '', 'JUNAIDUL HASSAN', '', 'iffat naaz', '', '10 , BIGHT STEET KOLKATA - 700019', '', '', '', '', '', '9007321730', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007321730', '9007321730', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1040, 1, '', '', 'TASNIM SAKIL', '2003-09-24', '', 'FEMALE', '', '', '', '', '', '', '14', '438', '438', '', '', '', 'SAKIL ', '', 'AYESHA SAKIL', '', '26,AI CHAAN GHOSH LANE KOL-39', '', '', '', '', '', '7278875140', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7278875140', '7278875140', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1041, 1, '', '', 'ZUBYA ASLAM', '2005-11-23', '', 'FEMALE', '', '', '', '', '', '', '14', '429', '429', '', '', '', 'MD.ASLAM ', '', 'NILOFA ASLAM', '', '59A,CANNING STEET,KOL-', '', '', '', '', '', '9163014399', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163014399', '9163014399', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1042, 1, '', '', 'UQAYYA MAHMOOD', '2005-12-15', '', 'FEMALE', '', '', '', '', '', '', '14', '1713', '1713', '', '', '', 'MOHAMMAD MAHMOOD ALAM', '', 'MAHJABIN MAHMOOD', '', 'TILJALA LANE, BESIDE EGAL NUSING HOME, KOLKATA - 700019', '', '', '', '', '', '7323004885', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7323004885', '7323004885', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1043, 1, '', '', 'J M SEYED NOOHU FATHIMA SAHIB', '2005-08-19', '', 'FEMALE', '', '', '', '', '', '', '14', '1722', '1722', '', '', '', 'L.S. JAMAL MOHAMED', '', 'S.I.KATHEEJA ELEVANA', '', '103, PINCEP STEET, CHANDNEY CHOWK, KOLKATA - 700072', '', '', '', '', '', '7980079811', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '7980079811', '7980079811', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1044, 1, '', '', 'AMMA HUSSAIN SHAHAYA', '2005-10-14', '', 'MALE', '', '', '', '', '', '', '14', '383', '383', '', '', '', 'MD SHAAZADA MD HUSSAIN ', '', 'UHI NAZIA ', '', '13/H/5,SI SYED AHMED OAD KOL-14', '', '', '', '', '', '8697353054', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8697353054', '8697353054', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1045, 1, '', '', 'ASHAD HUSSAIN', '2005-06-05', '', 'MALE', '', '', '', '', '', '', '14', '75', '75', '', '', '', 'ASHOF HUSSAIN ', '', ' NIKHAT PAVEEN', '', '40A/H3, SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '9163129647', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9163129647', '9163129647', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1046, 1, '', '', 'ASI ALAM', '2004-05-25', '', 'MALE', '', '', '', '', '', '', '14', '202', '202', '', '', '', 'PAVEZ ALAM ', '', ' ATIA PAVEEN', '', '4C/1A,GOA CHAND LANE KOL-14', '', '', '', '', '', '9830367233', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830367233', '9830367233', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1047, 1, '', '', 'GAZI HAFIJU AHMAN ', '2005-04-06', '', 'MALE', '', '', '', '', '', '', '14', '521', '521', '', '', '', 'SUJAUDDIN GAZI ', '', 'FAHAT GAZI', '', '64,G.J KHAN OAD KOL- 39', '', '', '', '', '', '9831995396', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831995396', '9831995396', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1048, 1, '', '', 'HUZEFA ZUBAI', '2002-09-06', '', 'MALE', '', '', '', '', '', '', '14', '456', '456', '', '', '', 'ABDULLAH ZUBAI ', '', ' AFIA ZUBAI', '', '49,JHOWTALLA OAD KOL-17', '', '', '', '', '', '8420234415', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420234415', '8420234415', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1049, 1, '', '', 'MD AAZIB SHAMIM', '2004-05-15', '', 'MALE', '', '', '', '', '', '', '14', '650', '650', '', '', '', ' MD. SHAMIM AKHTA', '', 'Anjum Aa', '', '41/A BIGHT STEET KOLKATA - 700017', '', '', '', '', '', '8420223488', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8420223488', '8420223488', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1050, 1, '', '', 'MD ADEEB EQUBAL', '2004-03-26', '', 'MALE', '', '', '', '', '', '', '14', '200', '200', '', '', '', 'JAWAID EQUBAL ', '', ' ESHMA BEGUM', '', '114/C, TOPSIA OAD KOL-39', '', '', '', '', '', '9681888049', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681888049', '9681888049', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1051, 1, '', '', 'MD AMAAN', '2003-11-27', '', 'MALE', '', '', '', '', '', '', '14', '731', '731', '', '', '', 'MD NADIM', '', 'OSHAN AA ', '', 'G - 176/B SHYAM LAL LANE GADEN EACH KOLKATA - 24', '', '', '', '', '', '9748350123', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748350123', '9748350123', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1052, 1, '', '', 'MOHAMMED AMMA SHABANDI', '2004-09-04', '', 'MALE', '', '', '', '', '', '', '14', '112', '112', '', '', '', 'ASIM ABU BAKE ', '', ' SHAZIYA ASIM ', '', '100A, ABINDA SAANI KOL-73', '', '', '', '', '', '9331828123', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331828123', '9331828123', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1053, 1, '', '', 'MD AHAM ASHFAQUE', '2004-05-02', '', 'MALE', '', '', '', '', '', '', '14', '831', '831', '', '', '', 'ASHFAQUE AHMED', '', 'SHAHEENA PAVEEN', '', '44, TOPSIA OAD KOLKATA - 39', '', '', '', '', '', '9088784373', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9088784373', '9088784373', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1054, 1, '', '', 'MD FAZ ISLAM ', '2004-12-26', '', 'MALE', '', '', '', '', '', '', '14', '485', '485', '', '', '', 'MD WAIS ISLAM ', '', 'SHABNAM PAVEEN ', '', '15/H/3 SMITH LANE KOL 13', '', '', '', '', '', '9007361606', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007361606', '9007361606', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1055, 1, '', '', 'MD GASSAN ALI', '2004-10-02', '', 'MALE', '', '', '', '', '', '', '14', '971', '971', '', '', '', 'MD NAUSHAD ', '', 'ESHMA KHAI', '', '29A/4A, G J KHAN OAD, KOLKATA - 39', '', '', '', '', '', '9748848256', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748848256', '9748848256', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1056, 1, '', '', 'MD HAAIS AHMAN', '2005-06-20', '', 'MALE', '', '', '', '', '', '', '14', '460', '460', '', '', '', 'ABDU AHMAN ', '', 'SHANAZ BEGUM', '', '3/2 SHAIKH PAA LANE KOL 4', '', '', '', '', '', '9038431373', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038431373', '9038431373', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1057, 1, '', '', 'MD HASEEBUL QAMA', '2005-09-25', '', 'MALE', '', '', '', '', '', '', '14', '495', '495', '', '', '', 'MOHAMAD SHAMSHAD QAMA', '', 'DUE FATMA QAMA', '', '24,BENIA PUKHE LANE KOL-14', '', '', '', '', '', '9748565711', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748565711', '9748565711', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1058, 1, '', '', 'MD HASSAN ALI', '2004-10-02', '', 'MALE', '', '', '', '', '', '', '14', '972', '972', '', '', '', 'MD NAUSHAD ', '', 'ESHMA KHAI', '', '29A/4A, G J KHAN OAD, KOLKATA - 39', '', '', '', '', '', '9748848256', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748848256', '9748848256', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1059, 1, '', '', 'MD IBAHIM ', '2004-08-22', '', 'MALE', '', '', '', '', '', '', '14', '388', '388', '', '', '', 'MD.KHALIL ', '', ' MEHJABEEN BANO', '', '52,BECK BAGAN OW KOL-17', '', '', '', '', '', '9830930079', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9830930079', '9830930079', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1060, 1, '', '', 'MD MIAZUDDIN', '2005-04-14', '', 'MALE', '', '', '', '', '', '', '14', '846', '846', '', '', '', 'MD NIZAMUDDIN', '', 'SHABANA BEGUM', '', '6A/1A, TILJALA LANE, KOL - 39', '', '', '', '', '', '9038963121', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9038963121', '9038963121', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1061, 1, '', '', 'MD MUSA-AL-SHAHNAWAZ', '2005-08-09', '', 'MALE', '', '', '', '', '', '', '14', '222', '222', '', '', '', 'SHAHNAWAZ ALI AHMED AI ', '', ' ADA SHAYESTA SUBBUH', '', '30/B,CANTOPHE LANE KOL-14', '', '', '', '', '', '8961102599', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8961102599', '8961102599', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1062, 1, '', '', 'MD OSAID MISBAH', '2004-11-26', '', 'MALE', '', '', '', '', '', '', '14', '253', '253', '', '', '', 'MD.KHALID MISBAH ', '', ' NASEEN JAHAN', '', '19D,SI SYED AHMED OAD KOL-14', '', '', '', '', '', '9861127817', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9861127817', '9861127817', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1063, 1, '', '', 'MD SAIF', '2005-05-23', '', 'MALE', '', '', '', '', '', '', '14', '179', '179', '', '', '', 'MD.SABI ', '', ' SHABANA AZAD', '', '14/1B,SHAMSUL HUDA OAD KOL-17', '', '', '', '', '', '9007471611', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007471611', '9007471611', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1064, 1, '', '', 'MD SHAHID ALI', '2005-02-16', '', 'MALE', '', '', '', '', '', '', '14', '52', '52', '', '', '', 'MD.AKBA ALI ', '', ' AKBAI BEGUM', '', '7/H/9,KASAI PAA LANE KOL-17', '', '', '', '', '', '9681837785', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681837785', '9681837785', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1065, 1, '', '', 'MD ZAHID JAMAL', '2005-11-12', '', 'MALE', '', '', '', '', '', '', '14', '121', '121', '', '', '', 'MD.JAMALUDDIN ', '', ' GULSHAN JAMAL', '', 'B/22/1/H/4,BIGHT STEET KOL 17', '', '', '', '', '', '9748547411', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748547411', '9748547411', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1066, 1, '', '', 'MOHAMMAD YUSUF', '2005-01-14', '', 'MALE', '', '', '', '', '', '', '14', '367', '367', '', '', '', 'NEHAL AHMED ', '', 'ZEBA NEHAL', '', '44,MCLEOD STEET KOL-17', '', '', '', '', '', '9831676755', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831676755', '9831676755', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1067, 1, '', '', 'SAAD ANSAI', '2004-12-16', '', 'MALE', '', '', '', '', '', '', '14', '109', '109', '', '', '', 'SABI AHMED ANSAI ', '', ' SABINA ANSAI', '', '9H/5,ALIMUDDIN STEET KOL-16', '', '', '', '', '', '9331015978', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9331015978', '9331015978', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1068, 1, '', '', 'SK. BABA ALI ', '2005-08-27', '', 'MALE', '', '', '', '', '', '', '14', '532', '532', '', '', '', 'SK. OUSHAN ALI ', '', 'SALMA BEGUM ', '', '37, TOPSIA OAD KOL-46 (SOUTH) ', '', '', '', '', '', '9143348668', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9143348668', '9143348668', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1069, 1, '', '', 'ZAINUL ABEDIN', '2005-02-12', '', 'MALE', '', '', '', '', '', '', '14', '308', '308', '', '', '', 'ZAINUL HAQUE ', '', ' ANJUM PAVEEN', '', '2B/H/10, CHATU BABU LANE KOL-14', '', '', '', '', '', '9007736081', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9007736081', '9007736081', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1070, 1, '', '', 'YUSUF HUSAIN', '2004-12-26', '', 'MALE', '', '', '', '', '', '', '14', '297', '297', '', '', '', 'AKAM HUSSAIN ', '', ' SAIQA HUSSAIN', '', '5/3,GEEN PAK TILJALA LANE KOL-19', '', '', '', '', '', '9883177486', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9883177486', '9883177486', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1071, 1, '', '', 'SK. AHBA-UL-HUDA', '2004-02-03', '', 'MALE', '', '', '', '', '', '', '14', '1708', '1708', '', '', '', 'BAHZAD SHAMS', '', 'SHAZIA SHAMS', '', 'IDEAL LAKEVIEW. 16/1E/1, SYEDNA MD BUHANUDDIN OAD, EAST TOPSIA, KOLKATA- 700046', '', '', '', '', '', '8583829042', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8583829042', '8583829042', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1072, 1, '', '', 'ZAIDAN AKAM', '2003-11-19', '', 'MALE', '', '', '', '', '', '', '14', '548', '548', '', '', '', 'MD OMA', '', 'Mumtaz Begum', '', '48,TOPSIA OAD SOUTH KOLKATA-46', '', '', '', '', '', '8621019228', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '8621019228', '8621019228', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1073, 1, '', '', 'MD ZAIN ALI - UNENOLLED', '2004-10-06', '', 'MALE', '', '', '', '', '', '', '14', '849', '849', '', '', '', 'MD IFTEKHA ALAM', '', 'NAFISA ALAM', '', '105/2, KAAYA OAD, KOL - 17', '', '', '', '', '', '9748930840', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9748930840', '9748930840', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1074, 1, '', '', 'SK. SHAHNAWAZ ALAM - UNENOLLED', '2006-01-01', '', 'MALE', '', '', '', '', '', '', '14', '165', '165', '', '', '', 'SK. IZWAN ALAM ', '', ' ANJUM AA', '', '57D,TOPSIA OAD (S) KOL-46', '', '', '', '', '', '9681167327', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9681167327', '9681167327', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1075, 1, '', '', 'MUJTABA SHAMIM', '2003-04-26', '', 'MALE', '', '', '', '', '', '', '14', '1716', '1716', '', '', '', 'MD SHAMIM', '', 'SHABANA SHAMIM', '', '59/A, CANNING STEET, KOLKATA - 700001', '', '', '', '', '', '9831282606', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831282606', '9831282606', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1076, 1, '', '', 'MD WAQQAS ZAHID', '2005-03-23', '', 'MALE', '', '', '', '', '', '', '14', '954', '954', '', '', '', 'MD ZAHID', '', 'SHAGUFTA PEVEEN', '', '59 A, 1ST FLOO BIPLABI AS BIHAI BOSE OAD KOL-01', '', '', '', '', '', '9831315234', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9831315234', '9831315234', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(1077, 1, '', '', 'FAIZAN AZA ', '2004-06-13', '', 'MALE', '', '', '', '', '', '', '13', 'R1489', 'R1489', '', '', '', 'MD  JALALUDDIN', '', 'ESHMA ', '', '29A/4A, GOLAM JILANI KHAN OAD, KOL - 39', '', '', '', '', '', '9903403748', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'profile', '9903403748', '9903403748', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `school_admission_fees`
--

CREATE TABLE `school_admission_fees` (
  `feesid` int(11) NOT NULL,
  `admi_id` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionid` int(11) NOT NULL,
  `feesdate` varchar(255) NOT NULL,
  `feesyear` varchar(50) NOT NULL,
  `feesname` varchar(200) NOT NULL,
  `totfeesamt` varchar(255) NOT NULL,
  `feespaidamt` varchar(255) NOT NULL,
  `feesbalanceamt` varchar(255) NOT NULL,
  `challan` text NOT NULL,
  `feesfullname` varchar(255) NOT NULL,
  `receipt_no` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `classname` varchar(255) NOT NULL,
  `checksave` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_admission_old`
--

CREATE TABLE `school_admission_old` (
  `admi_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `app_no` varchar(255) NOT NULL,
  `stu_name` varchar(255) NOT NULL,
  `aBirth` date NOT NULL,
  `age` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `app_relation` varchar(255) NOT NULL,
  `app_rel_dis` varchar(255) NOT NULL,
  `app_rel_name` varchar(255) NOT NULL,
  `app_curr_school_name` varchar(255) NOT NULL,
  `current_class` varchar(255) NOT NULL,
  `income_year` varchar(255) NOT NULL,
  `join_class_section` varchar(255) NOT NULL,
  `admission_no` varchar(255) NOT NULL,
  `roll_no` varchar(255) NOT NULL,
  `app_status` varchar(255) NOT NULL,
  `app_offer_specific` varchar(255) NOT NULL,
  `app_remark` text NOT NULL,
  `name_of_parent` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `street_address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `home_phone` varchar(255) NOT NULL,
  `mobile_phone` varchar(255) NOT NULL,
  `business_phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `medical_problem` text NOT NULL,
  `medical_need` text NOT NULL,
  `medical_allergies` text NOT NULL,
  `food_allergies` text NOT NULL,
  `blood_group` varchar(255) NOT NULL,
  `medical_other_info` text NOT NULL,
  `class_teacher_name` varchar(255) NOT NULL,
  `other_subject_name` varchar(255) NOT NULL,
  `other_teacher_name` varchar(255) NOT NULL,
  `is_staff_child` varchar(255) NOT NULL,
  `school_bus` varchar(255) NOT NULL,
  `house_name` varchar(255) NOT NULL,
  `chome_phone` varchar(50) NOT NULL,
  `ccell_phone` varchar(50) NOT NULL,
  `cbusiness_phone` varchar(50) NOT NULL,
  `csms` varchar(50) NOT NULL,
  `cemail` varchar(50) NOT NULL,
  `communication_prefernce` varchar(888) NOT NULL,
  `ickup_child` varchar(255) NOT NULL,
  `emergency_contact` varchar(255) NOT NULL,
  `feesdate` varchar(255) NOT NULL,
  `feesyear` varchar(255) NOT NULL,
  `feename` varchar(255) NOT NULL,
  `totfeesamt` varchar(255) NOT NULL,
  `feespaidamt` varchar(255) NOT NULL,
  `feesbalanceamt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_config_acadamic`
--

CREATE TABLE `school_config_acadamic` (
  `scId` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `scFDate` varchar(255) NOT NULL,
  `scTDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_config_acadamic`
--

INSERT INTO `school_config_acadamic` (`scId`, `sId`, `scFDate`, `scTDate`) VALUES
(1, 1, 'Apirl-2018', 'March-2019');

-- --------------------------------------------------------

--
-- Table structure for table `school_config_design`
--

CREATE TABLE `school_config_design` (
  `id` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `teacher_name` text NOT NULL,
  `class_section_id` text NOT NULL,
  `designation_type` text NOT NULL,
  `Designation` text NOT NULL,
  `Designation_code` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_config_design`
--

INSERT INTO `school_config_design` (`id`, `sId`, `teacher_name`, `class_section_id`, `designation_type`, `Designation`, `Designation_code`) VALUES
(1, 1, '', '', '', 'testing', 'test001');

-- --------------------------------------------------------

--
-- Table structure for table `school_config_fee`
--

CREATE TABLE `school_config_fee` (
  `id` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `acadamic_section_id` text NOT NULL,
  `class_section_id` text NOT NULL,
  `note` text NOT NULL,
  `amt` text NOT NULL,
  `fee_name` text NOT NULL,
  `challan` varchar(64) NOT NULL,
  `fromDate` varchar(64) NOT NULL,
  `toDate` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_config_grade`
--

CREATE TABLE `school_config_grade` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `grade` text NOT NULL,
  `classes` text NOT NULL,
  `min_mark` int(11) NOT NULL,
  `max_mark` int(11) NOT NULL,
  `graderow_id` int(11) NOT NULL,
  `apply_version` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_config_house`
--

CREATE TABLE `school_config_house` (
  `hId` int(11) NOT NULL,
  `sId` int(11) NOT NULL,
  `scHName` varchar(250) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_config_qualification`
--

CREATE TABLE `school_config_qualification` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `staff_name` varchar(5000) NOT NULL,
  `qualification` text NOT NULL,
  `qualification_category` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_config_salary`
--

CREATE TABLE `school_config_salary` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `salary_name` varchar(255) NOT NULL,
  `salary_amt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_config_section`
--

CREATE TABLE `school_config_section` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `classname` varchar(555) NOT NULL,
  `classes` text NOT NULL,
  `section` text NOT NULL,
  `gradesettings` int(11) NOT NULL COMMENT '1 - applied, 0 - not applied',
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_config_section`
--

INSERT INTO `school_config_section` (`id`, `sid`, `classname`, `classes`, `section`, `gradesettings`, `status`) VALUES
(1, 1, 'I Std-A', 'I Std', 'A', 0, 1),
(2, 1, 'I Std-B', 'I Std', 'B', 0, 1),
(3, 1, 'II Std-A', 'II Std', 'A', 0, 1),
(4, 1, 'II Std-B', 'II Std', 'B', 0, 1),
(5, 1, 'II Std-C', 'II Std', 'C', 0, 1),
(6, 1, 'IV Std-A', 'IV Std', 'A', 0, 1),
(7, 1, 'IV Std-B', 'IV Std', 'B', 0, 1),
(8, 1, 'IV Std-C', 'IV Std', 'C', 0, 1),
(9, 1, 'V Std-A', 'V Std', 'A', 0, 1),
(10, 1, 'V Std-B', 'V Std', 'B', 0, 1),
(11, 1, 'VI Std-A', 'VI Std', 'A', 0, 1),
(12, 1, 'VI Std-B', 'VI Std', 'B', 0, 1),
(13, 1, 'VII Std-A', 'VII Std', 'A', 0, 1),
(14, 1, 'VIII Std-A', 'VIII Std', 'A', 0, 1),
(15, 1, 'III Std-A', 'III Std', 'A', 0, 1),
(16, 1, 'III Std-B', 'III Std', 'B', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `school_cos_mark_grade`
--

CREATE TABLE `school_cos_mark_grade` (
  `markId` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `examId` int(11) NOT NULL,
  `stuId` int(11) NOT NULL,
  `cos_subjectId` int(11) NOT NULL,
  `cos_grade` varchar(150) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_exam_mark`
--

CREATE TABLE `school_exam_mark` (
  `markId` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `examId` int(11) NOT NULL,
  `stuId` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL,
  `mark` varchar(150) NOT NULL,
  `status` varchar(100) NOT NULL,
  `pass_mark` varchar(10) NOT NULL,
  `total_mark` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_exam_mark_grade`
--

CREATE TABLE `school_exam_mark_grade` (
  `markId` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `examId` int(11) NOT NULL,
  `stuId` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL,
  `fa_mark` varchar(150) NOT NULL,
  `sa_mark` varchar(20) NOT NULL,
  `total_mark` varchar(20) NOT NULL,
  `fa_grade` varchar(20) NOT NULL,
  `sa_grade` varchar(20) NOT NULL,
  `total_grade` varchar(20) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_exam_total_grade`
--

CREATE TABLE `school_exam_total_grade` (
  `srId` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `examId` int(11) NOT NULL,
  `stuId` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `remark` text NOT NULL,
  `total` int(11) NOT NULL,
  `total_grade` varchar(20) NOT NULL,
  `stat` varchar(100) NOT NULL,
  `cr` int(11) NOT NULL,
  `or` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_fees_collection`
--

CREATE TABLE `school_fees_collection` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `academicid` int(11) NOT NULL,
  `school_config_acadamic_id` int(11) NOT NULL,
  `fees_type_id` int(11) NOT NULL,
  `term_setting_id` varchar(250) NOT NULL,
  `class` varchar(50) NOT NULL,
  `school_admissionid` int(11) DEFAULT NULL,
  `student_name` varchar(100) NOT NULL,
  `fathername` varchar(100) NOT NULL,
  `classsectionid` int(11) NOT NULL,
  `rollno` varchar(50) NOT NULL,
  `feenameid` varchar(250) NOT NULL,
  `fee_history` text NOT NULL,
  `fees_amount` varchar(250) DEFAULT NULL,
  `paid_amount` varchar(250) DEFAULT NULL,
  `balance_amount` varchar(250) DEFAULT NULL,
  `old_fees_amount` varchar(100) NOT NULL,
  `late_fee_amount` varchar(100) NOT NULL,
  `concession` varchar(100) NOT NULL,
  `concession_amount` varchar(100) NOT NULL,
  `net_amount` varchar(100) NOT NULL,
  `receipt_no` varchar(100) DEFAULT NULL,
  `payment_mode` varchar(20) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `cheque_dd_no` varchar(50) NOT NULL,
  `cheque_date` varchar(20) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `is_active` int(11) DEFAULT '1',
  `updatedon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff_form_id` int(11) DEFAULT NULL,
  `cancel_reason` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_fees_collection`
--

INSERT INTO `school_fees_collection` (`id`, `sid`, `academicid`, `school_config_acadamic_id`, `fees_type_id`, `term_setting_id`, `class`, `school_admissionid`, `student_name`, `fathername`, `classsectionid`, `rollno`, `feenameid`, `fee_history`, `fees_amount`, `paid_amount`, `balance_amount`, `old_fees_amount`, `late_fee_amount`, `concession`, `concession_amount`, `net_amount`, `receipt_no`, `payment_mode`, `bank_name`, `cheque_dd_no`, `cheque_date`, `remarks`, `is_active`, `updatedon`, `staff_form_id`, `cancel_reason`) VALUES
(1, 1, 0, 1, 1, '', 'I Std', 1, 'ADEEBAH IFAN', 'MD IFAN AHMED', 1, '1531', '1', 'a:1:{i:0;a:10:{s:12:\"fees_name_id\";s:1:\"1\";s:7:\"feename\";s:12:\"Monthly Fees\";s:7:\"remarks\";s:3:\"Apr\";s:18:\"concession_percent\";s:1:\"0\";s:17:\"concession_amount\";s:1:\"0\";s:8:\"totalfee\";s:4:\"1620\";s:7:\"latefee\";s:1:\"0\";s:8:\"rowtotal\";s:4:\"1620\";s:11:\"paid_amount\";s:4:\"1620\";s:10:\"feepaytype\";s:6:\"normal\";}}', '1620', '1620', '0', '0', '0', '0', '0', '1620', '', 'Cash', '', '', '', '', 1, '2019-02-08 06:04:20', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `school_profile`
--

CREATE TABLE `school_profile` (
  `sId` int(11) NOT NULL,
  `sName` varchar(200) NOT NULL,
  `sCode` varchar(50) NOT NULL,
  `sAddress` text NOT NULL,
  `sContactNumber` varchar(100) NOT NULL,
  `sMobileNumber` varchar(100) NOT NULL,
  `sEmail` varchar(100) NOT NULL,
  `sWebsite` varchar(100) NOT NULL,
  `sPrincipal` varchar(200) NOT NULL,
  `sCorrespondent` varchar(200) NOT NULL,
  `sUsername` varchar(100) NOT NULL,
  `sPassword` varchar(100) NOT NULL,
  `institution` int(11) NOT NULL,
  `syllabus` int(11) NOT NULL COMMENT '1-State Board,2-CBSE,3-ICSE',
  `homework_sms_char` int(11) NOT NULL COMMENT '160 char only for sms ',
  `homework_sms_type` int(11) NOT NULL COMMENT '0 - Single SMS Box, 1 -  Subject wise SMS Box',
  `sLogo` varchar(200) NOT NULL,
  `simage` varchar(200) NOT NULL,
  `sClass` varchar(250) NOT NULL,
  `contactperson_name` text NOT NULL,
  `admission_start_no` varchar(255) NOT NULL,
  `application_start_no` varchar(255) NOT NULL,
  `rollno_start_no` varchar(255) NOT NULL,
  `senderid` varchar(255) NOT NULL,
  `suserid` varchar(255) NOT NULL,
  `smspassword` varchar(255) NOT NULL,
  `redsms_senderid` varchar(255) NOT NULL,
  `redsms_username` varchar(255) NOT NULL,
  `redsms_password` varchar(255) NOT NULL,
  `smsfundo_senderid` varchar(255) NOT NULL,
  `smsfundo_username` varchar(255) NOT NULL,
  `smsfundo_password` varchar(255) NOT NULL,
  `buycheap_senderid` varchar(255) NOT NULL,
  `buycheap_username` varchar(255) NOT NULL,
  `buycheap_password` varchar(255) NOT NULL,
  `chenusername` varchar(100) NOT NULL,
  `chenpassword` varchar(100) NOT NULL,
  `chensenderid` varchar(100) NOT NULL,
  `chenchannel` varchar(100) NOT NULL,
  `chendcs` varchar(100) NOT NULL,
  `chenflashsms` varchar(100) NOT NULL,
  `chenroute` varchar(100) NOT NULL,
  `sms_company_details` varchar(255) NOT NULL,
  `receipt_no` int(11) NOT NULL,
  `checksave` varchar(255) NOT NULL,
  `headorbranch` varchar(255) NOT NULL,
  `reportcard_sname` varchar(255) NOT NULL,
  `reportcard_slogo` varchar(255) NOT NULL,
  `reportcard_sacdyear` varchar(50) NOT NULL,
  `reportcard_template` int(11) NOT NULL COMMENT '1-sample1,2-sample2,3-sample3',
  `sAttendancetype` int(11) NOT NULL,
  `sAccountfromdate` date NOT NULL,
  `sAccounttodate` date NOT NULL,
  `sAcademicfromdate` date NOT NULL,
  `sAcademictodate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_profile`
--

INSERT INTO `school_profile` (`sId`, `sName`, `sCode`, `sAddress`, `sContactNumber`, `sMobileNumber`, `sEmail`, `sWebsite`, `sPrincipal`, `sCorrespondent`, `sUsername`, `sPassword`, `institution`, `syllabus`, `homework_sms_char`, `homework_sms_type`, `sLogo`, `simage`, `sClass`, `contactperson_name`, `admission_start_no`, `application_start_no`, `rollno_start_no`, `senderid`, `suserid`, `smspassword`, `redsms_senderid`, `redsms_username`, `redsms_password`, `smsfundo_senderid`, `smsfundo_username`, `smsfundo_password`, `buycheap_senderid`, `buycheap_username`, `buycheap_password`, `chenusername`, `chenpassword`, `chensenderid`, `chenchannel`, `chendcs`, `chenflashsms`, `chenroute`, `sms_company_details`, `receipt_no`, `checksave`, `headorbranch`, `reportcard_sname`, `reportcard_slogo`, `reportcard_sacdyear`, `reportcard_template`, `sAttendancetype`, `sAccountfromdate`, `sAccounttodate`, `sAcademicfromdate`, `sAcademictodate`) VALUES
(1, 'JIBREEL INTERNATIONAL SCHOOL', '', '13/2/6 MAHENDRA ROY LANE (MARUTI BAGAN) TOPSIA, KOLKATA 700046 WEST BENGAL', '8981311766', '', 'jibreelinternationalschool@gmail.com', 'http://jibreelinternationalschool.com/', 'JUNAID ALI FIZA ZAMADAR (HR)', '', 'jibreel@jibreel.com', 'jibreel?05', 1, 3, 1, 0, '', '', 'I Std,II Std,III Std,IV Std,V Std,VI Std,VII Std,VIII Std', '', '', '', '', '', '', '', '', '', '', 'IJMHSS', 'sardonxmledusms', 'sarxml11', '', '', '', '', '', '', '', '', '', '', '5', 0, '', '1', '', '', '', 0, 1, '2018-04-01', '2019-03-31', '2019-02-05', '2019-02-05');

-- --------------------------------------------------------

--
-- Table structure for table `school_remarks`
--

CREATE TABLE `school_remarks` (
  `srId` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `examId` int(11) NOT NULL,
  `stuId` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `remark` text NOT NULL,
  `total` int(11) NOT NULL,
  `tot` int(11) NOT NULL,
  `stat` varchar(100) NOT NULL,
  `cr` int(11) NOT NULL,
  `or` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_subjects`
--

CREATE TABLE `school_subjects` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `subject` text NOT NULL,
  `Abbrevation` text NOT NULL,
  `class_section` varchar(255) NOT NULL,
  `gradesettings` int(11) NOT NULL COMMENT '1 - applied, 0 - not applied',
  `isweeklyclass` int(11) NOT NULL,
  `isexam` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `school_subjects_cos`
--

CREATE TABLE `school_subjects_cos` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `cos_sub_id` int(11) NOT NULL,
  `class_section` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `scl_sal_fields`
--

CREATE TABLE `scl_sal_fields` (
  `id` int(11) NOT NULL,
  `sId` varchar(100) NOT NULL,
  `field_name` varchar(100) NOT NULL,
  `sal_type` varchar(100) NOT NULL,
  `desig_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `smslogs`
--

CREATE TABLE `smslogs` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `message` text NOT NULL,
  `phonenumbers` text NOT NULL,
  `response` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_attendance`
--

CREATE TABLE `staff_attendance` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `staff_department_id` int(11) NOT NULL,
  `Attendancedate` date NOT NULL,
  `Fullpresent` text NOT NULL,
  `Halfpresent` text NOT NULL,
  `Absent` text NOT NULL,
  `Absentwithpermission` text NOT NULL,
  `delay` text NOT NULL,
  `edelay` text NOT NULL,
  `Remark` text NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_attendance_oldformat`
--

CREATE TABLE `staff_attendance_oldformat` (
  `attendanceId` int(11) NOT NULL,
  `admissionId` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `Fullpresent` int(11) NOT NULL,
  `Halfpresent` int(11) NOT NULL,
  `Absent` int(11) NOT NULL,
  `Absentwithpermission` int(11) NOT NULL,
  `Classwithsection` int(11) NOT NULL,
  `Attendancedate` date NOT NULL,
  `Remark` text NOT NULL,
  `Takenattendance` datetime NOT NULL,
  `att_month` varchar(100) NOT NULL,
  `att_year` varchar(100) NOT NULL,
  `delay` int(11) NOT NULL,
  `edelay` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_basic_detail`
--

CREATE TABLE `staff_basic_detail` (
  `sId` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `sWebsite` text NOT NULL,
  `sFName` varchar(250) NOT NULL,
  `sMName` varchar(250) NOT NULL,
  `sLName` varchar(250) NOT NULL,
  `sDOB` date NOT NULL,
  `sGender` varchar(50) NOT NULL,
  `sBloodgroup` varchar(20) NOT NULL,
  `sEmail` varchar(250) NOT NULL,
  `sPhone` varchar(100) NOT NULL,
  `sMobile` varchar(100) NOT NULL,
  `sStreetaddress` varchar(500) NOT NULL,
  `sState` varchar(100) NOT NULL,
  `sCity` varchar(100) NOT NULL,
  `sCountry` varchar(200) NOT NULL,
  `sZipcode` varchar(100) NOT NULL,
  `suser` varchar(40) NOT NULL,
  `spass` varchar(40) NOT NULL,
  `teacherdesg` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_department`
--

CREATE TABLE `staff_department` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_designation`
--

CREATE TABLE `staff_designation` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_form`
--

CREATE TABLE `staff_form` (
  `id` int(11) NOT NULL,
  `sId` varchar(100) NOT NULL,
  `scode` varchar(100) NOT NULL,
  `spass` varchar(200) NOT NULL,
  `sFName` varchar(100) NOT NULL,
  `sMName` varchar(100) NOT NULL,
  `sLName` varchar(100) NOT NULL,
  `pName` varchar(100) NOT NULL,
  `sDOB` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `sPhone` varchar(100) NOT NULL,
  `sMobile` varchar(100) NOT NULL,
  `sGender` varchar(100) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `marital` varchar(100) NOT NULL,
  `b_grp` varchar(100) NOT NULL,
  `fat_name` varchar(100) NOT NULL,
  `wk_of` varchar(100) NOT NULL,
  `sEmail` varchar(100) NOT NULL,
  `addr1` varchar(100) NOT NULL,
  `addr2` varchar(100) NOT NULL,
  `sCountry` varchar(100) NOT NULL,
  `sState` varchar(100) NOT NULL,
  `sCity` varchar(100) NOT NULL,
  `sZipcode` varchar(100) NOT NULL,
  `own_trans` varchar(100) NOT NULL,
  `scl_bus` varchar(100) NOT NULL,
  `hostel` varchar(100) NOT NULL,
  `teacherdesg` varchar(100) NOT NULL,
  `job_type` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `accountnumber` varchar(100) NOT NULL,
  `b_sal` varchar(110) NOT NULL,
  `field_earn` text NOT NULL,
  `field_dedu` text NOT NULL,
  `gross_sal` varchar(100) NOT NULL,
  `tot_sal` varchar(100) NOT NULL,
  `net_sal` varchar(100) NOT NULL,
  `ct_class_name` varchar(100) NOT NULL,
  `ct_subject` varchar(100) NOT NULL,
  `sub_class_name` varchar(100) NOT NULL,
  `sub_subject` varchar(100) NOT NULL,
  `menu_cls_name` varchar(100) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `date_of_join` varchar(100) NOT NULL,
  `d_month` varchar(100) NOT NULL,
  `d_year` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_grade`
--

CREATE TABLE `staff_grade` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_personal_detail`
--

CREATE TABLE `staff_personal_detail` (
  `spId` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `sClass` int(11) NOT NULL,
  `sSubject` int(11) NOT NULL,
  `sWebsite` text NOT NULL,
  `sMaritalstatus` varchar(100) NOT NULL,
  `sHouse` int(11) NOT NULL,
  `sDateofjoining` date NOT NULL,
  `sDateofleaving` date NOT NULL,
  `sQcategory` varchar(200) NOT NULL,
  `sQualification` int(11) NOT NULL,
  `sSName` varchar(100) NOT NULL,
  `sSAmount` decimal(8,2) NOT NULL,
  `teacherdesg` varchar(255) NOT NULL,
  `staffid` varchar(90) NOT NULL,
  `service` varchar(90) NOT NULL,
  `bankname` varchar(90) NOT NULL,
  `accountnumber` varchar(90) NOT NULL,
  `pannumber` varchar(90) NOT NULL,
  `pfnumber` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_postion`
--

CREATE TABLE `staff_postion` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff_profile`
--

CREATE TABLE `staff_profile` (
  `id` int(11) NOT NULL,
  `sId` varchar(100) NOT NULL,
  `staff_designation_id` int(11) NOT NULL,
  `staff_postion_id` int(11) NOT NULL,
  `staff_grade_id` int(11) NOT NULL,
  `staff_department_id` int(11) NOT NULL,
  `class_teacher` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `scode` varchar(100) NOT NULL,
  `spass` varchar(200) NOT NULL,
  `sFName` varchar(100) NOT NULL,
  `sMName` varchar(100) NOT NULL,
  `sLName` varchar(100) NOT NULL,
  `pName` varchar(100) NOT NULL,
  `sDOB` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `sPhone` varchar(100) NOT NULL,
  `sMobile` varchar(100) NOT NULL,
  `sGender` varchar(100) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `marital` varchar(100) NOT NULL,
  `b_grp` varchar(100) NOT NULL,
  `fat_name` varchar(100) NOT NULL,
  `wk_of` varchar(100) NOT NULL,
  `sEmail` varchar(100) NOT NULL,
  `addr1` varchar(100) NOT NULL,
  `addr2` varchar(100) NOT NULL,
  `sCountry` varchar(100) NOT NULL,
  `sState` varchar(100) NOT NULL,
  `sCity` varchar(100) NOT NULL,
  `sZipcode` varchar(100) NOT NULL,
  `own_trans` varchar(100) NOT NULL,
  `scl_bus` varchar(100) NOT NULL,
  `hostel` varchar(100) NOT NULL,
  `teacherdesg` varchar(100) NOT NULL,
  `job_type` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `accountnumber` varchar(100) NOT NULL,
  `b_sal` varchar(110) NOT NULL,
  `field_earn` text NOT NULL,
  `field_dedu` text NOT NULL,
  `gross_sal` varchar(100) NOT NULL,
  `tot_sal` varchar(100) NOT NULL,
  `net_sal` varchar(100) NOT NULL,
  `ct_class_name` varchar(100) NOT NULL,
  `ct_subject` varchar(100) NOT NULL,
  `sub_class_name` varchar(100) NOT NULL,
  `sub_subject` varchar(100) NOT NULL,
  `menu_cls_name` varchar(100) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `date_of_join` varchar(100) NOT NULL,
  `d_month` varchar(100) NOT NULL,
  `d_year` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `staffphoto` varchar(255) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` varchar(55) NOT NULL,
  `name` text NOT NULL,
  `dept` text NOT NULL,
  `mobile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance`
--

CREATE TABLE `student_attendance` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `Attendancedate` date NOT NULL,
  `Fullpresent` text NOT NULL,
  `Halfpresent` text NOT NULL,
  `Absent` text NOT NULL,
  `Absentwithpermission` text NOT NULL,
  `delay` text NOT NULL,
  `edelay` text NOT NULL,
  `Remark` text NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance_oldformat`
--

CREATE TABLE `student_attendance_oldformat` (
  `attendanceId` int(11) NOT NULL,
  `admissionId` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `Fullpresent` int(11) NOT NULL,
  `Halfpresent` int(11) NOT NULL,
  `Absent` int(11) NOT NULL,
  `Absentwithpermission` int(11) NOT NULL,
  `Classwithsection` int(11) NOT NULL,
  `Attendancedate` date NOT NULL,
  `Remark` text NOT NULL,
  `Takenattendance` datetime NOT NULL,
  `delay` int(11) NOT NULL,
  `edelay` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_categories`
--

CREATE TABLE `student_categories` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_dicipline`
--

CREATE TABLE `student_dicipline` (
  `mid` int(11) NOT NULL,
  `admi_id` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionid` int(11) NOT NULL,
  `incidentdate` varchar(255) NOT NULL,
  `reportedby` varchar(255) NOT NULL,
  `incidentdetail` varchar(255) NOT NULL,
  `putype` varchar(255) NOT NULL,
  `dpoints` varchar(255) NOT NULL,
  `actiontaken` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_diciplines`
--

CREATE TABLE `student_diciplines` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `incidentdate` date NOT NULL,
  `reportedby` varchar(255) NOT NULL,
  `incidentdetail` varchar(255) NOT NULL,
  `putype` varchar(255) NOT NULL,
  `dpoints` varchar(255) NOT NULL,
  `actiontaken` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_medical`
--

CREATE TABLE `student_medical` (
  `mid` int(11) NOT NULL,
  `admi_id` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `sectionid` int(11) NOT NULL,
  `mdate` varchar(255) NOT NULL,
  `mreport` varchar(255) NOT NULL,
  `mproblem` varchar(255) NOT NULL,
  `maction` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_medicals`
--

CREATE TABLE `student_medicals` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `mdate` date NOT NULL,
  `mreport` varchar(255) NOT NULL,
  `mproblem` varchar(255) NOT NULL,
  `maction` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_profile`
--

CREATE TABLE `student_profile` (
  `admi_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `app_no` varchar(255) NOT NULL,
  `stu_name` varchar(255) NOT NULL,
  `aBirth` date NOT NULL,
  `age` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `app_relation` varchar(255) NOT NULL,
  `app_rel_dis` varchar(255) NOT NULL,
  `app_rel_name` varchar(255) NOT NULL,
  `app_curr_school_name` varchar(255) NOT NULL,
  `current_class` varchar(255) NOT NULL,
  `income_year` varchar(255) NOT NULL,
  `join_class_section` varchar(255) NOT NULL,
  `admission_no` varchar(255) NOT NULL,
  `roll_no` varchar(255) NOT NULL,
  `app_status` varchar(255) NOT NULL,
  `app_offer_specific` varchar(255) NOT NULL,
  `app_remark` text NOT NULL,
  `name_of_parent` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `street_address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `pincode` text NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `home_phone` varchar(255) NOT NULL,
  `mobile_phone` varchar(255) NOT NULL,
  `business_phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `medical_problem` text NOT NULL,
  `medical_need` text NOT NULL,
  `medical_allergies` text NOT NULL,
  `food_allergies` text NOT NULL,
  `blood_group` varchar(255) NOT NULL,
  `medical_other_info` text NOT NULL,
  `class_teacher_name` varchar(255) NOT NULL,
  `other_subject_name` varchar(255) NOT NULL,
  `other_teacher_name` varchar(255) NOT NULL,
  `is_staff_child` varchar(255) NOT NULL,
  `school_bus` varchar(255) NOT NULL,
  `house_name` varchar(255) NOT NULL,
  `chome_phone` varchar(50) NOT NULL,
  `ccell_phone` varchar(50) NOT NULL,
  `cbusiness_phone` varchar(50) NOT NULL,
  `csms` varchar(50) NOT NULL,
  `cemail` varchar(50) NOT NULL,
  `communication_prefernce` varchar(888) NOT NULL,
  `ickup_child` varchar(255) NOT NULL,
  `emergency_contact` varchar(255) NOT NULL,
  `feesdate` varchar(255) NOT NULL,
  `feesyear` varchar(255) NOT NULL,
  `feename` varchar(255) NOT NULL,
  `totfeesamt` varchar(255) NOT NULL,
  `feespaidamt` varchar(255) NOT NULL,
  `feesbalanceamt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stu_exam_roomall`
--

CREATE TABLE `stu_exam_roomall` (
  `sturoom` int(11) NOT NULL,
  `roomno` longtext NOT NULL,
  `exdetid` int(11) NOT NULL,
  `clsname` longtext NOT NULL,
  `autman` int(11) NOT NULL,
  `stuclsname` longtext NOT NULL,
  `noofstu` longtext NOT NULL,
  `fromstu` longtext NOT NULL,
  `tostu` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subcastes`
--

CREATE TABLE `subcastes` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `caste_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subject_allotment`
--

CREATE TABLE `subject_allotment` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `school_config_section_id` int(11) NOT NULL,
  `school_subject_id` int(11) NOT NULL,
  `staff_department_id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_home_works`
--

CREATE TABLE `tbl_home_works` (
  `home_work_id` bigint(11) UNSIGNED NOT NULL,
  `school_id` int(11) NOT NULL,
  `class_section` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `home_work` text NOT NULL,
  `sms_sent` tinyint(1) NOT NULL DEFAULT '0',
  `updated_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `home_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tec_roomselection`
--

CREATE TABLE `tec_roomselection` (
  `tecrooid` int(11) NOT NULL,
  `examrid` int(11) NOT NULL,
  `roomno` varchar(100) NOT NULL,
  `teachername` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `term_setting`
--

CREATE TABLE `term_setting` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `fees_type_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `is_active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `time`
--

CREATE TABLE `time` (
  `id` int(11) NOT NULL,
  `time` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `id` int(11) NOT NULL,
  `dept` text NOT NULL,
  `monday_1` text NOT NULL,
  `monday_2` text NOT NULL,
  `monday_3` text NOT NULL,
  `monday_4` text NOT NULL,
  `monday_5` text NOT NULL,
  `monday_6` text NOT NULL,
  `monday_7` text NOT NULL,
  `monday_8` text NOT NULL,
  `tuesday_1` text NOT NULL,
  `tuesday_2` text NOT NULL,
  `tuesday_3` text NOT NULL,
  `tuesday_4` text NOT NULL,
  `tuesday_5` text NOT NULL,
  `tuesday_6` text NOT NULL,
  `tuesday_7` text NOT NULL,
  `tuesday_8` text NOT NULL,
  `wednesday_1` text NOT NULL,
  `wednesday_2` text NOT NULL,
  `wednesday_3` text NOT NULL,
  `wednesday_4` text NOT NULL,
  `wednesday_5` text NOT NULL,
  `wednesday_6` text NOT NULL,
  `wednesday_7` text NOT NULL,
  `wednesday_8` text NOT NULL,
  `thursday_1` text NOT NULL,
  `thursday_2` text NOT NULL,
  `thursday_3` text NOT NULL,
  `thursday_4` text NOT NULL,
  `thursday_5` text NOT NULL,
  `thursday_6` text NOT NULL,
  `thursday_7` text NOT NULL,
  `thursday_8` text NOT NULL,
  `friday_1` text NOT NULL,
  `friday_2` text NOT NULL,
  `friday_3` text NOT NULL,
  `friday_4` text NOT NULL,
  `friday_5` text NOT NULL,
  `friday_6` text NOT NULL,
  `friday_7` text NOT NULL,
  `friday_8` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `visiting_details`
--

CREATE TABLE `visiting_details` (
  `visiting_id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `visiting_no` varchar(255) NOT NULL,
  `visiting_name` varchar(255) NOT NULL,
  `visiting_date` varchar(50) NOT NULL,
  `age` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `intime` varchar(255) NOT NULL,
  `outtime` varchar(255) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `status` text NOT NULL,
  `name_of_parent` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `name_of_mother` varchar(255) NOT NULL,
  `mother_occupation` varchar(50) NOT NULL,
  `street_address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `pincode` text NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `home_phone` varchar(255) NOT NULL,
  `mobile_phone` varchar(255) NOT NULL,
  `business_phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `medical_problem` text NOT NULL,
  `medical_need` text NOT NULL,
  `medical_allergies` text NOT NULL,
  `food_allergies` text NOT NULL,
  `blood_group` varchar(255) NOT NULL,
  `medical_other_info` text NOT NULL,
  `class_teacher_name` varchar(255) NOT NULL,
  `other_subject_name` varchar(255) NOT NULL,
  `other_teacher_name` varchar(255) NOT NULL,
  `is_staff_child` varchar(255) NOT NULL,
  `school_bus` varchar(255) NOT NULL,
  `house_name` varchar(255) NOT NULL,
  `chome_phone` varchar(50) NOT NULL,
  `ccell_phone` varchar(50) NOT NULL,
  `cbusiness_phone` varchar(50) NOT NULL,
  `csms` varchar(50) NOT NULL,
  `cemail` varchar(50) NOT NULL,
  `communication_prefernce` varchar(888) NOT NULL,
  `ickup_child` varchar(255) NOT NULL,
  `emergency_contact` varchar(255) NOT NULL,
  `feesdate` varchar(255) NOT NULL,
  `feesyear` varchar(255) NOT NULL,
  `feename` varchar(255) NOT NULL,
  `totfeesamt` varchar(255) NOT NULL,
  `feespaidamt` varchar(255) NOT NULL,
  `feesbalanceamt` varchar(255) NOT NULL,
  `studentphoto` varchar(300) NOT NULL,
  `student_type` varchar(50) NOT NULL DEFAULT 'admission',
  `suser` varchar(70) NOT NULL,
  `spass` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `weekdays`
--

CREATE TABLE `weekdays` (
  `wid` int(11) NOT NULL,
  `days` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `week_off`
--

CREATE TABLE `week_off` (
  `id` int(11) NOT NULL,
  `wk_of` varchar(12) NOT NULL,
  `desig_id` varchar(50) NOT NULL,
  `sId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`aId`);

--
-- Indexes for table `addroom`
--
ALTER TABLE `addroom`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `add_exam`
--
ALTER TABLE `add_exam`
  ADD PRIMARY KEY (`examId`);

--
-- Indexes for table `add_exam_name`
--
ALTER TABLE `add_exam_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `admin_details`
--
ALTER TABLE `admin_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_editaccess`
--
ALTER TABLE `admin_editaccess`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `autoname_types`
--
ALTER TABLE `autoname_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auto_generations`
--
ALTER TABLE `auto_generations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fees_group_id` (`fees_type_id`);

--
-- Indexes for table `bank_entry`
--
ALTER TABLE `bank_entry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank_name`
--
ALTER TABLE `bank_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank_setting`
--
ALTER TABLE `bank_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `book_fees_collection`
--
ALTER TABLE `book_fees_collection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bus_fees_collection`
--
ALTER TABLE `bus_fees_collection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `castes`
--
ALTER TABLE `castes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certificate`
--
ALTER TABLE `certificate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`com_id`);

--
-- Indexes for table `cosholatic_grades`
--
ALTER TABLE `cosholatic_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `school_config_section_id` (`school_config_section_id`),
  ADD KEY `exam_detail_id` (`exam_detail_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `cosholatic_subsubject_id` (`cosholatic_subsubject_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `cosholatic_mainsubject`
--
ALTER TABLE `cosholatic_mainsubject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cosholatic_subsubject`
--
ALTER TABLE `cosholatic_subsubject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dynamicfields`
--
ALTER TABLE `dynamicfields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dynamictables`
--
ALTER TABLE `dynamictables`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_code`
--
ALTER TABLE `emp_code`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `start` (`start`),
  ADD KEY `end` (`end`),
  ADD KEY `allDay` (`allDay`),
  ADD KEY `usertype` (`usertype`),
  ADD KEY `holiday` (`holiday`);

--
-- Indexes for table `events_old`
--
ALTER TABLE `events_old`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `examroomallocation`
--
ALTER TABLE `examroomallocation`
  ADD PRIMARY KEY (`exid`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_config_grades`
--
ALTER TABLE `exam_config_grades`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_config_totalgrades`
--
ALTER TABLE `exam_config_totalgrades`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_details`
--
ALTER TABLE `exam_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `generatecard_status` (`generatecard_status`),
  ADD KEY `examentry_type` (`examentry_type`);

--
-- Indexes for table `exam_grades`
--
ALTER TABLE `exam_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_config_section_id` (`school_config_section_id`),
  ADD KEY `exam_detail_id` (`exam_detail_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `school_subject_id` (`school_subject_id`);

--
-- Indexes for table `exam_mark`
--
ALTER TABLE `exam_mark`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `school_config_section_id` (`school_config_section_id`),
  ADD KEY `exam_id` (`exam_detail_id`),
  ADD KEY `school_subject_id` (`school_subject_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `exam_remarks`
--
ALTER TABLE `exam_remarks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chart1` (`chart1`),
  ADD KEY `chart2` (`chart2`),
  ADD KEY `school_config_section_id` (`school_config_section_id`),
  ADD KEY `exam_detail_id` (`exam_detail_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `exam_totalgrades`
--
ALTER TABLE `exam_totalgrades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school_config_section_id` (`school_config_section_id`),
  ADD KEY `exam_detail_id` (`exam_detail_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `chart1` (`chart1`),
  ADD KEY `chart2` (`chart2`),
  ADD KEY `chart3` (`chart3`),
  ADD KEY `chart4` (`chart4`),
  ADD KEY `chart5` (`chart5`),
  ADD KEY `chart6` (`chart6`);

--
-- Indexes for table `expenses_entry`
--
ALTER TABLE `expenses_entry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses_setting`
--
ALTER TABLE `expenses_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees_collection_default`
--
ALTER TABLE `fees_collection_default`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees_discount`
--
ALTER TABLE `fees_discount`
  ADD PRIMARY KEY (`id`),
  ADD KEY `classsectionid` (`classsectionid`),
  ADD KEY `school_admissionid` (`school_admissionid`);

--
-- Indexes for table `fees_group`
--
ALTER TABLE `fees_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees_name`
--
ALTER TABLE `fees_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees_type`
--
ALTER TABLE `fees_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `frbl_banner`
--
ALTER TABLE `frbl_banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `full_atten`
--
ALTER TABLE `full_atten`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`),
  ADD KEY `sid` (`sid`);

--
-- Indexes for table `groupname`
--
ALTER TABLE `groupname`
  ADD PRIMARY KEY (`gr_id`);

--
-- Indexes for table `home_works`
--
ALTER TABLE `home_works`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel_manage`
--
ALTER TABLE `hostel_manage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel_room`
--
ALTER TABLE `hostel_room`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `hostel_type_id` (`hostel_type_id`),
  ADD KEY `hostel_manage_id` (`hostel_manage_id`);

--
-- Indexes for table `hostel_room_allocation`
--
ALTER TABLE `hostel_room_allocation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `hostel_type_id` (`hostel_type_id`),
  ADD KEY `hostel_manage_id` (`hostel_manage_id`),
  ADD KEY `hostel_room_id` (`hostel_room_id`),
  ADD KEY `school_config_section_id` (`school_config_section_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `hostel_type`
--
ALTER TABLE `hostel_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_item_master`
--
ALTER TABLE `inventory_item_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_supplier_master`
--
ALTER TABLE `inventory_supplier_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leaves`
--
ALTER TABLE `leaves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_app_his`
--
ALTER TABLE `leave_app_his`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_dect`
--
ALTER TABLE `leave_dect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_name`
--
ALTER TABLE `leave_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lesson_boards`
--
ALTER TABLE `lesson_boards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_profile_id` (`staff_profile_id`);

--
-- Indexes for table `lesson_board_activity`
--
ALTER TABLE `lesson_board_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lesson_board_activity_list`
--
ALTER TABLE `lesson_board_activity_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `share_status` (`share_status`);

--
-- Indexes for table `lesson_board_config`
--
ALTER TABLE `lesson_board_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `libraray_book_issue`
--
ALTER TABLE `libraray_book_issue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `libraray_new_book`
--
ALTER TABLE `libraray_new_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `libraray_rules`
--
ALTER TABLE `libraray_rules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `libraray_subject`
--
ALTER TABLE `libraray_subject`
  ADD PRIMARY KEY (`hId`);

--
-- Indexes for table `loan_mgmt`
--
ALTER TABLE `loan_mgmt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loan_trans`
--
ALTER TABLE `loan_trans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manage_timing`
--
ALTER TABLE `manage_timing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `minute`
--
ALTER TABLE `minute`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `month_setting`
--
ALTER TABLE `month_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_home_works`
--
ALTER TABLE `new_home_works`
  ADD PRIMARY KEY (`home_work_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_types`
--
ALTER TABLE `notification_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `old_leaveform`
--
ALTER TABLE `old_leaveform`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paymentplan`
--
ALTER TABLE `paymentplan`
  ADD PRIMARY KEY (`pId`);

--
-- Indexes for table `period`
--
ALTER TABLE `period`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `periods`
--
ALTER TABLE `periods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quickabse_class`
--
ALTER TABLE `quickabse_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quick_absent`
--
ALTER TABLE `quick_absent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `receipt_no`
--
ALTER TABLE `receipt_no`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reportcard_settings`
--
ALTER TABLE `reportcard_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reportentry`
--
ALTER TABLE `reportentry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report_field`
--
ALTER TABLE `report_field`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles_settings`
--
ALTER TABLE `roles_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sal_day_set`
--
ALTER TABLE `sal_day_set`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_admission`
--
ALTER TABLE `school_admission`
  ADD PRIMARY KEY (`admi_id`),
  ADD KEY `status` (`status`),
  ADD KEY `suser` (`suser`),
  ADD KEY `spass` (`spass`),
  ADD KEY `admission_no` (`admission_no`),
  ADD KEY `join_class_section` (`join_class_section`),
  ADD KEY `roll_no` (`roll_no`);

--
-- Indexes for table `school_admission_fees`
--
ALTER TABLE `school_admission_fees`
  ADD PRIMARY KEY (`feesid`);

--
-- Indexes for table `school_admission_old`
--
ALTER TABLE `school_admission_old`
  ADD PRIMARY KEY (`admi_id`);

--
-- Indexes for table `school_config_acadamic`
--
ALTER TABLE `school_config_acadamic`
  ADD PRIMARY KEY (`scId`);

--
-- Indexes for table `school_config_design`
--
ALTER TABLE `school_config_design`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_config_fee`
--
ALTER TABLE `school_config_fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_config_grade`
--
ALTER TABLE `school_config_grade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_config_house`
--
ALTER TABLE `school_config_house`
  ADD PRIMARY KEY (`hId`);

--
-- Indexes for table `school_config_qualification`
--
ALTER TABLE `school_config_qualification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_config_salary`
--
ALTER TABLE `school_config_salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_config_section`
--
ALTER TABLE `school_config_section`
  ADD PRIMARY KEY (`id`),
  ADD KEY `classname` (`classname`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `school_cos_mark_grade`
--
ALTER TABLE `school_cos_mark_grade`
  ADD PRIMARY KEY (`markId`);

--
-- Indexes for table `school_exam_mark`
--
ALTER TABLE `school_exam_mark`
  ADD PRIMARY KEY (`markId`);

--
-- Indexes for table `school_exam_mark_grade`
--
ALTER TABLE `school_exam_mark_grade`
  ADD PRIMARY KEY (`markId`);

--
-- Indexes for table `school_exam_total_grade`
--
ALTER TABLE `school_exam_total_grade`
  ADD PRIMARY KEY (`srId`);

--
-- Indexes for table `school_fees_collection`
--
ALTER TABLE `school_fees_collection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `classsectionid` (`classsectionid`);

--
-- Indexes for table `school_profile`
--
ALTER TABLE `school_profile`
  ADD PRIMARY KEY (`sId`),
  ADD KEY `sUsername` (`sUsername`),
  ADD KEY `sPassword` (`sPassword`);

--
-- Indexes for table `school_remarks`
--
ALTER TABLE `school_remarks`
  ADD PRIMARY KEY (`srId`);

--
-- Indexes for table `school_subjects`
--
ALTER TABLE `school_subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_subjects_cos`
--
ALTER TABLE `school_subjects_cos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scl_sal_fields`
--
ALTER TABLE `scl_sal_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smslogs`
--
ALTER TABLE `smslogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_attendance`
--
ALTER TABLE `staff_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_attendance_oldformat`
--
ALTER TABLE `staff_attendance_oldformat`
  ADD PRIMARY KEY (`attendanceId`);

--
-- Indexes for table `staff_basic_detail`
--
ALTER TABLE `staff_basic_detail`
  ADD PRIMARY KEY (`sId`);

--
-- Indexes for table `staff_department`
--
ALTER TABLE `staff_department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_designation`
--
ALTER TABLE `staff_designation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_form`
--
ALTER TABLE `staff_form`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `staff_grade`
--
ALTER TABLE `staff_grade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_personal_detail`
--
ALTER TABLE `staff_personal_detail`
  ADD PRIMARY KEY (`spId`);

--
-- Indexes for table `staff_postion`
--
ALTER TABLE `staff_postion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_profile`
--
ALTER TABLE `staff_profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `student_attendance`
--
ALTER TABLE `student_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_attendance_oldformat`
--
ALTER TABLE `student_attendance_oldformat`
  ADD PRIMARY KEY (`attendanceId`);

--
-- Indexes for table `student_categories`
--
ALTER TABLE `student_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_dicipline`
--
ALTER TABLE `student_dicipline`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `student_diciplines`
--
ALTER TABLE `student_diciplines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_medical`
--
ALTER TABLE `student_medical`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `student_medicals`
--
ALTER TABLE `student_medicals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `school_config_section_id` (`school_config_section_id`),
  ADD KEY `mdate` (`mdate`);

--
-- Indexes for table `student_profile`
--
ALTER TABLE `student_profile`
  ADD PRIMARY KEY (`admi_id`);

--
-- Indexes for table `stu_exam_roomall`
--
ALTER TABLE `stu_exam_roomall`
  ADD PRIMARY KEY (`sturoom`);

--
-- Indexes for table `subcastes`
--
ALTER TABLE `subcastes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject_allotment`
--
ALTER TABLE `subject_allotment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_home_works`
--
ALTER TABLE `tbl_home_works`
  ADD PRIMARY KEY (`home_work_id`);

--
-- Indexes for table `tec_roomselection`
--
ALTER TABLE `tec_roomselection`
  ADD PRIMARY KEY (`tecrooid`);

--
-- Indexes for table `term_setting`
--
ALTER TABLE `term_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `time`
--
ALTER TABLE `time`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visiting_details`
--
ALTER TABLE `visiting_details`
  ADD PRIMARY KEY (`visiting_id`);

--
-- Indexes for table `weekdays`
--
ALTER TABLE `weekdays`
  ADD PRIMARY KEY (`wid`);

--
-- Indexes for table `week_off`
--
ALTER TABLE `week_off`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `aId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `addroom`
--
ALTER TABLE `addroom`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `add_exam`
--
ALTER TABLE `add_exam`
  MODIFY `examId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `add_exam_name`
--
ALTER TABLE `add_exam_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_details`
--
ALTER TABLE `admin_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_editaccess`
--
ALTER TABLE `admin_editaccess`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `autoname_types`
--
ALTER TABLE `autoname_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auto_generations`
--
ALTER TABLE `auto_generations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bank_entry`
--
ALTER TABLE `bank_entry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bank_name`
--
ALTER TABLE `bank_name`
  MODIFY `id` int(64) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bank_setting`
--
ALTER TABLE `bank_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `book_fees_collection`
--
ALTER TABLE `book_fees_collection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bus_fees_collection`
--
ALTER TABLE `bus_fees_collection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `castes`
--
ALTER TABLE `castes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `certificate`
--
ALTER TABLE `certificate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `com_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cosholatic_grades`
--
ALTER TABLE `cosholatic_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cosholatic_mainsubject`
--
ALTER TABLE `cosholatic_mainsubject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cosholatic_subsubject`
--
ALTER TABLE `cosholatic_subsubject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dynamicfields`
--
ALTER TABLE `dynamicfields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dynamictables`
--
ALTER TABLE `dynamictables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `emp_code`
--
ALTER TABLE `emp_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enquiries`
--
ALTER TABLE `enquiries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events_old`
--
ALTER TABLE `events_old`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `examroomallocation`
--
ALTER TABLE `examroomallocation`
  MODIFY `exid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exam_config_grades`
--
ALTER TABLE `exam_config_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `exam_config_totalgrades`
--
ALTER TABLE `exam_config_totalgrades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `exam_details`
--
ALTER TABLE `exam_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exam_grades`
--
ALTER TABLE `exam_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exam_mark`
--
ALTER TABLE `exam_mark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exam_remarks`
--
ALTER TABLE `exam_remarks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exam_totalgrades`
--
ALTER TABLE `exam_totalgrades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expenses_entry`
--
ALTER TABLE `expenses_entry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expenses_setting`
--
ALTER TABLE `expenses_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fees_collection_default`
--
ALTER TABLE `fees_collection_default`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fees_discount`
--
ALTER TABLE `fees_discount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1693;

--
-- AUTO_INCREMENT for table `fees_group`
--
ALTER TABLE `fees_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fees_name`
--
ALTER TABLE `fees_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `fees_type`
--
ALTER TABLE `fees_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `frbl_banner`
--
ALTER TABLE `frbl_banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `full_atten`
--
ALTER TABLE `full_atten`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groupname`
--
ALTER TABLE `groupname`
  MODIFY `gr_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `home_works`
--
ALTER TABLE `home_works`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hostel_manage`
--
ALTER TABLE `hostel_manage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hostel_room`
--
ALTER TABLE `hostel_room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hostel_room_allocation`
--
ALTER TABLE `hostel_room_allocation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hostel_type`
--
ALTER TABLE `hostel_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory_item_master`
--
ALTER TABLE `inventory_item_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory_supplier_master`
--
ALTER TABLE `inventory_supplier_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `leaves`
--
ALTER TABLE `leaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_app_his`
--
ALTER TABLE `leave_app_his`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_dect`
--
ALTER TABLE `leave_dect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `leave_name`
--
ALTER TABLE `leave_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lesson_boards`
--
ALTER TABLE `lesson_boards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lesson_board_activity`
--
ALTER TABLE `lesson_board_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lesson_board_activity_list`
--
ALTER TABLE `lesson_board_activity_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lesson_board_config`
--
ALTER TABLE `lesson_board_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `libraray_book_issue`
--
ALTER TABLE `libraray_book_issue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `libraray_new_book`
--
ALTER TABLE `libraray_new_book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `libraray_rules`
--
ALTER TABLE `libraray_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `libraray_subject`
--
ALTER TABLE `libraray_subject`
  MODIFY `hId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loan_mgmt`
--
ALTER TABLE `loan_mgmt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loan_trans`
--
ALTER TABLE `loan_trans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manage_timing`
--
ALTER TABLE `manage_timing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `minute`
--
ALTER TABLE `minute`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `month_setting`
--
ALTER TABLE `month_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `new_home_works`
--
ALTER TABLE `new_home_works`
  MODIFY `home_work_id` bigint(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification_types`
--
ALTER TABLE `notification_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `old_leaveform`
--
ALTER TABLE `old_leaveform`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `paymentplan`
--
ALTER TABLE `paymentplan`
  MODIFY `pId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `period`
--
ALTER TABLE `period`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `periods`
--
ALTER TABLE `periods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quickabse_class`
--
ALTER TABLE `quickabse_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quick_absent`
--
ALTER TABLE `quick_absent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `receipt_no`
--
ALTER TABLE `receipt_no`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reportcard_settings`
--
ALTER TABLE `reportcard_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reportentry`
--
ALTER TABLE `reportentry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `report_field`
--
ALTER TABLE `report_field`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `roles_settings`
--
ALTER TABLE `roles_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sal_day_set`
--
ALTER TABLE `sal_day_set`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_admission`
--
ALTER TABLE `school_admission`
  MODIFY `admi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1078;

--
-- AUTO_INCREMENT for table `school_admission_fees`
--
ALTER TABLE `school_admission_fees`
  MODIFY `feesid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_admission_old`
--
ALTER TABLE `school_admission_old`
  MODIFY `admi_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_config_acadamic`
--
ALTER TABLE `school_config_acadamic`
  MODIFY `scId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `school_config_design`
--
ALTER TABLE `school_config_design`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `school_config_fee`
--
ALTER TABLE `school_config_fee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_config_grade`
--
ALTER TABLE `school_config_grade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_config_house`
--
ALTER TABLE `school_config_house`
  MODIFY `hId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_config_qualification`
--
ALTER TABLE `school_config_qualification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_config_salary`
--
ALTER TABLE `school_config_salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_config_section`
--
ALTER TABLE `school_config_section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `school_cos_mark_grade`
--
ALTER TABLE `school_cos_mark_grade`
  MODIFY `markId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_exam_mark`
--
ALTER TABLE `school_exam_mark`
  MODIFY `markId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_exam_mark_grade`
--
ALTER TABLE `school_exam_mark_grade`
  MODIFY `markId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_exam_total_grade`
--
ALTER TABLE `school_exam_total_grade`
  MODIFY `srId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_fees_collection`
--
ALTER TABLE `school_fees_collection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `school_profile`
--
ALTER TABLE `school_profile`
  MODIFY `sId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `school_remarks`
--
ALTER TABLE `school_remarks`
  MODIFY `srId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_subjects`
--
ALTER TABLE `school_subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_subjects_cos`
--
ALTER TABLE `school_subjects_cos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scl_sal_fields`
--
ALTER TABLE `scl_sal_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `smslogs`
--
ALTER TABLE `smslogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_attendance`
--
ALTER TABLE `staff_attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_attendance_oldformat`
--
ALTER TABLE `staff_attendance_oldformat`
  MODIFY `attendanceId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_basic_detail`
--
ALTER TABLE `staff_basic_detail`
  MODIFY `sId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_department`
--
ALTER TABLE `staff_department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_designation`
--
ALTER TABLE `staff_designation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_form`
--
ALTER TABLE `staff_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_grade`
--
ALTER TABLE `staff_grade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_personal_detail`
--
ALTER TABLE `staff_personal_detail`
  MODIFY `spId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_postion`
--
ALTER TABLE `staff_postion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_profile`
--
ALTER TABLE `staff_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_attendance`
--
ALTER TABLE `student_attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_attendance_oldformat`
--
ALTER TABLE `student_attendance_oldformat`
  MODIFY `attendanceId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_categories`
--
ALTER TABLE `student_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_dicipline`
--
ALTER TABLE `student_dicipline`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `student_diciplines`
--
ALTER TABLE `student_diciplines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_medical`
--
ALTER TABLE `student_medical`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `student_medicals`
--
ALTER TABLE `student_medicals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_profile`
--
ALTER TABLE `student_profile`
  MODIFY `admi_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stu_exam_roomall`
--
ALTER TABLE `stu_exam_roomall`
  MODIFY `sturoom` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subcastes`
--
ALTER TABLE `subcastes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subject_allotment`
--
ALTER TABLE `subject_allotment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_home_works`
--
ALTER TABLE `tbl_home_works`
  MODIFY `home_work_id` bigint(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tec_roomselection`
--
ALTER TABLE `tec_roomselection`
  MODIFY `tecrooid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `term_setting`
--
ALTER TABLE `term_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `time`
--
ALTER TABLE `time`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `visiting_details`
--
ALTER TABLE `visiting_details`
  MODIFY `visiting_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `weekdays`
--
ALTER TABLE `weekdays`
  MODIFY `wid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `week_off`
--
ALTER TABLE `week_off`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
